import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Hen, 
  Shed, 
  EggProductionRecord, 
  EggSaleRecord, 
  FarmExpense, 
  FinancialCycle, 
  CustomerStatement, 
  PurchaseOrder, 
  WithdrawalRequest, 
  DepositRequest,
  DepositSetting,
  DepositMethodKey,
  WithdrawalSetting,
  WithdrawalMethodKey,
  WithdrawalStatus,
  SupportSetting,
  CustomerEggAllocation,
  AppUser, 
  AuditLog, 
  AppNotification, 
  PublicActiveView,
  AdminActiveSection,
  PaymentMethod,
  EggMarket,
  EggSellingOrder
} from '../types';
import { 
  INITIAL_SHEDS, 
  INITIAL_HENS, 
  INITIAL_DEPOSIT_SETTINGS,
  INITIAL_WITHDRAWAL_SETTINGS,
  INITIAL_SUPPORT_SETTING,
  INITIAL_CUSTOMERS,
  INITIAL_PURCHASES, 
  INITIAL_DEPOSITS,
  INITIAL_WITHDRAWALS, 
  INITIAL_CUSTOMER_STATEMENTS, 
  INITIAL_PRODUCTION_RECORDS, 
  INITIAL_EGG_SALES, 
  INITIAL_EXPENSES, 
  INITIAL_FINANCIAL_CYCLES, 
  INITIAL_AUDIT_LOGS, 
  INITIAL_NOTIFICATIONS,
  INITIAL_EGG_ALLOCATIONS,
  INITIAL_EGG_MARKETS
} from '../data/initialData';
import {
  supabase,
  supabaseCustomerRegister,
  supabaseCustomerLogin,
  supabaseCustomerLogout,
  supabaseGetSession,
  supabaseCreatePurchaseOrder,
  supabaseVerifyPurchaseOrder,
  supabaseFetchPurchases,
  supabaseFetchEggMarkets,
  supabaseUpdateEggMarket,
  supabaseCreateEggSellingOrder,
  supabaseProcessEggSellingOrder,
  supabaseFetchEggSellingOrders,
  supabaseCreateDeposit,
  supabaseProcessDeposit,
  supabaseFetchDeposits,
  supabaseCreateWithdrawal,
  supabaseProcessWithdrawal,
  supabaseFetchWithdrawals,
  supabaseFetchCustomerEggs,
  supabaseAllocateCustomerEggs,
  supabaseFetchSupportSettings,
  supabaseUpdateSupportSettings,
  supabaseFetchProfiles,
  supabaseResetAllData,
  AUTHORIZED_ADMIN_EMAIL,
  supabaseAdminLogin,
  supabaseAdminLogout,
  supabaseCheckAdminSession
} from '../lib/supabase';

interface AppContextType {
  // Website Complete Reset
  resetWebsiteData: () => Promise<{ success: boolean; message: string }>;

  // Customer Auth
  currentUser: AppUser | null;
  customerLogin: (realName: string, password: string) => Promise<{ success: boolean; message: string }> | { success: boolean; message: string };
  customerRegister: (realName: string, phone: string, password: string) => Promise<{ success: boolean; message: string }> | { success: boolean; message: string };
  customerPasswordReset: (identifier: string) => Promise<{ success: boolean; message: string }>;
  customerLogout: () => void;

  // Private Admin Auth (Protected email & password authentication)
  isAdminAuthenticated: boolean;
  adminEmail: string;
  adminLogin: (email: string, password: string) => Promise<{ success: boolean; message: string }>;
  adminLogout: () => Promise<void>;
  isAdminRoute: boolean;
  setIsAdminRoute: (isRoute: boolean) => void;

  // Navigation
  activeView: PublicActiveView;
  setActiveView: (view: PublicActiveView) => void;
  adminSection: AdminActiveSection;
  setAdminSection: (section: AdminActiveSection) => void;

  // Language
  language: 'en' | 'ur';
  toggleLanguage: () => void;

  // Domain Data
  hens: Hen[];
  sheds: Shed[];
  customers: AppUser[];
  depositSettings: DepositSetting[];
  depositRequests: DepositRequest[];
  withdrawalSettings: WithdrawalSetting[];
  purchases: PurchaseOrder[];
  withdrawals: WithdrawalRequest[];
  productionRecords: EggProductionRecord[];
  eggSales: EggSaleRecord[];
  expenses: FarmExpense[];
  financialCycles: FinancialCycle[];
  customerStatements: CustomerStatement[];
  auditLogs: AuditLog[];
  notifications: AppNotification[];
  lastCollectionCycleTime: number;
  triggerEggCycleReset: () => void;

  // Customer Actions
  createDepositRequest: (
    methodKey: DepositMethodKey, 
    amount: number, 
    trxRef: string, 
    receiptUrl?: string
  ) => { success: boolean; message: string };

  createPurchaseOrder: (
    quantity: number, 
    paymentMethod: PaymentMethod, 
    trxRef: string
  ) => { success: boolean; message: string };

  requestWithdrawal: (
    amount: number, 
    method: 'Easypaisa' | 'JazzCash' | 'Bank Transfer', 
    accountTitle: string, 
    accountNumber: string,
    bankName?: string
  ) => { success: boolean; message: string };

  // Admin Actions
  processDepositRequest: (
    id: string, 
    action: 'approve' | 'reject', 
    adminNote?: string
  ) => void;

  updateDepositSetting: (
    methodKey: DepositMethodKey, 
    updates: Partial<DepositSetting>
  ) => void;

  updateWithdrawalSetting: (
    methodKey: WithdrawalMethodKey, 
    updates: Partial<WithdrawalSetting>
  ) => void;

  verifyPurchaseOrder: (orderId: string) => { success: boolean; message: string };

  processWithdrawal: (
    id: string, 
    action: 'under_review' | 'approve' | 'pay' | 'reject', 
    txRef?: string, 
    adminNotes?: string
  ) => void;

  addHen: (newHen: Omit<Hen, 'id'>) => void;
  updateHenStatus: (id: string, updates: Partial<Hen>) => void;
  recordMortality: (id: string, cause: string) => void;
  recordProduction: (entry: Omit<EggProductionRecord, 'id'>) => void;
  recordEggSale: (sale: Omit<EggSaleRecord, 'id'>) => void;
  recordExpense: (expense: Omit<FarmExpense, 'id'>) => void;
  runMonthlyAllocation: (cyclePeriod: string) => void;
  markNotificationRead: (id: string) => void;
  supportSetting: SupportSetting;
  updateSupportSetting: (updates: Partial<SupportSetting>) => void;
  eggAllocations: CustomerEggAllocation[];
  availableVerifiedEggs: number;
  customerAvailableEggs: (customerId: string) => number;
  allocateFlockProduction: (shedId: string, eggsToAllocate?: number) => { success: boolean; message: string };
  adjustCustomerEggs: (customerId: string, quantity: number, reason: string) => void;

  // Supabase Egg Marketplace & Orders
  eggMarkets: EggMarket[];
  updateEggMarket: (id: string, updates: Partial<EggMarket>) => void;
  eggSellingOrders: EggSellingOrder[];
  sellEggsToMarket: (orderPayload: {
    marketId: string;
    quantity: number;
    payoutMethod: 'Bank Transfer' | 'Easypaisa' | 'JazzCash';
    accountHolderName: string;
    bankName?: string;
    accountNumber?: string;
    walletName?: string;
    walletNumber?: string;
  }) => { success: boolean; message: string };
  processEggSellingOrder: (orderId: string, action: 'paid' | 'rejected' | 'processing', txRef?: string, adminNotes?: string) => void;

  // Real-Time Requests Synchronization
  refreshLiveRequests: () => Promise<void>;
  isRefreshingRequests: boolean;
  lastSyncTime: string;

  // Modals
  selectedHenForCertificate: Hen | null;
  setSelectedHenForCertificate: (hen: Hen | null) => void;
  purchaseModalOpen: boolean;
  setPurchaseModalOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Check if current URL is an admin route (/admin or #admin or /secure-farm-control)
  const checkIsAdminRoute = (): boolean => {
    if (typeof window === 'undefined') return false;
    const path = window.location.pathname.toLowerCase();
    const hash = window.location.hash.toLowerCase();
    return (
      path.startsWith('/admin') ||
      path.includes('secure-farm-control') ||
      hash.startsWith('#admin') ||
      hash.includes('secure-farm-control')
    );
  };

  const [isAdminRoute, setIsAdminRoute] = useState<boolean>(() => checkIsAdminRoute());
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => supabaseCheckAdminSession());
  const [adminSection, setAdminSection] = useState<AdminActiveSection>('overview');

  // URL route listeners: updates route if user navigates to/from /admin or #admin
  useEffect(() => {
    const handleUrlChange = () => {
      setIsAdminRoute(checkIsAdminRoute());
    };

    window.addEventListener('popstate', handleUrlChange);
    window.addEventListener('hashchange', handleUrlChange);
    return () => {
      window.removeEventListener('popstate', handleUrlChange);
      window.removeEventListener('hashchange', handleUrlChange);
    };
  }, []);

  // Customer authentication state (clean start; persist locally)
  const [currentUser, setCurrentUser] = useState<AppUser | null>(() => {
    try {
      const saved = localStorage.getItem('fme_customer_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [customers, setCustomers] = useState<AppUser[]>(() => {
    try {
      const saved = localStorage.getItem('fme_registered_customers');
      return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
    } catch {
      return INITIAL_CUSTOMERS;
    }
  });

  const [activeView, setActiveView] = useState<PublicActiveView>('home');
  const [language, setLanguage] = useState<'en' | 'ur'>('en');

  // Domain states
  const [hens, setHens] = useState<Hen[]>(() => {
    try {
      const saved = localStorage.getItem('fme_hens');
      return saved ? JSON.parse(saved) : INITIAL_HENS;
    } catch {
      return INITIAL_HENS;
    }
  });

  const [sheds] = useState<Shed[]>(INITIAL_SHEDS);

  const [depositSettings, setDepositSettings] = useState<DepositSetting[]>(() => {
    try {
      const saved = localStorage.getItem('fme_deposit_settings');
      return saved ? JSON.parse(saved) : INITIAL_DEPOSIT_SETTINGS;
    } catch {
      return INITIAL_DEPOSIT_SETTINGS;
    }
  });

  const [withdrawalSettings, setWithdrawalSettings] = useState<WithdrawalSetting[]>(() => {
    try {
      const saved = localStorage.getItem('fme_withdrawal_settings');
      return saved ? JSON.parse(saved) : INITIAL_WITHDRAWAL_SETTINGS;
    } catch {
      return INITIAL_WITHDRAWAL_SETTINGS;
    }
  });

  const [supportSetting, setSupportSetting] = useState<SupportSetting>(() => {
    try {
      const saved = localStorage.getItem('fme_support_setting');
      return saved ? JSON.parse(saved) : INITIAL_SUPPORT_SETTING;
    } catch {
      return INITIAL_SUPPORT_SETTING;
    }
  });

  const [eggAllocations, setEggAllocations] = useState<CustomerEggAllocation[]>(() => {
    try {
      const saved = localStorage.getItem('fme_egg_allocations');
      return saved ? JSON.parse(saved) : INITIAL_EGG_ALLOCATIONS;
    } catch {
      return INITIAL_EGG_ALLOCATIONS;
    }
  });

  const [lastCollectionCycleTime, setLastCollectionCycleTime] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('fme_last_cycle_time');
      return saved ? parseInt(saved, 10) : Date.now();
    } catch {
      return Date.now();
    }
  });

  const [depositRequests, setDepositRequests] = useState<DepositRequest[]>(() => {
    try {
      const saved = localStorage.getItem('fme_deposit_requests');
      return saved ? JSON.parse(saved) : INITIAL_DEPOSITS;
    } catch {
      return INITIAL_DEPOSITS;
    }
  });

  const [purchases, setPurchases] = useState<PurchaseOrder[]>(() => {
    try {
      const saved = localStorage.getItem('fme_purchases');
      return saved ? JSON.parse(saved) : INITIAL_PURCHASES;
    } catch {
      return INITIAL_PURCHASES;
    }
  });

  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>(() => {
    try {
      const saved = localStorage.getItem('fme_withdrawals');
      return saved ? JSON.parse(saved) : INITIAL_WITHDRAWALS;
    } catch {
      return INITIAL_WITHDRAWALS;
    }
  });

  const [productionRecords, setProductionRecords] = useState<EggProductionRecord[]>(() => {
    try {
      const saved = localStorage.getItem('fme_production');
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTION_RECORDS;
    } catch {
      return INITIAL_PRODUCTION_RECORDS;
    }
  });

  const [eggSales, setEggSales] = useState<EggSaleRecord[]>(() => {
    try {
      const saved = localStorage.getItem('fme_egg_sales');
      return saved ? JSON.parse(saved) : INITIAL_EGG_SALES;
    } catch {
      return INITIAL_EGG_SALES;
    }
  });

  const [expenses, setExpenses] = useState<FarmExpense[]>(() => {
    try {
      const saved = localStorage.getItem('fme_expenses');
      return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
    } catch {
      return INITIAL_EXPENSES;
    }
  });

  const [financialCycles, setFinancialCycles] = useState<FinancialCycle[]>(() => {
    try {
      const saved = localStorage.getItem('fme_cycles');
      return saved ? JSON.parse(saved) : INITIAL_FINANCIAL_CYCLES;
    } catch {
      return INITIAL_FINANCIAL_CYCLES;
    }
  });

  const [customerStatements, setCustomerStatements] = useState<CustomerStatement[]>(() => {
    try {
      const saved = localStorage.getItem('fme_statements');
      return saved ? JSON.parse(saved) : INITIAL_CUSTOMER_STATEMENTS;
    } catch {
      return INITIAL_CUSTOMER_STATEMENTS;
    }
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);

  // Modals
  const [selectedHenForCertificate, setSelectedHenForCertificate] = useState<Hen | null>(null);
  const [purchaseModalOpen, setPurchaseModalOpen] = useState<boolean>(false);

  // Supabase Egg Markets & Customer Selling Orders
  const [eggMarkets, setEggMarkets] = useState<EggMarket[]>(() => {
    try {
      const saved = localStorage.getItem('fme_egg_markets');
      return saved ? JSON.parse(saved) : INITIAL_EGG_MARKETS;
    } catch {
      return INITIAL_EGG_MARKETS;
    }
  });

  const [eggSellingOrders, setEggSellingOrders] = useState<EggSellingOrder[]>(() => {
    try {
      const saved = localStorage.getItem('fme_egg_selling_orders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Derived available verified physical eggs in farm inventory
  const totalFarmCollected = productionRecords.reduce((sum, r) => sum + r.eggsCollected, 0);
  const totalFarmDamaged = productionRecords.reduce((sum, r) => sum + r.eggsDamaged, 0);
  const totalFarmSold = eggSales.reduce((sum, s) => sum + s.quantityEggs, 0);
  const totalAllocated = eggAllocations.reduce((sum, a) => sum + a.quantity, 0);
  const availableVerifiedEggs = Math.max(0, totalFarmCollected - totalFarmDamaged - totalFarmSold - totalAllocated);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('fme_hens', JSON.stringify(hens));
      localStorage.setItem('fme_deposit_settings', JSON.stringify(depositSettings));
      localStorage.setItem('fme_withdrawal_settings', JSON.stringify(withdrawalSettings));
      localStorage.setItem('fme_support_setting', JSON.stringify(supportSetting));
      localStorage.setItem('fme_egg_allocations', JSON.stringify(eggAllocations));
      localStorage.setItem('fme_production', JSON.stringify(productionRecords));
      localStorage.setItem('fme_deposit_requests', JSON.stringify(depositRequests));
      localStorage.setItem('fme_purchases', JSON.stringify(purchases));
      localStorage.setItem('fme_withdrawals', JSON.stringify(withdrawals));
      localStorage.setItem('fme_registered_customers', JSON.stringify(customers));
      localStorage.setItem('fme_egg_markets', JSON.stringify(eggMarkets));
      localStorage.setItem('fme_egg_selling_orders', JSON.stringify(eggSellingOrders));
      if (currentUser) {
        localStorage.setItem('fme_customer_user', JSON.stringify(currentUser));
      } else {
        localStorage.removeItem('fme_customer_user');
      }
    } catch (e) {
      console.warn('Storage sync issue:', e);
    }
  }, [hens, depositSettings, withdrawalSettings, supportSetting, eggAllocations, productionRecords, depositRequests, purchases, withdrawals, customers, currentUser, eggMarkets, eggSellingOrders]);

  // Real-Time Requests Synchronization State
  const [isRefreshingRequests, setIsRefreshingRequests] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>('Just now');

  const refreshLiveRequests = async () => {
    try {
      setIsRefreshingRequests(true);
      const [liveDeps, liveWdrs] = await Promise.all([
        supabaseFetchDeposits(),
        supabaseFetchWithdrawals()
      ]);

      if (liveDeps && Array.isArray(liveDeps)) {
        setDepositRequests(prev => {
          const map = new Map<string, DepositRequest>();
          // Index existing by ID
          prev.forEach(d => map.set(d.id, d));
          // Overlay with live Supabase database records
          liveDeps.forEach(d => {
            map.set(d.id, d);
            // Deduplicate if temporary local ID was used
            if (d.transactionReference) {
              for (const [key, val] of map.entries()) {
                if (key !== d.id && val.transactionReference === d.transactionReference) {
                  map.delete(key);
                }
              }
            }
          });
          return Array.from(map.values()).sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
        });
      }

      if (liveWdrs && Array.isArray(liveWdrs)) {
        setWithdrawals(prev => {
          const map = new Map<string, WithdrawalRequest>();
          prev.forEach(w => map.set(w.id, w));
          liveWdrs.forEach(w => map.set(w.id, w));
          return Array.from(map.values()).sort((a, b) => (b.requestedAt || '').localeCompare(a.requestedAt || ''));
        });
      }

      // Also refresh egg markets, purchases, selling orders from Supabase/cache
      supabaseFetchPurchases().then(livePurchases => {
        if (livePurchases && livePurchases.length > 0) setPurchases(livePurchases);
      });
      supabaseFetchEggSellingOrders().then(liveOrders => {
        if (liveOrders && liveOrders.length > 0) setEggSellingOrders(liveOrders);
      });

      setLastSyncTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (err) {
      console.warn('Error refreshing live requests from Supabase:', err);
    } finally {
      setIsRefreshingRequests(false);
    }
  };

  // Supabase Session & Complete Live Data Sync on startup + Polling + Real-time Channel
  useEffect(() => {
    supabaseGetSession().then(sessUser => {
      if (sessUser) {
        setCurrentUser(sessUser);
      }
    });

    supabaseFetchEggMarkets().then(liveMarkets => {
      if (liveMarkets && liveMarkets.length > 0) {
        setEggMarkets(liveMarkets);
      }
    });

    supabaseFetchSupportSettings().then(liveSupport => {
      if (liveSupport) {
        setSupportSetting(liveSupport);
      }
    });

    supabaseFetchCustomerEggs().then(liveEggs => {
      if (liveEggs && liveEggs.length > 0) {
        setEggAllocations(liveEggs);
      }
    });

    supabaseFetchProfiles().then(liveProfiles => {
      if (liveProfiles && liveProfiles.length > 0) {
        setCustomers(liveProfiles);
      }
    });

    // Run initial request fetch
    refreshLiveRequests();

    // Auto-polling interval every 6 seconds to ensure immediate updates across any clients
    const pollInterval = setInterval(() => {
      refreshLiveRequests();
    }, 6000);

    // Real-time channel listener for public.deposits and public.withdrawals
    const channel = supabase
      .channel('fme-all-requests-sync')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'deposits' }, () => {
        refreshLiveRequests();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'withdrawals' }, () => {
        refreshLiveRequests();
      })
      .subscribe();

    // Broadcast channel / storage event listener for multi-tab synchronization
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'fme_deposit_requests' || e.key === 'fme_withdrawals' || e.key === 'fme_request_signal') {
        refreshLiveRequests();
      }
    };
    window.addEventListener('storage', handleStorageChange);

    return () => {
      clearInterval(pollInterval);
      supabase.removeChannel(channel);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  // URL listener for private route
  useEffect(() => {
    const handleLocation = () => {
      const isPriv = window.location.pathname.includes('secure-farm-control') || 
        window.location.hash.includes('secure-farm-control');
      setIsAdminRoute(isPriv);
    };

    window.addEventListener('popstate', handleLocation);
    window.addEventListener('hashchange', handleLocation);
    return () => {
      window.removeEventListener('popstate', handleLocation);
      window.removeEventListener('hashchange', handleLocation);
    };
  }, []);

  const addAudit = (action: string, category: AuditLog['category'], details: string) => {
    const newLog: AuditLog = {
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      actor: isAdminAuthenticated ? 'Farm Operations Lead (Tariq)' : currentUser ? currentUser.name : 'Public Customer',
      action,
      category,
      details,
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  const toggleLanguage = () => {
    setLanguage(prev => (prev === 'en' ? 'ur' : 'en'));
  };

  // --- Customer Authentication (Real Name, Phone, and Password) ---
  const customerRegister = async (
    realName: string, 
    phone: string, 
    password: string
  ) => {
    const trimmedName = realName.trim();
    const cleanedPhone = phone.trim().replace(/[\s-]/g, '');

    if (!trimmedName || trimmedName.length < 2) {
      return { success: false, message: 'Please provide your Real Name (minimum 2 characters).' };
    }

    if (!cleanedPhone || cleanedPhone.length < 8) {
      return { success: false, message: 'Please provide a valid Phone Number (e.g. 0300 1234567).' };
    }

    if (!password || password.length < 6) {
      return { success: false, message: 'Password must be at least 6 characters long.' };
    }

    // Check duplicate phone number in state
    const duplicate = customers.find(c => c.phone.replace(/[\s-]/g, '') === cleanedPhone);
    if (duplicate) {
      return { success: false, message: 'This phone number is already registered. Please sign in or use a different phone number.' };
    }

    // Call Supabase registration
    const supaRes = await supabaseCustomerRegister(trimmedName, phone.trim(), password);
    if (!supaRes.success || !supaRes.user) {
      return { success: false, message: supaRes.message };
    }

    const newUser = supaRes.user;
    setCustomers(prev => [...prev.filter(c => c.id !== newUser.id), newUser]);
    setCurrentUser(newUser);
    addAudit('Customer Account Registered', 'security', `Customer ${newUser.name} (${newUser.phone}) registered.`);
    return { success: true, message: 'Account registered successfully!' };
  };

  const customerLogin = async (realName: string, password: string) => {
    const trimmedName = realName.trim();

    if (!trimmedName) {
      return { success: false, message: 'Please enter your registered Real Name.' };
    }

    if (!password) {
      return { success: false, message: 'Please enter your password.' };
    }

    // Call Supabase login
    const supaRes = await supabaseCustomerLogin(trimmedName, password);
    if (supaRes.success && supaRes.user) {
      setCurrentUser(supaRes.user);
      setCustomers(prev => {
        if (!prev.some(c => c.id === supaRes.user!.id)) {
          return [...prev, supaRes.user!];
        }
        return prev;
      });
      addAudit('Customer Login', 'security', `Customer ${supaRes.user.name} logged in.`);
      return { success: true, message: supaRes.message };
    }

    // Local state fallback matching
    const localMatch = customers.find(
      c => c.name.toLowerCase() === trimmedName.toLowerCase() ||
           c.phone.replace(/[\s-]/g, '') === trimmedName.replace(/[\s-]/g, '')
    );
    if (localMatch) {
      setCurrentUser(localMatch);
      addAudit('Customer Login', 'security', `Customer ${localMatch.name} logged in.`);
      return { success: true, message: `Welcome back, ${localMatch.name}!` };
    }

    return { 
      success: false, 
      message: supaRes.message || `No account found for Real Name "${trimmedName}". Please check the spelling or register.` 
    };
  };

  const customerLogout = async () => {
    if (currentUser) {
      addAudit('Customer Logout', 'security', `Customer ${currentUser.name} logged out.`);
    }
    await supabaseCustomerLogout();
    setCurrentUser(null);
    setActiveView('home');
  };

  // Complete Website Data Reset (Purges all test accounts, demo orders, and balances)
  const resetWebsiteData = async (): Promise<{ success: boolean; message: string }> => {
    const res = await supabaseResetAllData();

    // Pristine clean state
    setCurrentUser(null);
    setCustomers([]);
    setPurchases([]);
    setDepositRequests([]);
    setWithdrawals([]);
    setEggAllocations([]);
    setEggSellingOrders([]);
    setEggSales([]);
    setExpenses([]);
    setFinancialCycles([]);
    setCustomerStatements([]);
    setNotifications([]);
    setHens(INITIAL_HENS.map(h => ({ ...h, status: 'available', ownerId: undefined })));
    setAuditLogs([
      {
        id: `audit-reset-${Date.now()}`,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
        actor: 'Admin / System Reset',
        action: 'Complete Website & Database Reset Executed',
        category: 'security',
        details: 'All demo accounts, test transactions, egg balances, and selling requests wiped clean.',
      }
    ]);
    setLastCollectionCycleTime(Date.now());
    setActiveView('home');

    return res;
  };

  const customerPasswordReset = async (email: string) => {
    const trimmedEmail = email.trim().toLowerCase();
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(trimmedEmail);
      if (error) {
        return { success: false, message: error.message };
      }
      return { success: true, message: 'Password reset link sent to your registered email address!' };
    } catch (e: any) {
      return { success: false, message: e?.message || 'Failed to dispatch reset email.' };
    }
  };

  // --- Private Admin Authentication (Authorized Email: hanzlapremium@gmail.com) ---
  const adminLogin = async (email: string, pass: string): Promise<{ success: boolean; message: string }> => {
    const res = await supabaseAdminLogin(email, pass);
    if (res.success) {
      setIsAdminAuthenticated(true);
      addAudit('Admin Access Granted', 'security', `Authorized login for administrator (${email}) to Secure Farm Control.`);
    } else {
      addAudit('Failed Admin Access Attempt', 'security', `Unauthorized attempt with email "${email}".`);
    }
    return res;
  };

  const adminLogout = async () => {
    await supabaseAdminLogout();
    setIsAdminAuthenticated(false);
    setIsAdminRoute(false);
    addAudit('Admin Session Closed', 'security', 'Administrator signed out of console.');
    if (typeof window !== 'undefined') {
      window.location.hash = '';
      if (window.location.pathname.startsWith('/admin') || window.location.pathname.includes('secure-farm-control')) {
        window.history.replaceState(null, '', '/');
      }
    }
    setActiveView('home');
  };

  // --- Customer Deposit Workflow ---
  const createDepositRequest = (
    methodKey: DepositMethodKey, 
    amount: number, 
    trxRef: string, 
    receiptUrl?: string
  ) => {
    if (!currentUser) {
      return { success: false, message: 'Please log in to your customer account to submit a deposit.' };
    }

    if (amount < 500) {
      return { success: false, message: 'Minimum deposit amount is Rs. 500 (price of 1 physical hen).' };
    }

    if (!trxRef.trim()) {
      return { success: false, message: 'Transaction Reference ID (TRX/TID) is required.' };
    }

    // Duplicate check
    const isDuplicate = depositRequests.some(d => d.transactionReference.toLowerCase() === trxRef.trim().toLowerCase());
    if (isDuplicate) {
      return { success: false, message: 'This transaction reference ID has already been submitted.' };
    }

    const methodSetting = depositSettings.find(s => s.methodKey === methodKey);
    const methodName = methodSetting ? methodSetting.name : methodKey;
    const tempId = `dep-${Date.now()}`;

    const newDep: DepositRequest = {
      id: tempId,
      customerId: currentUser.id,
      customerName: currentUser.name,
      customerPhone: currentUser.phone,
      customerEmail: currentUser.email,
      methodKey,
      methodName,
      amount,
      transactionReference: trxRef.trim(),
      receiptUrl: receiptUrl || '/src/assets/images/fresh_farm_eggs_1793810684885.jpg',
      status: 'pending',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    setDepositRequests(prev => [newDep, ...prev]);

    // Dispatch to Supabase backend and capture generated UUID
    supabaseCreateDeposit({
      userId: currentUser.id,
      customerName: currentUser.name,
      customerPhone: currentUser.phone,
      customerEmail: currentUser.email,
      amount: amount,
      paymentMethod: methodName,
      transactionReference: trxRef.trim(),
    }).then(res => {
      if (res && res.depositId) {
        setDepositRequests(prev => prev.map(d => (d.id === tempId || d.transactionReference === trxRef.trim()) ? { ...d, id: res.depositId } : d));
      }
      try {
        localStorage.setItem('fme_request_signal', Date.now().toString());
      } catch {}
      refreshLiveRequests();
    });

    addAudit(
      'Deposit Request Submitted',
      'deposit',
      `Customer ${currentUser.name} submitted Rs. ${amount.toLocaleString()} via ${methodName}. TRX: ${trxRef}. Status: Pending Verification.`
    );

    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      userId: currentUser.id,
      title: 'Deposit Submitted for Verification',
      message: `Your deposit request for Rs. ${amount.toLocaleString()} via ${methodName} (TRX: ${trxRef}) is queued for manual admin review.`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      read: false,
      type: 'deposit',
    };
    setNotifications(prev => [notif, ...prev]);

    return { 
      success: true, 
      message: 'Deposit verification request submitted successfully! Saved directly to Supabase public.deposits table.' 
    };
  };

  // --- Admin Deposit Management ---
  const processDepositRequest = (
    id: string, 
    action: 'approve' | 'reject', 
    adminNote?: string
  ) => {
    const dep = depositRequests.find(d => d.id === id || d.transactionReference === id);
    if (!dep) return;

    const updatedStatus = action === 'approve' ? 'approved' : 'rejected';
    const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 16);

    setDepositRequests(prev => prev.map(d => (d.id === id || (dep.transactionReference && d.transactionReference === dep.transactionReference)) ? {
      ...d,
      status: updatedStatus,
      adminNote: adminNote || (action === 'approve' ? 'Bank transfer confirmed.' : 'Verification failed.'),
      processedAt: nowTime,
      processedBy: 'Tariq Mahmood (Operations Lead)',
    } : d));

    if (action === 'approve') {
      // Credit customer withdrawable balance
      setCustomers(prev => prev.map(c => c.id === dep.customerId ? {
        ...c,
        withdrawableBalance: c.withdrawableBalance + dep.amount,
      } : c));

      // Also update currentUser if currently logged in
      if (currentUser && currentUser.id === dep.customerId) {
        setCurrentUser(prev => prev ? {
          ...prev,
          withdrawableBalance: prev.withdrawableBalance + dep.amount,
        } : null);
      }

      addAudit(
        'Deposit Request Approved',
        'deposit',
        `Approved deposit ${dep.id} (Rs. ${dep.amount.toLocaleString()}) for ${dep.customerName}. Account credited.`
      );

      const notif: AppNotification = {
        id: `notif-${Date.now()}`,
        userId: dep.customerId,
        title: 'Deposit Approved & Balance Credited',
        message: `Your deposit of Rs. ${dep.amount.toLocaleString()} via ${dep.methodName} (TRX: ${dep.transactionReference}) has been verified. Available balance updated.`,
        date: nowTime,
        read: false,
        type: 'deposit',
      };
      setNotifications(prev => [notif, ...prev]);
    } else {
      addAudit(
        'Deposit Request Rejected',
        'deposit',
        `Rejected deposit ${dep.id} for ${dep.customerName}. Reason: ${adminNote || 'Invalid reference'}`
      );

      const notif: AppNotification = {
        id: `notif-${Date.now()}`,
        userId: dep.customerId,
        title: 'Deposit Verification Declined',
        message: `Your deposit request for Rs. ${dep.amount.toLocaleString()} could not be verified. Note: ${adminNote || 'Transaction reference mismatch.'}`,
        date: nowTime,
        read: false,
        type: 'deposit',
      };
      setNotifications(prev => [notif, ...prev]);
    }

    // Update in Supabase backend using UUID and fallback reference
    supabaseProcessDeposit(dep.id, updatedStatus, dep.customerId, dep.amount, dep.transactionReference, adminNote).then(() => {
      try {
        localStorage.setItem('fme_request_signal', Date.now().toString());
      } catch {}
      refreshLiveRequests();
    });
  };

  // --- Admin Deposit Settings ---
  const updateDepositSetting = (methodKey: DepositMethodKey, updates: Partial<DepositSetting>) => {
    const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setDepositSettings(prev => prev.map(s => s.methodKey === methodKey ? {
      ...s,
      ...updates,
      updatedAt: nowTime,
    } : s));

    addAudit(
      'Updated Deposit Method Settings',
      'settings',
      `Modified configuration for deposit gateway: ${methodKey}. Details: ${JSON.stringify(updates)}`
    );
  };

  // --- Admin Withdrawal Settings ---
  const updateWithdrawalSetting = (methodKey: WithdrawalMethodKey, updates: Partial<WithdrawalSetting>) => {
    const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setWithdrawalSettings(prev => prev.map(s => s.methodKey === methodKey ? {
      ...s,
      ...updates,
      updatedAt: nowTime,
    } : s));

    addAudit(
      'Updated Withdrawal Method Settings',
      'settings',
      `Modified configuration for withdrawal gateway: ${methodKey}. Details: ${JSON.stringify(updates)}`
    );
  };

  // --- Admin Support Settings ---
  const updateSupportSetting = (updates: Partial<SupportSetting>) => {
    const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setSupportSetting(prev => {
      const updated = {
        ...prev,
        ...updates,
        updatedAt: nowTime,
      };
      try {
        localStorage.setItem('fme_support_setting', JSON.stringify(updated));
      } catch (e) {
        console.warn(e);
      }
      return updated;
    });

    addAudit(
      'Support Settings Updated',
      'settings',
      `Modified farm customer support parameters. Phone: ${updates.phoneNumber || supportSetting.phoneNumber}, WhatsApp: ${updates.whatsappNumber || supportSetting.whatsappNumber}, Enabled: ${updates.isEnabled !== undefined ? updates.isEnabled : supportSetting.isEnabled}`
    );

    // Sync to Supabase backend
    supabaseUpdateSupportSettings(updates);
  };

  // --- Egg Production Cycle Reset (24H Timer) ---
  const triggerEggCycleReset = () => {
    const now = Date.now();
    setLastCollectionCycleTime(now);
    try {
      localStorage.setItem('fme_last_cycle_time', now.toString());
    } catch (e) {
      console.warn(e);
    }
    addAudit(
      'Egg Production Cycle Reset',
      'production',
      'Authorized farm supervisor recorded daily collection cycle and reset 24H flock timer.'
    );
  };

  // --- Customer Purchase Order ---
  const createPurchaseOrder = (
    quantity: number, 
    paymentMethod: PaymentMethod, 
    trxRef: string
  ) => {
    if (!currentUser) {
      return { success: false, message: 'Please log in to purchase hens.' };
    }

    if (quantity < 1) {
      return { success: false, message: 'Please select at least 1 hen.' };
    }

    const unitPrice = 500;
    const totalAmount = quantity * unitPrice;

    // If paying via account balance: check balance and deduct immediately
    if (paymentMethod === 'Account Balance') {
      if (currentUser.withdrawableBalance < totalAmount) {
        return { 
          success: false, 
          message: `Insufficient balance (Rs. ${currentUser.withdrawableBalance.toFixed(2)}). Please deposit funds or pay via direct bank/wallet.` 
        };
      }

      // Deduct balance
      setCurrentUser(prev => prev ? { ...prev, withdrawableBalance: prev.withdrawableBalance - totalAmount } : null);
      setCustomers(prev => prev.map(c => c.id === currentUser.id ? { ...c, withdrawableBalance: c.withdrawableBalance - totalAmount } : c));

      const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 16);
      const nowMs = Date.now();
      const cycleMs = 24 * 60 * 60 * 1000;
      const breedOptions: Hen['breed'][] = ['Rhode Island Red', 'Golden Misri', 'White Leghorn', 'Fayoumi Layer'];
      const shedOptions = [
        { id: 'shed-1', name: 'Shed 1 - Alpha Layer House' },
        { id: 'shed-2', name: 'Shed 2 - Sunrise Golden Flock' },
        { id: 'shed-3', name: 'Shed 3 - Heritage & Desi Enclosure' },
      ];

      const assignedHens: Hen[] = [];
      const assignedIds: string[] = [];

      // Take existing available hens first
      const availableHens = hens.filter(h => h.status === 'available');
      const reuseCount = Math.min(quantity, availableHens.length);
      const reusedHens = availableHens.slice(0, reuseCount);

      reusedHens.forEach((h) => {
        assignedHens.push({
          ...h,
          status: 'owned',
          ownerId: currentUser.id,
          ownerName: currentUser.name,
          acquisitionDate: nowTime.split(' ')[0],
          ownershipId: `FME-CUST-${currentUser.id.slice(-4).toUpperCase()}-${h.tagCode}`,
          initialEggsAllocated: 1,
          cycleStartedAt: nowMs,
          nextCollectionTimestamp: nowMs + cycleMs,
        });
        assignedIds.push(h.id);
      });

      // Dynamically generate remaining hens if customer purchases more than unassigned pool
      const remainingCount = quantity - reuseCount;
      const newHensCreated: Hen[] = [];
      for (let i = 0; i < remainingCount; i++) {
        const randId = `hen-${nowMs}-${i + 1}`;
        const randTag = `FME-L${nowMs.toString().slice(-4)}-${i + 1 + Math.floor(Math.random() * 89)}`;
        const selectedBreed = breedOptions[(i + reuseCount) % breedOptions.length];
        const selectedShed = shedOptions[(i + reuseCount) % shedOptions.length];
        
        const newHen: Hen = {
          id: randId,
          tagCode: randTag,
          breed: selectedBreed,
          ageWeeks: 24,
          healthStatus: 'healthy',
          shedId: selectedShed.id,
          shedName: selectedShed.name,
          flockCode: `FLK-LAYER-${nowTime.split('-')[0]}`,
          purchasePrice: 500,
          status: 'owned',
          ownerId: currentUser.id,
          ownerName: currentUser.name,
          acquisitionDate: nowTime.split(' ')[0],
          vaccinationStatus: 'Certified ND + Marek + IB Complete',
          photoUrl: '/src/assets/images/layer_hens_close_1793810684205.jpg',
          dailyEggYieldAvg: 0.88,
          ownershipId: `FME-CUST-${currentUser.id.slice(-4).toUpperCase()}-${randTag}`,
          initialEggsAllocated: 1,
          cycleStartedAt: nowMs,
          nextCollectionTimestamp: nowMs + cycleMs,
          notes: 'High productive point-of-lay pullet in farm custody flock.',
        };
        assignedHens.push(newHen);
        assignedIds.push(randId);
        newHensCreated.push(newHen);
      }

      // Update hens state
      setHens(prev => {
        const updated = prev.map(h => {
          const matched = assignedHens.find(ah => ah.id === h.id);
          return matched ? matched : h;
        });
        return [...updated, ...newHensCreated];
      });

      // Immediate 1:1 egg credit: 1 hen = 1 egg, instantly ready to sell!
      const initialEggsToAllocate = quantity;
      const allocRecord: CustomerEggAllocation = {
        id: `alloc-${nowMs}-${Math.floor(Math.random() * 1000)}`,
        customerId: currentUser.id,
        customerName: currentUser.name,
        quantity: initialEggsToAllocate,
        allocationType: 'initial_purchase',
        date: nowTime,
        timestamp: nowMs,
        batchId: `BATCH-INIT-${nowMs.toString().slice(-4)}`,
        shedName: 'Farming Master Egg Flock',
        notes: `Immediate 1:1 initial egg credit (${quantity} eggs for ${quantity} acquired hens) available for selling immediately.`,
        verifiedBy: 'Tariq Mahmood (Operations Lead)',
      };
      setEggAllocations(prev => [allocRecord, ...prev]);

      // Sync egg allocation to Supabase backend
      supabaseAllocateCustomerEggs({
        userId: currentUser.id,
        quantity: initialEggsToAllocate,
        allocationType: 'initial_purchase',
        notes: `Immediate 1:1 egg credit for ${quantity} acquired hens`,
      });

      const newOrder: PurchaseOrder = {
        id: `ord-2026-${Math.floor(100 + Math.random() * 900)}`,
        customerId: currentUser.id,
        customerName: currentUser.name,
        customerPhone: currentUser.phone,
        customerEmail: currentUser.email,
        quantity,
        unitPrice,
        totalAmount,
        paymentMethod,
        transactionReference: `BAL-${Date.now().toString().slice(-6)}`,
        status: 'verified',
        assignedHenIds: assignedIds,
        createdAt: nowTime,
        verifiedAt: nowTime,
        agreementSigned: true,
      };

      setPurchases(prev => [newOrder, ...prev]);

      // Sync verified purchase order and assigned ownership to Supabase backend
      supabaseCreatePurchaseOrder({
        userId: currentUser.id,
        userName: currentUser.name,
        userPhone: currentUser.phone,
        userEmail: currentUser.email,
        quantity,
        unitPrice,
        totalAmount,
        paymentMethod,
        transactionReference: newOrder.transactionReference,
        isImmediatelyVerified: true,
        assignedHenIds: assignedIds,
      });

      addAudit(
        'Hen Purchase Completed & Eggs Allocated',
        'purchase',
        `Customer ${currentUser.name} bought ${quantity} hens (Rs. ${totalAmount}). Assigned: ${assignedHens.map(h => h.tagCode).join(', ')}. Initial verified eggs allocated: ${initialEggsToAllocate} (1 hen = 1 egg).`
      );

      const notif: AppNotification = {
        id: `notif-${Date.now()}`,
        userId: currentUser.id,
        title: 'Hens Acquired & Initial Eggs Allocated!',
        message: `Your acquisition of ${quantity} physical hens is complete with ${initialEggsToAllocate} initial verified egg(s) immediately available in your balance ready to sell. Next 24-hour collection countdown is live. Assigned tags: ${assignedHens.map(h => h.tagCode).join(', ')}.`,
        date: nowTime,
        read: false,
        type: 'purchase',
      };
      setNotifications(prev => [notif, ...prev]);

      return { 
        success: true, 
        message: `Purchase successful! ${quantity} hen(s) activated and ${initialEggsToAllocate} egg(s) immediately credited to your Available Eggs balance ready to sell!` 
      };
    }

    // Otherwise: Pending manual verification
    if (!trxRef.trim()) {
      return { success: false, message: 'Please enter transaction reference ID.' };
    }

    const newOrder: PurchaseOrder = {
      id: `ord-2026-${Math.floor(100 + Math.random() * 900)}`,
      customerId: currentUser.id,
      customerName: currentUser.name,
      customerPhone: currentUser.phone,
      customerEmail: currentUser.email,
      quantity,
      unitPrice,
      totalAmount,
      paymentMethod,
      transactionReference: trxRef.trim(),
      status: 'pending',
      assignedHenIds: [],
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      agreementSigned: true,
    };

    setPurchases(prev => [newOrder, ...prev]);

    // Dispatch to Supabase backend
    supabaseCreatePurchaseOrder({
      userId: currentUser.id,
      userName: currentUser.name,
      userPhone: currentUser.phone,
      userEmail: currentUser.email,
      quantity,
      unitPrice,
      totalAmount,
      paymentMethod,
      transactionReference: trxRef.trim(),
      isImmediatelyVerified: false,
      assignedHenIds: [],
    });

    addAudit(
      'Hen Purchase Order Submitted',
      'purchase',
      `Order ${newOrder.id} for ${quantity} hens (Rs. ${totalAmount}) submitted by ${currentUser.name}. Awaiting verification.`
    );

    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      userId: currentUser.id,
      title: 'Hen Acquisition Order Pending Verification',
      message: `Your order for ${quantity} hen(s) (Rs. ${totalAmount}) has been submitted. Physical IDs and initial eggs will be allocated upon admin verification.`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      read: false,
      type: 'purchase',
    };
    setNotifications(prev => [notif, ...prev]);

    return { success: true, message: 'Purchase order submitted for admin verification!' };
  };

  // --- Admin Verify Purchase Order ---
  const verifyPurchaseOrder = (orderId: string) => {
    const order = purchases.find(p => p.id === orderId);
    if (!order || order.status === 'verified') {
      return { success: false, message: 'Order not found or already verified.' };
    }

    const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const nowMs = Date.now();
    const cycleMs = 24 * 60 * 60 * 1000;
    const breedOptions: Hen['breed'][] = ['Rhode Island Red', 'Golden Misri', 'White Leghorn', 'Fayoumi Layer'];
    const shedOptions = [
      { id: 'shed-1', name: 'Shed 1 - Alpha Layer House' },
      { id: 'shed-2', name: 'Shed 2 - Sunrise Golden Flock' },
      { id: 'shed-3', name: 'Shed 3 - Heritage & Desi Enclosure' },
    ];

    const assignedHens: Hen[] = [];
    const assignedIds: string[] = [];

    // Assign existing available hens first
    const availableHens = hens.filter(h => h.status === 'available');
    const reuseCount = Math.min(order.quantity, availableHens.length);
    const reusedHens = availableHens.slice(0, reuseCount);

    reusedHens.forEach(h => {
      assignedHens.push({
        ...h,
        status: 'owned',
        ownerId: order.customerId,
        ownerName: order.customerName,
        acquisitionDate: nowTime.split(' ')[0],
        ownershipId: `FME-CUST-${order.customerId.slice(-4).toUpperCase()}-${h.tagCode}`,
        initialEggsAllocated: 1,
        cycleStartedAt: nowMs,
        nextCollectionTimestamp: nowMs + cycleMs,
      });
      assignedIds.push(h.id);
    });

    // Auto-generate remaining hens if order exceeds available inventory
    const remainingCount = order.quantity - reuseCount;
    const newHensCreated: Hen[] = [];
    for (let i = 0; i < remainingCount; i++) {
      const randId = `hen-${nowMs}-${i + 1}`;
      const randTag = `FME-L${nowMs.toString().slice(-4)}-${i + 1 + Math.floor(Math.random() * 89)}`;
      const selectedBreed = breedOptions[(i + reuseCount) % breedOptions.length];
      const selectedShed = shedOptions[(i + reuseCount) % shedOptions.length];

      const newHen: Hen = {
        id: randId,
        tagCode: randTag,
        breed: selectedBreed,
        ageWeeks: 24,
        healthStatus: 'healthy',
        shedId: selectedShed.id,
        shedName: selectedShed.name,
        flockCode: `FLK-LAYER-${nowTime.split('-')[0]}`,
        purchasePrice: 500,
        status: 'owned',
        ownerId: order.customerId,
        ownerName: order.customerName,
        acquisitionDate: nowTime.split(' ')[0],
        vaccinationStatus: 'Certified ND + Marek + IB Complete',
        photoUrl: '/src/assets/images/layer_hens_close_1793810684205.jpg',
        dailyEggYieldAvg: 0.88,
        ownershipId: `FME-CUST-${order.customerId.slice(-4).toUpperCase()}-${randTag}`,
        initialEggsAllocated: 1,
        cycleStartedAt: nowMs,
        nextCollectionTimestamp: nowMs + cycleMs,
        notes: 'High productive point-of-lay pullet in farm custody flock.',
      };
      assignedHens.push(newHen);
      assignedIds.push(randId);
      newHensCreated.push(newHen);
    }

    setHens(prev => {
      const updated = prev.map(h => {
        const matched = assignedHens.find(ah => ah.id === h.id);
        return matched ? matched : h;
      });
      return [...updated, ...newHensCreated];
    });

    // Immediate 1:1 initial egg credit (1 hen = 1 egg)
    const initialEggsToAllocate = order.quantity;
    const allocRecord: CustomerEggAllocation = {
      id: `alloc-${nowMs}-${Math.floor(Math.random() * 1000)}`,
      customerId: order.customerId,
      customerName: order.customerName,
      quantity: initialEggsToAllocate,
      allocationType: 'initial_purchase',
      date: nowTime,
      timestamp: nowMs,
      batchId: `BATCH-VERIFY-${nowMs.toString().slice(-4)}`,
      shedName: 'Farming Master Egg Flock',
      notes: `Immediate 1:1 initial egg credit (${order.quantity} eggs for ${order.quantity} verified hens) available for selling immediately.`,
      verifiedBy: 'Tariq Mahmood (Operations Lead)',
    };
    setEggAllocations(prev => [allocRecord, ...prev]);

    setPurchases(prev => prev.map(p => p.id === orderId ? {
      ...p,
      status: 'verified',
      assignedHenIds: assignedIds,
      verifiedAt: nowTime,
    } : p));

    addAudit(
      'Verified Purchase & Assigned Hens and Eggs',
      'purchase',
      `Verified order ${orderId} (${order.customerName}). Assigned: ${assignedHens.map(h => h.tagCode).join(', ')}. Allocated initial eggs: ${initialEggsToAllocate} (1 hen = 1 egg).`
    );

    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      userId: order.customerId,
      title: 'Payment Verified & Physical Hens Assigned!',
      message: `Your payment was verified. Permanent physical tags: ${assignedHens.map(h => h.tagCode).join(', ')} are registered in your name with ${initialEggsToAllocate} verified egg(s) immediately ready to sell. Download your Ownership Certificates.`,
      date: nowTime,
      read: false,
      type: 'purchase',
    };
    setNotifications(prev => [notif, ...prev]);

    // Dispatch verification and 1:1 egg credit to Supabase backend
    supabaseVerifyPurchaseOrder(orderId, order.customerId, assignedIds, initialEggsToAllocate);
    supabaseAllocateCustomerEggs({
      userId: order.customerId,
      quantity: initialEggsToAllocate,
      allocationType: 'initial_purchase',
      notes: `Immediate 1:1 egg credit for ${order.quantity} verified hens`,
    });

    return { 
      success: true, 
      message: `Order verified! Assigned ${assignedHens.length} hen(s) and immediately credited ${initialEggsToAllocate} egg(s) ready to sell!` 
    };
  };

  // --- Admin Flock Egg Allocation & Adjustments ---
  const allocateFlockProduction = (shedId: string, eggsToAllocate?: number) => {
    const activeHens = hens.filter(h => h.status === 'owned' && (shedId === 'all' || h.shedId === shedId));
    if (activeHens.length === 0) {
      return { success: false, message: 'No customer-owned hens currently active in the selected shed.' };
    }

    const pool = eggsToAllocate || Math.min(availableVerifiedEggs, activeHens.length);
    if (pool <= 0) {
      return { success: false, message: 'No unallocated verified eggs currently available in farm inventory.' };
    }

    const customerHenMap: Record<string, { count: number; name: string }> = {};
    activeHens.forEach(h => {
      if (h.ownerId) {
        if (!customerHenMap[h.ownerId]) {
          customerHenMap[h.ownerId] = { count: 0, name: h.ownerName || 'Customer' };
        }
        customerHenMap[h.ownerId].count += 1;
      }
    });

    const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const nowMs = Date.now();
    const newAllocations: CustomerEggAllocation[] = [];
    let distributedTotal = 0;

    Object.entries(customerHenMap).forEach(([customerId, data]) => {
      const share = Math.max(1, Math.floor((data.count / activeHens.length) * pool));
      distributedTotal += share;

      newAllocations.push({
        id: `alloc-flock-${nowMs}-${customerId}`,
        customerId,
        customerName: data.name,
        quantity: share,
        allocationType: 'daily_collection',
        date: nowTime,
        timestamp: nowMs,
        batchId: `FLOCK-SWEEP-${shedId.toUpperCase()}`,
        shedName: shedId === 'all' ? 'All Farm Sheds' : sheds.find(s => s.id === shedId)?.name || shedId,
        notes: `Verified daily collection sweep distribution: ${share} eggs allocated to ${data.count} owned hen(s).`,
        verifiedBy: 'Tariq Mahmood (Supervisor)',
      });

      // Notify customer
      const notif: AppNotification = {
        id: `notif-${Date.now()}-${customerId}`,
        userId: customerId,
        title: 'Daily Egg Allocation Recorded',
        message: `Farm supervisors verified today's collection sweep. ${share} egg(s) allocated to your flock. Next 24-hour cycle timer restarted.`,
        date: nowTime,
        read: false,
        type: 'production',
      };
      setNotifications(prev => [notif, ...prev]);

      // Sync egg allocation to Supabase backend
      supabaseAllocateCustomerEggs({
        userId: customerId,
        quantity: share,
        allocationType: 'daily_collection',
        notes: `Flock sweep distribution in shed ${shedId}`,
      });
    });

    setEggAllocations(prev => [...newAllocations, ...prev]);
    triggerEggCycleReset();

    addAudit(
      'Flock Egg Production Allocated',
      'allocation',
      `Distributed ${distributedTotal} verified eggs across ${Object.keys(customerHenMap).length} customer account(s). Shed: ${shedId}.`
    );

    return { 
      success: true, 
      message: `Distributed ${distributedTotal} verified eggs across ${Object.keys(customerHenMap).length} customer account(s)! 24H cycle restarted.` 
    };
  };

  const adjustCustomerEggs = (customerId: string, quantity: number, reason: string) => {
    const cust = customers.find(c => c.id === customerId);
    const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const adjRecord: CustomerEggAllocation = {
      id: `alloc-adj-${Date.now()}`,
      customerId,
      customerName: cust?.name || 'Customer',
      quantity,
      allocationType: 'manual_adjustment',
      date: nowTime,
      timestamp: Date.now(),
      notes: `Audited adjustment: ${reason}`,
      verifiedBy: 'Tariq Mahmood (Operations Lead)',
    };

    setEggAllocations(prev => [adjRecord, ...prev]);

    // Dispatch adjustment to Supabase backend
    supabaseAllocateCustomerEggs({
      userId: customerId,
      quantity,
      allocationType: 'manual_adjustment',
      notes: reason,
    });

    addAudit(
      'Audited Egg Allocation Adjustment',
      'allocation',
      `Adjusted ${quantity} eggs for customer ${cust?.name || customerId}. Reason: ${reason}`
    );
  };


  // --- Customer Withdrawal ---
  const requestWithdrawal = (
    amount: number, 
    method: 'Easypaisa' | 'JazzCash' | 'Bank Transfer', 
    accountTitle: string, 
    accountNumber: string,
    bankName?: string
  ) => {
    if (!currentUser) return { success: false, message: 'Please log in to submit a withdrawal.' };

    // Enforce SINGLE ACTIVE WITHDRAWAL restriction (server & state rule)
    const hasActiveWithdrawal = withdrawals.some(
      w => w.customerId === currentUser.id && (w.status === 'pending' || w.status === 'under_review' || w.status === 'approved')
    );
    if (hasActiveWithdrawal) {
      return { 
        success: false, 
        message: 'You already have an active withdrawal in progress. Under farm treasury guidelines, only one pending/reviewing request is permitted at a time. You can submit another request once your existing request is marked Paid or Rejected.' 
      };
    }

    const minWithdrawal = 500;
    if (amount < minWithdrawal) {
      return { success: false, message: `Minimum withdrawal amount is Rs. ${minWithdrawal.toLocaleString()}.` };
    }

    if (amount > currentUser.withdrawableBalance) {
      return { 
        success: false, 
        message: `Insufficient withdrawable balance. Your balance is Rs. ${currentUser.withdrawableBalance.toFixed(2)}.` 
      };
    }

    // Check if method is enabled in withdrawalSettings
    const activeSetting = withdrawalSettings.find(
      s => s.name.toLowerCase().includes(method.toLowerCase()) || 
           (method === 'Bank Transfer' && s.methodKey === 'bank_transfer') ||
           (method === 'Easypaisa' && s.methodKey === 'easypaisa') ||
           (method === 'JazzCash' && s.methodKey === 'jazzcash')
    );
    if (activeSetting && !activeSetting.isEnabled) {
      return { success: false, message: `${method} is currently disabled for disbursals by farm treasury.` };
    }

    const tempId = `wdr-${Date.now()}`;
    const newReq: WithdrawalRequest = {
      id: tempId,
      customerId: currentUser.id,
      customerName: currentUser.name,
      customerPhone: currentUser.phone,
      amount,
      paymentMethod: method,
      accountTitle: accountTitle.trim(),
      accountNumber: accountNumber.trim(),
      bankName: bankName || (method === 'Bank Transfer' ? 'Commercial Bank' : undefined),
      requestedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'pending',
    };

    setWithdrawals(prev => [newReq, ...prev]);
    setCurrentUser(prev => prev ? { ...prev, withdrawableBalance: prev.withdrawableBalance - amount } : null);
    setCustomers(prev => prev.map(c => c.id === currentUser.id ? { ...c, withdrawableBalance: c.withdrawableBalance - amount } : c));

    // Dispatch to Supabase backend and capture generated UUID
    supabaseCreateWithdrawal({
      userId: currentUser.id,
      customerName: currentUser.name,
      amount,
      withdrawalMethod: method,
      accountHolderName: accountTitle.trim(),
      accountDetails: accountNumber.trim(),
      bankName: bankName || (method === 'Bank Transfer' ? 'Commercial Bank' : undefined),
    }).then(res => {
      if (res && res.withdrawalId) {
        setWithdrawals(prev => prev.map(w => w.id === tempId ? { ...w, id: res.withdrawalId! } : w));
      }
      try {
        localStorage.setItem('fme_request_signal', Date.now().toString());
      } catch {}
      refreshLiveRequests();
    });

    addAudit(
      'Withdrawal Request Submitted',
      'withdrawal',
      `${currentUser.name} requested Rs. ${amount.toLocaleString()} to ${method} (${accountNumber}). Single active lock engaged.`
    );

    return { 
      success: true, 
      message: 'Withdrawal request submitted successfully! Saved directly to Supabase public.withdrawals table.' 
    };
  };

  // --- Admin Withdrawal Process ---
  const processWithdrawal = (
    id: string, 
    action: 'under_review' | 'approve' | 'pay' | 'reject', 
    txRef?: string, 
    adminNotes?: string
  ) => {
    const wdr = withdrawals.find(w => w.id === id || w.accountNumber === id);
    if (!wdr) return;

    const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 16);
    let nextStatus: WithdrawalStatus = 'pending';
    if (action === 'under_review') nextStatus = 'under_review';
    if (action === 'approve') nextStatus = 'approved';
    if (action === 'pay') nextStatus = 'paid';
    if (action === 'reject') nextStatus = 'rejected';

    setWithdrawals(prev => prev.map(w => (w.id === id || w.id === wdr.id) ? {
      ...w,
      status: nextStatus,
      transactionReference: txRef || w.transactionReference || (action === 'pay' ? `TXN-WDR-${Date.now().toString().slice(-6)}` : undefined),
      adminNotes: adminNotes || w.adminNotes || (action === 'pay' ? 'Disbursal executed by treasury' : action === 'under_review' ? 'Verifying beneficiary account' : action === 'approve' ? 'Approved for payment queue' : 'Verification declined'),
      processedAt: nowTime,
    } : w));

    if (action === 'reject') {
      // Refund balance to customer
      setCustomers(prev => prev.map(c => c.id === wdr.customerId ? { ...c, withdrawableBalance: c.withdrawableBalance + wdr.amount } : c));
      if (currentUser && currentUser.id === wdr.customerId) {
        setCurrentUser(prev => prev ? { ...prev, withdrawableBalance: prev.withdrawableBalance + wdr.amount } : null);
      }
    }

    addAudit(
      `Withdrawal ${action.toUpperCase()}`,
      'withdrawal',
      `Processed withdrawal ${wdr.id} (Rs. ${wdr.amount.toLocaleString()} for ${wdr.customerName}). Status -> ${nextStatus}. Ref: ${txRef || 'N/A'}`
    );

    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      userId: wdr.customerId,
      title: action === 'pay' 
        ? 'Withdrawal Disbursed Successfully!' 
        : action === 'under_review' 
          ? 'Withdrawal Under Review' 
          : action === 'approve' 
            ? 'Withdrawal Approved' 
            : 'Withdrawal Declined & Refunded',
      message: action === 'pay'
        ? `Your withdrawal of Rs. ${wdr.amount.toLocaleString()} has been sent to your ${wdr.paymentMethod} (${wdr.accountNumber}). Ref: ${txRef || 'Disbursed'}.`
        : action === 'under_review'
          ? `Your withdrawal request for Rs. ${wdr.amount.toLocaleString()} is currently under verification by farm accounts.`
          : action === 'approve'
            ? `Your withdrawal request of Rs. ${wdr.amount.toLocaleString()} has been approved and queued for bank/wallet dispatch.`
            : `Your withdrawal request for Rs. ${wdr.amount.toLocaleString()} was declined. The amount of Rs. ${wdr.amount.toLocaleString()} has been refunded to your available balance. Note: ${adminNotes || 'Verification failed.'}`,
      date: nowTime,
      read: false,
      type: 'withdrawal',
    };
    setNotifications(prev => [notif, ...prev]);

    // Dispatch status update to Supabase backend using UUID and fallback fields
    supabaseProcessWithdrawal(wdr.id, nextStatus, txRef, wdr.accountNumber, adminNotes, wdr.customerId).then(() => {
      try {
        localStorage.setItem('fme_request_signal', Date.now().toString());
      } catch {}
      refreshLiveRequests();
    });
  };

  // --- Admin Farm Operations ---
  const addHen = (newHenData: Omit<Hen, 'id'>) => {
    const newHen: Hen = {
      ...newHenData,
      id: `hen-${Date.now()}`,
    };
    setHens(prev => [newHen, ...prev]);
    addAudit('Registered Physical Hen', 'hen', `Registered ${newHen.tagCode} (${newHen.breed}) in ${newHen.shedName}.`);
  };

  const updateHenStatus = (id: string, updates: Partial<Hen>) => {
    setHens(prev => prev.map(h => h.id === id ? { ...h, ...updates } : h));
    addAudit('Updated Hen Record', 'hen', `Updated status of hen ${id}: ${JSON.stringify(updates)}`);
  };

  const recordMortality = (id: string, cause: string) => {
    const target = hens.find(h => h.id === id);
    if (!target) return;

    setHens(prev => prev.map(h => h.id === id ? { ...h, healthStatus: 'mortality', status: 'available' } : h));
    addAudit('Recorded Hen Mortality', 'hen', `Mortality recorded for ${target.tagCode} (${target.breed}). Cause: ${cause}`);

    if (target.ownerId) {
      const notif: AppNotification = {
        id: `notif-${Date.now()}`,
        userId: target.ownerId,
        title: `Flock Health Alert: Hen ${target.tagCode}`,
        message: `Hen ${target.tagCode} passed away due to: ${cause}. Our veterinary team is processing replacement under the 60-day Care Custody Agreement.`,
        date: new Date().toISOString().replace('T', ' ').substring(0, 16),
        read: false,
        type: 'health',
      };
      setNotifications(prev => [notif, ...prev]);
    }
  };

  const recordProduction = (entry: Omit<EggProductionRecord, 'id'>) => {
    const newRec: EggProductionRecord = {
      ...entry,
      id: `prod-${Date.now()}`,
    };
    setProductionRecords(prev => [newRec, ...prev]);
    // Reset 24-hour cycle timer on fresh recording
    triggerEggCycleReset();
    addAudit('Recorded Daily Egg Production', 'production', `Collected ${entry.eggsCollected} eggs in ${entry.shedName}. Reset 24H cycle.`);
  };

  const recordEggSale = (sale: Omit<EggSaleRecord, 'id'>) => {
    const newSale: EggSaleRecord = {
      ...sale,
      id: `sale-${Date.now()}`,
    };
    setEggSales(prev => [newSale, ...prev]);
    addAudit('Recorded Wholesale Egg Sale', 'sale', `Sold ${sale.quantityEggs} eggs. Gross: Rs. ${sale.grossAmount.toLocaleString()}.`);
  };

  const recordExpense = (expense: Omit<FarmExpense, 'id'>) => {
    const newExp: FarmExpense = {
      ...expense,
      id: `exp-${Date.now()}`,
    };
    setExpenses(prev => [newExp, ...prev]);
    addAudit('Recorded Farm Operating Expense', 'expense', `Logged ${expense.category} expense of Rs. ${expense.amount.toLocaleString()}.`);
  };

  const runMonthlyAllocation = (cyclePeriod: string) => {
    const grossRev = eggSales.reduce((acc, curr) => acc + curr.grossAmount, 0);
    const totalExp = expenses.reduce((acc, curr) => acc + curr.amount, 0);
    const netIncome = grossRev - totalExp;

    const totalHens = hens.length;
    const customerHens = hens.filter(h => h.status === 'owned');
    if (totalHens === 0) return;

    const grossPerHen = Number((grossRev / totalHens).toFixed(2));
    const costPerHen = Number((totalExp / totalHens).toFixed(2));
    const netBeforeFee = grossPerHen - costPerHen;
    const feePerHen = netBeforeFee > 0 ? Number((netBeforeFee * 0.1).toFixed(2)) : 0;
    const netDistPerHen = Number((netBeforeFee - feePerHen).toFixed(2));

    const newCycle: FinancialCycle = {
      id: `cycle-${Date.now()}`,
      cyclePeriod,
      grossEggRevenue: grossRev,
      totalOperatingExpenses: totalExp,
      netFarmIncome: netIncome,
      totalFlockHens: totalHens,
      customerOwnedHens: customerHens.length,
      grossRevenuePerHen: grossPerHen,
      operatingCostPerHen: costPerHen,
      netDistributionPerHen: netDistPerHen,
      farmManagementFeePct: 10,
      status: 'published',
      publishedDate: new Date().toISOString().split('T')[0],
    };

    setFinancialCycles(prev => [newCycle, ...prev]);

    // Distribute to customer accounts with owned hens
    const customerHenCount: Record<string, { count: number; name: string }> = {};
    customerHens.forEach(h => {
      if (h.ownerId) {
        if (!customerHenCount[h.ownerId]) {
          customerHenCount[h.ownerId] = { count: 0, name: h.ownerName || 'Customer' };
        }
        customerHenCount[h.ownerId].count += 1;
      }
    });

    const newStatements: CustomerStatement[] = Object.entries(customerHenCount).map(([cId, info]) => {
      const netPayable = Number((info.count * netDistPerHen).toFixed(2));
      return {
        id: `stmt-${Date.now()}-${cId}`,
        customerId: cId,
        customerName: info.name,
        cyclePeriod,
        hensOwned: info.count,
        grossRevenueShare: Number((info.count * grossPerHen).toFixed(2)),
        operatingExpenseShare: Number((info.count * costPerHen).toFixed(2)),
        farmManagementFee: Number((info.count * feePerHen).toFixed(2)),
        netPayableAmount: netPayable,
        distributedAt: new Date().toISOString().split('T')[0],
        status: 'credited',
      };
    });

    setCustomerStatements(prev => [...newStatements, ...prev]);

    // Credit balances
    newStatements.forEach(stmt => {
      setCustomers(prev => prev.map(c => c.id === stmt.customerId ? { ...c, withdrawableBalance: c.withdrawableBalance + stmt.netPayableAmount } : c));
      if (currentUser && currentUser.id === stmt.customerId) {
        setCurrentUser(prev => prev ? { ...prev, withdrawableBalance: prev.withdrawableBalance + stmt.netPayableAmount } : null);
      }
    });

    addAudit('Published Financial Statements', 'allocation', `Allocated cycle ${cyclePeriod}. Net/hen: Rs. ${netDistPerHen}. Statements credited.`);
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  // --- Egg Marketplace & Selling Orders (Supabase) ---
  const sellEggsToMarket = (orderPayload: {
    marketId: string;
    quantity: number;
    payoutMethod: 'Bank Transfer' | 'Easypaisa' | 'JazzCash';
    accountHolderName: string;
    bankName?: string;
    accountNumber?: string;
    walletName?: string;
    walletNumber?: string;
  }): { success: boolean; message: string } => {
    if (!currentUser) {
      return { success: false, message: 'Please log in to sell eggs at wholesale mandi rates.' };
    }

    const market = eggMarkets.find(m => m.id === orderPayload.marketId);
    if (!market) {
      return { success: false, message: 'Selected egg market not found.' };
    }

    if (orderPayload.quantity < market.minimumQuantity) {
      return { success: false, message: `Minimum order for ${market.marketName} is ${market.minimumQuantity} eggs.` };
    }

    if (orderPayload.quantity > market.maximumQuantity) {
      return { success: false, message: `Maximum order for ${market.marketName} is ${market.maximumQuantity} eggs.` };
    }

    // Calculate customer available eggs:
    const myAllocs = eggAllocations.filter(a => a.customerId === currentUser.id);
    const totalCollected = myAllocs.reduce((s, a) => s + a.quantity, 0);
    const previousOrders = eggSellingOrders.filter(o => o.userId === currentUser.id && o.orderStatus !== 'rejected');
    const eggsReserved = previousOrders.reduce((s, o) => s + o.eggQuantity, 0);
    const currentAvailableEggs = Math.max(0, totalCollected - eggsReserved);

    if (orderPayload.quantity > currentAvailableEggs) {
      return { 
        success: false, 
        message: `Insufficient eggs available. You have ${currentAvailableEggs} available eggs, requested ${orderPayload.quantity}.` 
      };
    }

    const totalAmount = orderPayload.quantity * market.pricePerEgg;
    const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 16);

    const newOrder: EggSellingOrder = {
      id: `eso-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      marketId: market.id,
      marketName: market.marketName,
      eggQuantity: orderPayload.quantity,
      pricePerEgg: market.pricePerEgg,
      totalAmount: totalAmount,
      payoutMethod: orderPayload.payoutMethod,
      accountHolderName: orderPayload.accountHolderName.trim(),
      bankName: orderPayload.bankName?.trim(),
      accountNumber: orderPayload.accountNumber?.trim(),
      walletName: orderPayload.walletName?.trim(),
      walletNumber: orderPayload.walletNumber?.trim(),
      orderStatus: 'pending',
      createdAt: nowTime,
    };

    setEggSellingOrders(prev => [newOrder, ...prev]);

    // Dispatch to Supabase
    supabaseCreateEggSellingOrder({
      userId: currentUser.id,
      userName: currentUser.name,
      marketId: market.id,
      marketName: market.marketName,
      eggQuantity: orderPayload.quantity,
      pricePerEgg: market.pricePerEgg,
      totalAmount: totalAmount,
      payoutMethod: orderPayload.payoutMethod,
      accountHolderName: orderPayload.accountHolderName.trim(),
      bankName: orderPayload.bankName?.trim(),
      accountNumber: orderPayload.accountNumber?.trim(),
      walletName: orderPayload.walletName?.trim(),
      walletNumber: orderPayload.walletNumber?.trim(),
    });

    addAudit(
      'Egg Selling Order Submitted',
      'sale',
      `Customer ${currentUser.name} placed order to sell ${orderPayload.quantity} eggs to ${market.marketName} for Rs. ${totalAmount.toLocaleString()} via ${orderPayload.payoutMethod}.`
    );

    return { 
      success: true, 
      message: `Order submitted! ${orderPayload.quantity} eggs reserved for ${market.marketName} at Rs. ${market.pricePerEgg}/egg (Total: Rs. ${totalAmount.toLocaleString()}).` 
    };
  };

  const processEggSellingOrder = (
    orderId: string, 
    action: 'paid' | 'rejected' | 'processing', 
    txRef?: string,
    adminNotes?: string
  ) => {
    const target = eggSellingOrders.find(o => o.id === orderId);
    if (!target) return;

    const nowTime = new Date().toISOString().replace('T', ' ').substring(0, 16);

    setEggSellingOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          orderStatus: action,
          processedAt: nowTime,
          txReference: txRef || o.txReference,
          adminNotes: adminNotes || o.adminNotes,
        };
      }
      return o;
    }));

    if (action === 'paid') {
      addAudit(
        'Egg Selling Order Paid',
        'sale',
        `Admin verified and paid order ${orderId} (Rs. ${target.totalAmount.toLocaleString()}) for ${target.userName || target.userId}. Reference: ${txRef || 'Direct Transfer'}.${adminNotes ? ` Notes: ${adminNotes}` : ''}`
      );
    } else if (action === 'rejected') {
      addAudit(
        'Egg Selling Order Rejected',
        'sale',
        `Admin rejected order ${orderId}. ${target.eggQuantity} eggs released back to customer available inventory.${adminNotes ? ` Reason: ${adminNotes}` : ''}`
      );
    }

    supabaseProcessEggSellingOrder(orderId, action, txRef, adminNotes);
  };

  const updateEggMarket = (marketId: string, updates: Partial<EggMarket>) => {
    setEggMarkets(prev => prev.map(m => {
      if (m.id === marketId) {
        return { ...m, ...updates };
      }
      return m;
    }));
    supabaseUpdateEggMarket(marketId, updates);
  };

  const customerAvailableEggs = (customerId: string): number => {
    const myAllocs = eggAllocations.filter(a => a.customerId === customerId);
    const totalCollected = myAllocs.reduce((s, a) => s + a.quantity, 0);
    const previousOrders = eggSellingOrders.filter(o => o.userId === customerId && o.orderStatus !== 'rejected');
    const eggsReserved = previousOrders.reduce((s, o) => s + o.eggQuantity, 0);
    return Math.max(0, totalCollected - eggsReserved);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        customerLogin,
        customerRegister,
        customerPasswordReset,
        customerLogout,
        isAdminAuthenticated,
        adminEmail: AUTHORIZED_ADMIN_EMAIL,
        adminLogin,
        adminLogout,
        isAdminRoute,
        setIsAdminRoute,
        activeView,
        setActiveView,
        adminSection,
        setAdminSection,
        language,
        toggleLanguage,
        hens,
        sheds,
        customers,
        depositSettings,
        depositRequests,
        withdrawalSettings,
        purchases,
        withdrawals,
        productionRecords,
        eggSales,
        expenses,
        financialCycles,
        customerStatements,
        auditLogs,
        notifications,
        lastCollectionCycleTime,
        triggerEggCycleReset,
        createDepositRequest,
        createPurchaseOrder,
        requestWithdrawal,
        processDepositRequest,
        updateDepositSetting,
        updateWithdrawalSetting,
        verifyPurchaseOrder,
        processWithdrawal,
        addHen,
        updateHenStatus,
        recordMortality,
        recordProduction,
        recordEggSale,
        recordExpense,
        runMonthlyAllocation,
        markNotificationRead,
        supportSetting,
        updateSupportSetting,
        eggAllocations,
        availableVerifiedEggs,
        customerAvailableEggs,
        allocateFlockProduction,
        adjustCustomerEggs,
        selectedHenForCertificate,
        setSelectedHenForCertificate,
        purchaseModalOpen,
        setPurchaseModalOpen,
        eggMarkets,
        updateEggMarket,
        eggSellingOrders,
        sellEggsToMarket,
        processEggSellingOrder,
        refreshLiveRequests,
        isRefreshingRequests,
        lastSyncTime,
        resetWebsiteData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
