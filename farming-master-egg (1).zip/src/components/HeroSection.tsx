import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowRight, Shield, Award, Activity, FileText } from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { setActiveView, setPurchaseModalOpen } = useApp();

  return (
    <section className="relative bg-emerald-950 text-white overflow-hidden">
      {/* Background Hero Image with measured scrim for WCAG AA 4.5:1 legibility */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_poultry_farm_1793810684299.jpg"
          alt="Modern poultry layer farm in green rolling countryside"
          className="w-full h-full object-cover object-center filter brightness-90"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-950/95 via-emerald-950/80 to-emerald-950/50" />
        <div className="absolute inset-0 bg-gradient-to-t from-emerald-950 via-transparent to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20 sm:pt-24 sm:pb-28">
        <div className="max-w-3xl space-y-6">
          
          {/* Unboxed natural kicker */}
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-300">
            <span>Punjab Poultry Corridor</span>
            <span aria-hidden="true">·</span>
            <span>Physical Agricultural Asset</span>
            <span aria-hidden="true">·</span>
            <span>Zero-Gimmick Contract</span>
          </div>

          {/* Display Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold font-display tracking-tight text-white leading-tight text-balance">
            Real Farming. <br className="hidden sm:inline" />
            Real Hens. Real Eggs.
          </h1>

          {/* Concrete Proposition */}
          <p className="text-base sm:text-lg text-emerald-100/90 leading-relaxed max-w-2xl">
            Acquire actual, registered layer hens at <strong className="text-white font-semibold">Rs. 500 per hen</strong>, 
            professionally cared for at our biosecure farm. Track daily egg collection logs, inspect wholesale market sales receipts, 
            and receive transparent monthly distributions net of feed and veterinary care.
          </p>

          {/* Clear Disclaimer callout */}
          <div className="p-3.5 bg-emerald-900/60 border border-emerald-700/60 rounded-lg text-xs text-emerald-200 flex items-start gap-2.5 max-w-2xl">
            <Shield className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">Genuine Livestock Undertaking: </span>
              This is not a high-yield or fixed-return scheme. Hen laying curves, feed prices, and egg market rates fluctuate naturally. 
              Distributions are derived exclusively from actual verified egg sales.
            </div>
          </div>

          {/* Action CTAs */}
          <div className="pt-2 flex flex-wrap items-center gap-4">
            <button
              onClick={() => setActiveView('marketplace')}
              className="flex items-center gap-2 px-6 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold text-sm rounded-lg transition-all shadow-md hover:shadow-lg whitespace-nowrap shrink-0"
            >
              <span>Explore Available Hens (Rs. 500)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => setActiveView('transparency')}
              className="flex items-center gap-2 px-5 py-3.5 bg-white/10 hover:bg-white/15 text-white font-semibold text-sm rounded-lg border border-white/20 transition-all backdrop-blur-xs whitespace-nowrap shrink-0"
            >
              <Activity className="w-4 h-4 text-emerald-300" />
              <span>View Live Farm Records</span>
            </button>
          </div>
        </div>

        {/* 4-Item KPI Strip */}
        <div className="mt-16 pt-8 border-t border-emerald-800/60 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="space-y-1">
            <span className="text-xs text-emerald-300 block">Initial Hen Price</span>
            <span className="text-2xl font-bold font-display text-white tabular-nums">Rs. 500</span>
            <p className="text-[11px] text-emerald-300/80">Physical layer bird under custody</p>
          </div>

          <div className="space-y-1">
            <span className="text-xs text-emerald-300 block">Current Farm Flock</span>
            <span className="text-2xl font-bold font-display text-white tabular-nums">5,240 Hens</span>
            <p className="text-[11px] text-emerald-300/80">Across 3 climate-managed sheds</p>
          </div>

          <div className="space-y-1">
            <span className="text-xs text-emerald-300 block">Daily Average Laying Rate</span>
            <span className="text-2xl font-bold font-display text-white tabular-nums">84.2%</span>
            <p className="text-[11px] text-emerald-300/80">Verifiable morning & afternoon logs</p>
          </div>

          <div className="space-y-1">
            <span className="text-xs text-emerald-300 block">Care & Custody Fee</span>
            <span className="text-2xl font-bold font-display text-white tabular-nums">10% Net</span>
            <p className="text-[11px] text-emerald-300/80">Deducted only from net positive yields</p>
          </div>
        </div>
      </div>
    </section>
  );
};
