import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Menu, X, ArrowUpRight, User, LogOut, Globe } from 'lucide-react';
import { PublicActiveView } from '../types';

export const Header: React.FC = () => {
  const { 
    activeView, 
    setActiveView, 
    currentUser, 
    customerLogout, 
    setPurchaseModalOpen,
    language,
    toggleLanguage 
  } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigate = (view: PublicActiveView) => {
    setActiveView(view);
    setMobileMenuOpen(false);
  };

  return (
    <header className="bg-white/95 backdrop-blur-md border-b border-emerald-950/10 sticky top-0 z-40 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          
          {/* Zone 1: Single text element wordmark */}
          <button
            onClick={() => navigate('home')}
            className="text-left whitespace-nowrap shrink-0 focus-visible:outline-hidden"
          >
            <span className="text-xl font-bold font-display tracking-tight text-emerald-950">
              FARMING MASTER EGG
            </span>
          </button>

          {/* Zone 2: 4-5 concise single-line nav links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-emerald-950/80">
            <button
              onClick={() => navigate('marketplace')}
              className={`whitespace-nowrap transition-colors hover:text-emerald-700 py-1 ${
                activeView === 'marketplace' ? 'text-emerald-800 font-semibold border-b-2 border-emerald-700' : ''
              }`}
            >
              Available Hens (Rs. 500)
            </button>

            <button
              onClick={() => navigate('how-it-works')}
              className={`whitespace-nowrap transition-colors hover:text-emerald-700 py-1 ${
                activeView === 'how-it-works' ? 'text-emerald-800 font-semibold border-b-2 border-emerald-700' : ''
              }`}
            >
              How It Works
            </button>

            <button
              onClick={() => navigate('about')}
              className={`whitespace-nowrap transition-colors hover:text-emerald-700 py-1 ${
                activeView === 'about' ? 'text-emerald-800 font-semibold border-b-2 border-emerald-700' : ''
              }`}
            >
              Our Poultry Farm
            </button>

            <button
              onClick={() => navigate('transparency')}
              className={`whitespace-nowrap transition-colors hover:text-emerald-700 py-1 ${
                activeView === 'transparency' ? 'text-emerald-800 font-semibold border-b-2 border-emerald-700' : ''
              }`}
            >
              Transparency & Reports
            </button>

            <button
              onClick={() => navigate('faqs')}
              className={`whitespace-nowrap transition-colors hover:text-emerald-700 py-1 ${
                activeView === 'faqs' ? 'text-emerald-800 font-semibold border-b-2 border-emerald-700' : ''
              }`}
            >
              FAQs
            </button>
          </nav>

          {/* Zone 3: 1 primary action / User profile action */}
          <div className="flex items-center gap-3 shrink-0">
            
            {/* Language toggle */}
            <button
              onClick={toggleLanguage}
              className="hidden lg:flex items-center gap-1 text-xs text-stone-500 hover:text-emerald-900 px-2 py-1 rounded transition-colors"
              title="Toggle language"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{language === 'en' ? 'اردو' : 'EN'}</span>
            </button>

            {currentUser ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate('customer-dashboard')}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-800 hover:bg-emerald-900 rounded-lg transition-colors whitespace-nowrap shadow-xs"
                >
                  <User className="w-3.5 h-3.5" />
                  <span>My Dashboard</span>
                </button>
                <button
                  onClick={customerLogout}
                  className="p-2 text-stone-500 hover:text-red-700 transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate('customer-login')}
                  className="px-3 py-2 text-xs font-semibold text-emerald-950 hover:text-emerald-800 transition-colors whitespace-nowrap"
                >
                  Sign In
                </button>
                <button
                  onClick={() => navigate('customer-register')}
                  className="flex items-center gap-1 px-3.5 py-2 text-xs font-bold text-white bg-emerald-800 hover:bg-emerald-900 rounded-lg transition-colors whitespace-nowrap shadow-xs"
                >
                  <span>Register</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Mobile hamburger toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-emerald-950 hover:text-emerald-700 rounded-lg focus:outline-hidden"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile navigation drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-emerald-950/10 px-4 pt-3 pb-5 space-y-2">
          <button
            onClick={() => navigate('marketplace')}
            className="block w-full text-left py-2 px-3 text-sm font-medium rounded-md text-emerald-950 hover:bg-emerald-50"
          >
            Available Hens (Rs. 500)
          </button>
          <button
            onClick={() => navigate('how-it-works')}
            className="block w-full text-left py-2 px-3 text-sm font-medium rounded-md text-emerald-950 hover:bg-emerald-50"
          >
            How Hen Ownership Works
          </button>
          <button
            onClick={() => navigate('about')}
            className="block w-full text-left py-2 px-3 text-sm font-medium rounded-md text-emerald-950 hover:bg-emerald-50"
          >
            Our Poultry Farm
          </button>
          <button
            onClick={() => navigate('facilities')}
            className="block w-full text-left py-2 px-3 text-sm font-medium rounded-md text-emerald-950 hover:bg-emerald-50"
          >
            Sheds & Infrastructure
          </button>
          <button
            onClick={() => navigate('production-process')}
            className="block w-full text-left py-2 px-3 text-sm font-medium rounded-md text-emerald-950 hover:bg-emerald-50"
          >
            Egg Production Flow
          </button>
          <button
            onClick={() => navigate('transparency')}
            className="block w-full text-left py-2 px-3 text-sm font-medium rounded-md text-emerald-950 hover:bg-emerald-50"
          >
            Farm Transparency & Mandi Reports
          </button>
          <button
            onClick={() => navigate('gallery')}
            className="block w-full text-left py-2 px-3 text-sm font-medium rounded-md text-emerald-950 hover:bg-emerald-50"
          >
            Farm Photography Gallery
          </button>
          <button
            onClick={() => navigate('faqs')}
            className="block w-full text-left py-2 px-3 text-sm font-medium rounded-md text-emerald-950 hover:bg-emerald-50"
          >
            FAQs & Agricultural Risks
          </button>
          <button
            onClick={() => navigate('contact')}
            className="block w-full text-left py-2 px-3 text-sm font-medium rounded-md text-emerald-950 hover:bg-emerald-50"
          >
            Contact & Visiting Appointments
          </button>

          <div className="pt-3 border-t border-stone-100 flex flex-col gap-2">
            {currentUser ? (
              <button
                onClick={() => navigate('customer-dashboard')}
                className="w-full text-center py-2.5 px-4 text-xs font-bold text-white bg-emerald-800 rounded-lg hover:bg-emerald-900"
              >
                Go to Customer Dashboard
              </button>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => navigate('customer-login')}
                  className="py-2 px-3 text-xs font-semibold border border-stone-200 text-stone-700 rounded-lg text-center"
                >
                  Customer Sign In
                </button>
                <button
                  onClick={() => navigate('customer-register')}
                  className="py-2 px-3 text-xs font-bold bg-emerald-800 text-white rounded-lg text-center"
                >
                  Create Account
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
