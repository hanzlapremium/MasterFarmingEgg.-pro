import React from 'react';
import { 
  ArrowDownCircle, 
  ArrowUpCircle, 
  ShoppingBag, 
  Egg, 
  Layers, 
  CheckCircle2 
} from 'lucide-react';
import { DepositRequest, WithdrawalRequest, PurchaseOrder, Hen, EggProductionRecord } from '../../types';

import { useApp } from '../../context/AppContext';

interface StatsOverviewSectionProps {
  depositRequests: DepositRequest[];
  withdrawals: WithdrawalRequest[];
  purchases: PurchaseOrder[];
  myHens: Hen[];
  productionRecords: EggProductionRecord[];
  onCardClick?: (target: string) => void;
}

export const StatsOverviewSection: React.FC<StatsOverviewSectionProps> = ({
  depositRequests,
  withdrawals,
  purchases,
  myHens,
  productionRecords,
  onCardClick,
}) => {
  const { eggAllocations, eggSellingOrders, currentUser } = useApp();

  // 1. Pending Deposits
  const pendingDeposits = depositRequests.filter(d => d.status === 'pending');
  const pendingDepositAmount = pendingDeposits.reduce((sum, d) => sum + d.amount, 0);

  // 2. Pending Egg Sell Payout Orders
  const pendingEggSellOrders = eggSellingOrders.filter(o => o.userId === currentUser?.id && (o.orderStatus === 'pending' || o.orderStatus === 'processing'));
  const pendingEggSellAmount = pendingEggSellOrders.reduce((sum, o) => sum + o.totalAmount, 0);

  // 3. Pending Purchases
  const pendingPurchases = purchases.filter(p => p.status === 'pending');
  const pendingPurchaseAmount = pendingPurchases.reduce((sum, p) => sum + p.totalAmount, 0);

  // 4. Customer Verified Eggs & Available Balance
  const myAllocs = eggAllocations.filter(a => a.customerId === currentUser?.id);
  const totalCustomerEggs = myAllocs.reduce((sum, a) => sum + a.quantity, 0);
  const mySellingOrders = eggSellingOrders.filter(o => o.userId === currentUser?.id && o.orderStatus !== 'rejected');
  const eggsReserved = mySellingOrders.reduce((sum, o) => sum + o.eggQuantity, 0);
  const availableEggs = Math.max(0, totalCustomerEggs - eggsReserved);

  // 5. Total Hens
  const activeHensCount = myHens.length;
  const healthyLayersCount = myHens.filter(h => h.healthStatus === 'healthy').length;

  // 6. Total Completed Egg Sell Payouts (Successfully Paid)
  const paidEggSellOrders = eggSellingOrders.filter(o => o.userId === currentUser?.id && o.orderStatus === 'paid');
  const totalEggSellPaidAmount = paidEggSellOrders.reduce((sum, o) => sum + o.totalAmount, 0);

  const stats = [
    {
      id: 'deposit',
      title: 'PENDING DEPOSIT',
      value: `Rs. ${pendingDepositAmount.toLocaleString()}`,
      subtext: `${pendingDeposits.length} Request${pendingDeposits.length === 1 ? '' : 's'} Pending`,
      icon: <ArrowDownCircle className="w-5 h-5 text-amber-600" />,
      bgBadge: 'bg-amber-50 text-amber-800 border-amber-200',
      borderAccent: 'border-l-4 border-l-amber-500',
    },
    {
      id: 'sell-eggs',
      title: 'PENDING EGG SELL',
      value: `Rs. ${pendingEggSellAmount.toLocaleString()}`,
      subtext: `${pendingEggSellOrders.length} Request${pendingEggSellOrders.length === 1 ? '' : 's'} In Process`,
      icon: <ArrowUpCircle className="w-5 h-5 text-teal-600" />,
      bgBadge: 'bg-teal-50 text-teal-800 border-teal-200',
      borderAccent: 'border-l-4 border-l-teal-600',
    },
    {
      id: 'purchases',
      title: 'PENDING PURCHASE',
      value: `Rs. ${pendingPurchaseAmount.toLocaleString()}`,
      subtext: `${pendingPurchases.length} Order${pendingPurchases.length === 1 ? '' : 's'} Awaiting Verification`,
      icon: <ShoppingBag className="w-5 h-5 text-orange-600" />,
      bgBadge: 'bg-orange-50 text-orange-800 border-orange-200',
      borderAccent: 'border-l-4 border-l-orange-500',
    },
    {
      id: 'sell-eggs',
      title: 'AVAILABLE EGGS',
      value: `${availableEggs.toLocaleString()} Eggs`,
      subtext: totalCustomerEggs > 0 
        ? `${totalCustomerEggs} Total Credited (${eggsReserved > 0 ? `${eggsReserved} Reserved` : 'Ready to Sell'})` 
        : 'Acquire Hens to Receive Eggs (1 hen = 1 egg)',
      icon: <Egg className="w-5 h-5 text-amber-500" />,
      bgBadge: 'bg-yellow-50 text-yellow-900 border-yellow-200',
      borderAccent: 'border-l-4 border-l-yellow-400',
    },
    {
      id: 'my-hens',
      title: 'TOTAL HENS',
      value: `${activeHensCount} Hen${activeHensCount === 1 ? '' : 's'}`,
      subtext: activeHensCount > 0 ? `${healthyLayersCount} Active Laying Birds` : 'No Hens Registered',
      icon: <Layers className="w-5 h-5 text-emerald-700" />,
      bgBadge: 'bg-emerald-50 text-emerald-900 border-emerald-200',
      borderAccent: 'border-l-4 border-l-emerald-600',
    },
    {
      id: 'sell-eggs',
      title: 'EGG SELL PAYOUTS',
      value: `Rs. ${totalEggSellPaidAmount.toLocaleString()}`,
      subtext: `${paidEggSellOrders.length} Disbursed Settlement${paidEggSellOrders.length === 1 ? '' : 's'}`,
      icon: <CheckCircle2 className="w-5 h-5 text-emerald-600" />,
      bgBadge: 'bg-emerald-50 text-emerald-900 border-emerald-200',
      borderAccent: 'border-l-4 border-l-emerald-500',
    },
  ];

  return (
    <div className="mb-8 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm sm:text-base font-bold font-display text-emerald-950 uppercase tracking-wider">
            STATS OVERVIEW
          </h2>
          <p className="text-xs text-stone-500">
            Real-time verified agricultural records from farm books.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {stats.map(st => (
          <div
            key={st.title}
            onClick={() => onCardClick?.(st.id)}
            className={`bg-white rounded-2xl p-4 sm:p-5 border border-emerald-950/10 shadow-xs hover:shadow-md transition-all duration-200 ${st.borderAccent} cursor-pointer group flex flex-col justify-between`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold tracking-wider text-stone-500 uppercase font-sans">
                {st.title}
              </span>
              <div className="w-9 h-9 rounded-xl bg-stone-50 group-hover:bg-stone-100 flex items-center justify-center transition-colors">
                {st.icon}
              </div>
            </div>

            <div className="space-y-1">
              <div className="text-xl sm:text-2xl font-bold font-display text-emerald-950 font-mono tracking-tight tabular-nums">
                {st.value}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-stone-500">
                <span className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-semibold border ${st.bgBadge}`}>
                  {st.subtext}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
