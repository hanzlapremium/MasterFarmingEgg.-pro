import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Egg, 
  Activity, 
  ShoppingBag, 
  AlertTriangle, 
  Calendar, 
  Clock, 
  CheckCircle,
  Building2,
  TrendingUp,
  Info,
  Layers,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  FileText,
  Store
} from 'lucide-react';
import { EggProductionRecord, EggSaleRecord, Hen } from '../../types';
import { EggMarketplaceView } from './EggMarketplaceView';

interface EggCollectionViewProps {
  productionRecords: EggProductionRecord[];
  eggSales: EggSaleRecord[];
  myHens: Hen[];
}

export const EggCollectionView: React.FC<EggCollectionViewProps> = ({
  productionRecords,
  eggSales,
  myHens,
}) => {
  const { 
    currentUser, 
    eggAllocations, 
    eggSellingOrders,
    customerAvailableEggs,
    lastCollectionCycleTime, 
    availableVerifiedEggs 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'daily' | 'weekly' | 'allocations'>('all');
  const [activeSubView, setActiveSubView] = useState<'collection' | 'marketplace'>('collection');

  // Live 24-Hour Countdown Timer
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const cycleDurationMs = 24 * 60 * 60 * 1000;
  const elapsedMs = Math.max(0, now - lastCollectionCycleTime);
  const remainingMs = Math.max(0, cycleDurationMs - (elapsedMs % cycleDurationMs));
  const isCollectionDue = remainingMs <= 0 || (elapsedMs > cycleDurationMs && productionRecords.length === 0);

  const hours = Math.floor(remainingMs / (1000 * 60 * 60));
  const minutes = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((remainingMs % (1000 * 60)) / 1000);
  const formattedCountdown = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const nextCollectionDate = new Date(lastCollectionCycleTime + cycleDurationMs);
  const nextCollectionTimeStr = nextCollectionDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Customer Specific Egg Metrics
  const myAllocations = useMemo(() => {
    if (!currentUser) return [];
    return eggAllocations.filter(a => a.customerId === currentUser.id);
  }, [eggAllocations, currentUser]);

  const initialEggsAllocated = useMemo(() => {
    return myAllocations
      .filter(a => a.allocationType === 'initial_purchase')
      .reduce((sum, a) => sum + a.quantity, 0);
  }, [myAllocations]);

  const totalCustomerEggsCollected = useMemo(() => {
    return myAllocations.reduce((sum, a) => sum + a.quantity, 0);
  }, [myAllocations]);

  const customerOwnedHensCount = myHens.length;

  // Customer real-time marketplace orders and verified available eggs
  const eggsReservedInOrders = useMemo(() => {
    if (!currentUser) return 0;
    return eggSellingOrders
      .filter(o => o.userId === currentUser.id && o.orderStatus !== 'rejected')
      .reduce((sum, o) => sum + o.eggQuantity, 0);
  }, [eggSellingOrders, currentUser]);

  const customerEggsSold = useMemo(() => {
    if (!currentUser) return 0;
    return eggSellingOrders
      .filter(o => o.userId === currentUser.id && o.orderStatus === 'paid')
      .reduce((sum, o) => sum + o.eggQuantity, 0);
  }, [eggSellingOrders, currentUser]);

  const availableEggBalance = Math.max(0, totalCustomerEggsCollected - eggsReservedInOrders);

  // Overall Farm Totals
  const totalFarmCollected = productionRecords.reduce((sum, r) => sum + r.eggsCollected, 0);
  const totalFarmDamaged = productionRecords.reduce((sum, r) => sum + r.eggsDamaged, 0);
  const totalFarmSold = eggSales.reduce((sum, s) => sum + s.quantityEggs, 0);

  // Filtered Production Records (Daily / Weekly / All)
  const filteredRecords = useMemo(() => {
    const nowDate = new Date();
    return productionRecords.filter(rec => {
      const recDate = new Date(rec.date);
      const diffDays = (nowDate.getTime() - recDate.getTime()) / (1000 * 3600 * 24);

      if (activeTab === 'daily') return diffDays <= 1;
      if (activeTab === 'weekly') return diffDays <= 7;
      return true;
    });
  }, [productionRecords, activeTab]);

  if (activeSubView === 'marketplace') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActiveSubView('collection')}
            className="px-4 py-2 bg-white hover:bg-stone-50 border border-stone-200 text-stone-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            ← Back to Egg Production Sweeps & Countdown
          </button>
        </div>
        <EggMarketplaceView onBackToCollection={() => setActiveSubView('collection')} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-emerald-950/10 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 uppercase tracking-widest mb-1">
            <Egg className="w-4 h-4 text-emerald-700" />
            <span>Farming Master Egg · Production Ledger</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-emerald-950 tracking-tight">
            EGG DASHBOARD
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Real-time physical egg balances, initial allocations, and 24-hour collection sweep countdown.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 self-start md:self-auto">
          <button
            onClick={() => setActiveSubView('marketplace')}
            className="px-4 py-2.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-600 hover:to-orange-600 text-white rounded-2xl text-xs font-bold flex items-center gap-2 shadow-sm transition-all cursor-pointer"
          >
            <Store className="w-4 h-4 text-white" />
            <span>Sell Eggs at Mandi (Rs. 40 - 60)</span>
          </button>

          <div className="px-3.5 py-2 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <div>
              <span className="text-[10px] uppercase font-bold text-emerald-900 block">Farm Inventory Pool</span>
              <span className="font-mono font-bold text-emerald-950">{availableVerifiedEggs.toLocaleString()} Verified Eggs</span>
            </div>
          </div>
        </div>
      </div>

      {/* 6 Key Core Metrics Cards (Requirement 6) */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        
        {/* Card 1: Total Hens Owned */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs text-stone-500 font-semibold uppercase">
            <span>Total Hens</span>
            <Layers className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="text-2xl font-bold font-display text-emerald-950 font-mono tabular-nums">
            {customerOwnedHensCount}
          </div>
          <div className="text-[11px] text-stone-500">
            Active Layer Birds
          </div>
        </div>

        {/* Card 2: Initial Eggs Allocated */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-amber-500/20 shadow-xs space-y-1 bg-gradient-to-b from-amber-50/40 to-white">
          <div className="flex items-center justify-between text-xs text-amber-700 font-semibold uppercase">
            <span>Initial Eggs</span>
            <Sparkles className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold font-display text-amber-900 font-mono tabular-nums">
            {initialEggsAllocated}
          </div>
          <div className="text-[11px] text-amber-800 font-medium">
            Immediate Verified Stock
          </div>
        </div>

        {/* Card 3: Total Eggs Collected */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs text-stone-500 font-semibold uppercase">
            <span>Eggs Collected</span>
            <Egg className="w-4 h-4 text-emerald-800" />
          </div>
          <div className="text-2xl font-bold font-display text-emerald-950 font-mono tabular-nums">
            {totalCustomerEggsCollected}
          </div>
          <div className="text-[11px] text-stone-500">
            Initial + Daily Sweeps
          </div>
        </div>

        {/* Card 4: Available Egg Balance */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-emerald-600/30 shadow-xs space-y-1 bg-gradient-to-b from-emerald-50/50 to-white">
          <div className="flex items-center justify-between text-xs text-emerald-700 font-semibold uppercase">
            <span>Egg Balance</span>
            <CheckCircle className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-display text-emerald-900 font-mono tabular-nums">
            {availableEggBalance}
          </div>
          <div className="text-[11px] text-emerald-800 font-medium">
            Ready for Disbursal
          </div>
        </div>

        {/* Card 5: Eggs Sold */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs text-stone-500 font-semibold uppercase">
            <span>Eggs Sold</span>
            <ShoppingBag className="w-4 h-4 text-teal-700" />
          </div>
          <div className="text-2xl font-bold font-display text-stone-800 font-mono tabular-nums">
            {customerEggsSold}
          </div>
          <div className="text-[11px] text-stone-500">
            Wholesale Mandi Share
          </div>
        </div>

        {/* Card 6: Next Collection Time */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs text-stone-500 font-semibold uppercase">
            <span>Next Sweep</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-bold font-display text-emerald-950 font-mono">
            {nextCollectionTimeStr}
          </div>
          <div className="text-[11px] text-stone-500">
            24H Farm Schedule
          </div>
        </div>

      </div>

      {/* Live 24-Hour Countdown Interface (Requirement 5 & 6) */}
      <div className="bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-950 text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-emerald-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-800/80 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-800/80 border border-emerald-700 flex items-center justify-center text-emerald-300 shadow-xs">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 block font-sans">
                Automatic 24-Hour Collection Cycle
              </span>
              <span className="text-base font-bold font-display text-white">
                Next Expected Egg Collection Countdown
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-emerald-300">Expected Sweep Time:</span>
            <span className="text-xs font-mono font-bold text-amber-300 bg-emerald-950 px-2.5 py-1 rounded-lg border border-emerald-800">
              {nextCollectionTimeStr} PKT
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
          <div className="lg:col-span-2 space-y-2">
            <div className="text-xs text-emerald-200 font-medium">
              Live Scheduled Timer:
            </div>
            {isCollectionDue ? (
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500 text-emerald-950 font-bold rounded-xl text-base shadow-sm">
                <AlertTriangle className="w-5 h-5" />
                <span>Collection Due — Farm Staff Logging Tally Sweeps</span>
              </div>
            ) : (
              <div className="flex items-baseline gap-3">
                <span className="text-4xl sm:text-5xl font-bold font-mono text-emerald-100 tracking-wider">
                  {formattedCountdown}
                </span>
                <span className="text-xs sm:text-sm text-emerald-300 font-mono">
                  (HH:MM:SS)
                </span>
              </div>
            )}
            <p className="text-xs text-emerald-300/80 leading-relaxed pt-1">
              * The timer represents the expected collection schedule at the Mandra-Chakwal facility. Real-farm biological production varies; actual eggs are credited strictly upon physical tally and supervisor logging.
            </p>
          </div>

          <div className="bg-emerald-900/60 border border-emerald-800 rounded-2xl p-4 text-xs text-emerald-200 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-emerald-300">Your Active Flock:</span>
              <span className="font-mono font-bold text-white text-sm">{customerOwnedHensCount} Hens</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-emerald-300">Initial Allocation:</span>
              <span className="font-mono font-bold text-amber-300 text-sm">{initialEggsAllocated} Eggs</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-emerald-300">Collection Status:</span>
              <span className="text-emerald-400 font-semibold">{isCollectionDue ? 'Due for Recording' : 'Active Cycle'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Production History Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-stone-200 pb-2 overflow-x-auto text-xs font-semibold">
        {[
          { id: 'all', label: `All Sweeps (${productionRecords.length})` },
          { id: 'daily', label: 'Daily History (Last 24h)' },
          { id: 'weekly', label: 'Weekly History (Last 7d)' },
          { id: 'allocations', label: `My Egg Allocations (${myAllocations.length})` },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              activeTab === tab.id
                ? 'bg-emerald-800 text-white font-bold shadow-xs'
                : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* VIEW A: Customer's Personal Allocations Ledger */}
      {activeTab === 'allocations' && (
        <div className="bg-white rounded-3xl border border-emerald-950/10 shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-50/70 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-base text-emerald-950 font-display">
                Your Personal Egg Allocation History ({myAllocations.length})
              </h3>
              <p className="text-xs text-stone-500">
                Direct credits from initial purchases and verified daily farm flock sweeps.
              </p>
            </div>
          </div>

          {myAllocations.length === 0 ? (
            <div className="py-16 text-center text-xs text-stone-500 space-y-2">
              <Egg className="w-10 h-10 text-stone-300 mx-auto" />
              <p className="font-semibold text-stone-700">No egg allocations recorded yet.</p>
              <p>Acquire physical hens or await supervisor logging of daily collection sweeps.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                    <th className="p-3.5">Allocation ID</th>
                    <th className="p-3.5">Date & Time</th>
                    <th className="p-3.5">Type</th>
                    <th className="p-3.5">Source / Batch</th>
                    <th className="p-3.5">Allocated Quantity</th>
                    <th className="p-3.5">Verified By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {myAllocations.map(alloc => (
                    <tr key={alloc.id} className="hover:bg-stone-50/80 transition-colors">
                      <td className="p-3.5 font-bold text-emerald-950 font-mono text-[11px]">{alloc.id}</td>
                      <td className="p-3.5 font-sans text-stone-700">{alloc.date}</td>
                      <td className="p-3.5 font-sans">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          alloc.allocationType === 'initial_purchase'
                            ? 'bg-amber-100 text-amber-900 border border-amber-300'
                            : alloc.allocationType === 'daily_collection'
                            ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                            : 'bg-teal-100 text-teal-900 border border-teal-300'
                        }`}>
                          {alloc.allocationType === 'initial_purchase' ? 'Initial Purchase' : alloc.allocationType === 'daily_collection' ? 'Daily Collection' : 'Adjustment'}
                        </span>
                      </td>
                      <td className="p-3.5 font-sans text-stone-800 text-[11px]">
                        {alloc.shedName || 'Verified Farm Harvest'}
                      </td>
                      <td className="p-3.5 font-bold text-emerald-900 text-sm tabular-nums">
                        +{alloc.quantity} Eggs
                      </td>
                      <td className="p-3.5 font-sans text-stone-600 text-[11px]">{alloc.verifiedBy}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* VIEW B: Farm-Wide Verified Production Sweeps Table */}
      {activeTab !== 'allocations' && (
        <div className="bg-white rounded-3xl border border-emerald-950/10 shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-base text-emerald-950 font-display">
                Farm Collection Sweeps ({filteredRecords.length})
              </h3>
              <p className="text-xs text-stone-500">
                Audited batch production recorded by physical farm staff across Mandra-Chakwal layer sheds.
              </p>
            </div>
          </div>

          {filteredRecords.length === 0 ? (
            <div className="py-16 text-center text-xs text-stone-500 space-y-2">
              <Egg className="w-10 h-10 text-stone-300 mx-auto" />
              <p className="font-semibold text-stone-700">No sweeps found for this filter interval.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                    <th className="p-3.5">Batch ID</th>
                    <th className="p-3.5">Date</th>
                    <th className="p-3.5">Shed</th>
                    <th className="p-3.5">Flock Count</th>
                    <th className="p-3.5">Total Collected</th>
                    <th className="p-3.5">Damaged / Cull</th>
                    <th className="p-3.5">Saleable Output</th>
                    <th className="p-3.5">Laying %</th>
                    <th className="p-3.5">Your Pro-Rata Share</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {filteredRecords.map(rec => {
                    const myShare = customerOwnedHensCount > 0 && rec.flockSize > 0
                      ? ((customerOwnedHensCount / rec.flockSize) * rec.eggsAvailableForSale).toFixed(2)
                      : '0.00';

                    return (
                      <tr key={rec.id} className="hover:bg-stone-50/80 transition-colors">
                        <td className="p-3.5 font-bold text-emerald-950 font-mono">{rec.id}</td>
                        <td className="p-3.5 font-sans text-stone-700">{rec.date}</td>
                        <td className="p-3.5 font-sans text-stone-900 font-medium">{rec.shedName.split('-')[0]}</td>
                        <td className="p-3.5 text-stone-600">{rec.flockSize.toLocaleString()}</td>
                        <td className="p-3.5 font-bold text-stone-900 tabular-nums">{rec.eggsCollected.toLocaleString()}</td>
                        <td className="p-3.5 text-rose-700 tabular-nums">{rec.eggsDamaged}</td>
                        <td className="p-3.5 font-bold text-emerald-900 tabular-nums">{rec.eggsAvailableForSale.toLocaleString()}</td>
                        <td className="p-3.5 font-sans">
                          <span className="bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded text-[11px] font-semibold border border-emerald-200">
                            {rec.layingPercentage}%
                          </span>
                        </td>
                        <td className="p-3.5 font-sans font-bold text-emerald-900 text-xs">
                          {myShare} Eggs
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Transparency Note */}
      <div className="bg-emerald-50/80 rounded-2xl p-4 sm:p-5 border border-emerald-200 text-xs text-emerald-950 space-y-2">
        <div className="flex items-center gap-2 font-bold text-sm">
          <Info className="w-4 h-4 text-emerald-800 shrink-0" />
          <span>Agricultural Custody & Verification Standards</span>
        </div>
        <p className="text-stone-700 leading-relaxed">
          Farming Master Egg maintains zero artificial computer multipliers or fabricated returns. 
          When you acquire layer hens, initial eggs are reserved strictly from verified physical inventory currently stored in climate-controlled egg holding rooms. 
          Subsequent allocations occur in accordance with daily morning and evening collection sweeps recorded by on-site supervisors.
        </p>
      </div>

    </div>
  );
};
