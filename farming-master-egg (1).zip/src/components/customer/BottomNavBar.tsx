import React from 'react';
import { 
  Home, 
  Store, 
  Egg, 
  FileText, 
  LogOut 
} from 'lucide-react';

interface BottomNavBarProps {
  activeTab: string;
  onSelectTab: (tab: any) => void;
  onLogout: () => void;
  unreadCount?: number;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  onSelectTab,
  onLogout,
}) => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-emerald-950/10 shadow-[0_-4px_20px_rgba(0,0,0,0.06)] px-2 py-1.5 flex items-center justify-around text-[10px] font-semibold text-stone-600">
      
      {/* 1. Home */}
      <button
        onClick={() => onSelectTab('overview')}
        className={`flex flex-col items-center gap-1 py-1 px-2.5 transition-colors ${
          activeTab === 'overview' ? 'text-emerald-800 font-bold' : 'hover:text-stone-900'
        }`}
      >
        <Home className={`w-5 h-5 ${activeTab === 'overview' ? 'text-emerald-800' : 'text-stone-500'}`} />
        <span>Home</span>
      </button>

      {/* 2. Egg Sell (Market & Payout) */}
      <button
        onClick={() => onSelectTab('sell-eggs')}
        className={`flex flex-col items-center gap-1 py-1 px-2.5 transition-colors cursor-pointer ${
          activeTab === 'sell-eggs' || activeTab === 'egg-market' ? 'text-orange-600 font-bold' : 'hover:text-stone-900'
        }`}
      >
        <Store className={`w-5 h-5 ${activeTab === 'sell-eggs' || activeTab === 'egg-market' ? 'text-orange-600' : 'text-stone-500'}`} />
        <span>Egg Sell</span>
      </button>

      {/* 3. My Hens — Highlighted Elevated Central Button */}
      <button
        onClick={() => onSelectTab('my-hens')}
        className="flex flex-col items-center -mt-6 group focus:outline-hidden"
      >
        <div className="w-13 h-13 rounded-full bg-gradient-to-tr from-emerald-800 via-emerald-700 to-teal-600 text-white flex items-center justify-center shadow-lg shadow-emerald-800/30 group-hover:scale-105 active:scale-95 transition-all ring-4 ring-white">
          <Egg className="w-6 h-6 text-white" />
        </div>
        <span className={`mt-1 font-bold ${activeTab === 'my-hens' ? 'text-emerald-900' : 'text-stone-700'}`}>
          My Hens
        </span>
      </button>

      {/* 4. Transaction History */}
      <button
        onClick={() => onSelectTab('transactions')}
        className={`flex flex-col items-center gap-1 py-1 px-2.5 transition-colors ${
          activeTab === 'transactions' ? 'text-emerald-800 font-bold' : 'hover:text-stone-900'
        }`}
      >
        <FileText className={`w-5 h-5 ${activeTab === 'transactions' ? 'text-emerald-800' : 'text-stone-500'}`} />
        <span>History</span>
      </button>

      {/* 5. Logout */}
      <button
        onClick={onLogout}
        className="flex flex-col items-center gap-1 py-1 px-2.5 text-stone-500 hover:text-red-700 transition-colors"
      >
        <LogOut className="w-5 h-5" />
        <span>Logout</span>
      </button>

    </div>
  );
};
