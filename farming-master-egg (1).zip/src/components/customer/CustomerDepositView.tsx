import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Wallet, 
  Smartphone, 
  Building2, 
  Upload, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  FileText, 
  ArrowRight,
  ShieldCheck,
  Info,
  Database,
  Copy,
  Check,
  ExternalLink
} from 'lucide-react';
import { DepositMethodKey } from '../../types';
import { 
  SUPABASE_PROJECT_ID, 
  SUPABASE_DEFAULT_URL, 
  SUPABASE_DEPOSITS_WITHDRAWALS_SQL,
  checkDepositsWithdrawalsHealth 
} from '../../lib/supabase';

export const CustomerDepositView: React.FC = () => {
  const { 
    currentUser, 
    depositSettings, 
    depositRequests, 
    createDepositRequest 
  } = useApp();

  const enabledSettings = depositSettings.filter(s => s.isEnabled);

  const [selectedMethod, setSelectedMethod] = useState<DepositMethodKey>(
    enabledSettings[0]?.methodKey || 'easypaisa'
  );
  const [depositAmount, setDepositAmount] = useState<number>(1000);
  const [trxRef, setTrxRef] = useState<string>('');
  const [receiptAttached, setReceiptAttached] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [copiedSql, setCopiedSql] = useState(false);
  const [showSqlModal, setShowSqlModal] = useState(false);
  const [supabaseStatus, setSupabaseStatus] = useState<{ checked: boolean; depositsFound: boolean }>({
    checked: false,
    depositsFound: false,
  });

  useEffect(() => {
    checkDepositsWithdrawalsHealth().then(res => {
      setSupabaseStatus({ checked: true, depositsFound: res.depositsFound });
    });
  }, []);

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_DEPOSITS_WITHDRAWALS_SQL);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 3000);
  };

  const activeMethodConfig = depositSettings.find(s => s.methodKey === selectedMethod);

  // Customer's own deposit requests only (RLS compliant)
  const myDeposits = depositRequests.filter(d => d.customerId === currentUser?.id);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    const result = createDepositRequest(selectedMethod, depositAmount, trxRef, receiptAttached ? '/src/assets/images/fresh_farm_eggs_1793810684885.jpg' : undefined);
    if (result.success) {
      setFeedback({ 
        type: 'success', 
        message: `${result.message} Data dispatched to Supabase project "${SUPABASE_PROJECT_ID}".` 
      });
      setTrxRef('');
      setReceiptAttached(false);
    } else {
      setFeedback({ type: 'error', message: result.message });
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Supabase Backend Integration Banner */}
      <div className="bg-emerald-950 text-white p-4 sm:p-5 rounded-2xl border border-emerald-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-emerald-900/80 rounded-xl border border-emerald-700/50 text-emerald-300">
            <Database className="w-5 h-5 text-emerald-400" />
          </div>
          <div className="space-y-0.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                Supabase Backend Connected
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-800 text-emerald-100 border border-emerald-600">
                Project: {SUPABASE_PROJECT_ID}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-900 text-emerald-200 border border-emerald-700">
                Table: public.deposits
              </span>
            </div>
            <p className="text-xs text-emerald-100">
              Every deposit request is captured with user ID, name, contact, amount, and reference code.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setShowSqlModal(!showSqlModal)}
            className="px-3 py-1.5 bg-emerald-900/90 hover:bg-emerald-800 text-emerald-200 hover:text-white border border-emerald-700 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span>{showSqlModal ? 'Hide SQL' : 'View Supabase SQL'}</span>
          </button>
          <button
            type="button"
            onClick={handleCopySql}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
          >
            {copiedSql ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSql ? 'Copied SQL!' : 'Copy SQL Script'}</span>
          </button>
        </div>
      </div>

      {/* Expandable SQL Viewer Modal / Drawer */}
      {showSqlModal && (
        <div className="p-4 bg-stone-900 text-stone-200 rounded-2xl border border-stone-800 shadow-lg space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-stone-800 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold text-emerald-400">public.deposits & public.withdrawals DDL</span>
              <span className="text-stone-400">Run this once in Supabase SQL Editor</span>
            </div>
            <a
              href={`https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}/sql/new`}
              target="_blank"
              rel="noreferrer"
              className="text-emerald-400 hover:text-emerald-300 flex items-center gap-1 text-[11px] underline"
            >
              <span>Open Supabase SQL Editor</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          <pre className="text-[11px] font-mono leading-relaxed bg-stone-950 p-3 rounded-xl overflow-x-auto text-emerald-300 max-h-60">
            {SUPABASE_DEPOSITS_WITHDRAWALS_SQL}
          </pre>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-emerald-950/10 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800 uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>Audited Deposit Gateway</span>
          </div>
          <h2 className="text-xl font-bold font-display text-emerald-950">
            Deposit Funds for Physical Hen Purchases
          </h2>
          <p className="text-xs text-stone-500">
            Deposited funds allow you to acquire physical layer hens (Rs. 500 each) and settle farm custody care balances.
          </p>
        </div>

        <div className="bg-emerald-50/80 p-4 rounded-xl border border-emerald-900/10 shrink-0">
          <span className="text-[11px] text-stone-600 block">Current Available Balance</span>
          <span className="text-2xl font-bold font-mono text-emerald-950 tabular-nums">
            Rs. {currentUser ? currentUser.withdrawableBalance.toFixed(2) : '0.00'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column (8 cols): Step-by-step Deposit Form */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-2xl border border-emerald-950/10 shadow-xs space-y-6">
          <div className="space-y-1">
            <h3 className="text-base font-bold text-emerald-950 font-display">
              1. Select Approved Payment Method
            </h3>
            <p className="text-xs text-stone-500">
              Transfer funds through our verified corporate account, then submit the transaction reference below.
            </p>
          </div>

          {/* Payment Method Selector Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {enabledSettings.map(setting => {
              const isSelected = selectedMethod === setting.methodKey;
              return (
                <button
                  key={setting.id}
                  type="button"
                  onClick={() => setSelectedMethod(setting.methodKey)}
                  className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    isSelected 
                      ? 'bg-emerald-800 text-white border-emerald-800 shadow-xs' 
                      : 'bg-stone-50 text-stone-800 border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  <div className="flex items-center justify-between pb-2">
                    {setting.methodKey === 'bank_transfer' ? (
                      <Building2 className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-emerald-800'}`} />
                    ) : (
                      <Smartphone className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-emerald-800'}`} />
                    )}
                    <span className={`text-[10px] font-bold uppercase tracking-wider ${isSelected ? 'text-emerald-200' : 'text-stone-500'}`}>
                      Active
                    </span>
                  </div>
                  <div>
                    <span className="font-bold text-xs block leading-tight">{setting.name}</span>
                    <span className={`text-[11px] block mt-0.5 ${isSelected ? 'text-emerald-200' : 'text-stone-500'}`}>
                      {setting.methodKey === 'bank_transfer' ? setting.bankName?.split(' ')[0] : 'Mobile Wallet'}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Account Details Box */}
          {activeMethodConfig && (
            <div className="p-4 bg-emerald-50/70 rounded-xl border border-emerald-900/10 space-y-2 text-xs">
              <div className="font-bold text-emerald-950 flex items-center justify-between">
                <span>{activeMethodConfig.name} Details</span>
                <span className="font-mono text-[11px] text-emerald-800 font-semibold">{activeMethodConfig.accountDetails}</span>
              </div>

              <div className="space-y-1 text-stone-700">
                {activeMethodConfig.bankName && (
                  <div>Bank Name: <strong className="text-stone-900">{activeMethodConfig.bankName}</strong></div>
                )}
                <div>Account Title: <strong className="text-stone-900">{activeMethodConfig.accountHolderName}</strong></div>
                <div className="flex items-center gap-2">
                  <span>Account / IBAN:</span>
                  <span className="font-mono font-bold text-emerald-900 bg-white px-2 py-0.5 rounded border border-emerald-200 text-xs">
                    {activeMethodConfig.accountNumber}
                  </span>
                </div>
              </div>

              {activeMethodConfig.paymentInstructions && (
                <div className="pt-2 border-t border-emerald-900/10 text-[11px] text-stone-600 leading-relaxed">
                  <strong>Instructions:</strong> {activeMethodConfig.paymentInstructions}
                </div>
              )}
            </div>
          )}

          {/* Feedback Alert */}
          {feedback && (
            <div className={`p-3.5 rounded-xl text-xs flex items-center gap-2.5 ${
              feedback.type === 'error' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
            }`}>
              {feedback.type === 'error' ? <AlertCircle className="w-4 h-4 shrink-0 text-red-600" /> : <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />}
              <span>{feedback.message}</span>
            </div>
          )}

          {/* Deposit Submission Form */}
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Amount Transferred (PKR) *
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min={500}
                    step={100}
                    value={depositAmount}
                    onChange={e => setDepositAmount(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900 font-mono text-sm focus:outline-hidden focus:border-emerald-700"
                    required
                  />
                </div>
                <span className="text-[11px] text-stone-500 mt-0.5 block">
                  Minimum: Rs. 500 (1 Hen = Rs. 500)
                </span>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Transaction Reference ID (TRX / TID) *
                </label>
                <input
                  type="text"
                  value={trxRef}
                  onChange={e => setTrxRef(e.target.value)}
                  placeholder="e.g. EP-88492019 or TID-92810"
                  className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900 font-mono text-sm focus:outline-hidden focus:border-emerald-700"
                  required
                />
                <span className="text-[11px] text-stone-500 mt-0.5 block">
                  Copied from your transfer SMS or app receipt
                </span>
              </div>
            </div>

            {/* Receipt Upload */}
            <div className="space-y-1.5">
              <label className="font-semibold text-stone-700 block">
                Attach Payment Screenshot / Voucher (Recommended)
              </label>
              <button
                type="button"
                onClick={() => setReceiptAttached(!receiptAttached)}
                className={`w-full py-3 px-4 border border-dashed rounded-xl text-xs flex items-center justify-center gap-2 transition-colors ${
                  receiptAttached
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-900 font-semibold'
                    : 'bg-stone-50 border-stone-300 text-stone-600 hover:bg-stone-100'
                }`}
              >
                <Upload className="w-4 h-4 text-emerald-800" />
                <span>
                  {receiptAttached 
                    ? 'Payment Proof Attached: bank_transfer_receipt.jpg' 
                    : 'Click to attach payment transfer voucher / screenshot'}
                </span>
              </button>
            </div>

            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-[11px] text-stone-600 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-stone-800">
                <Info className="w-3.5 h-3.5 text-emerald-700" />
                <span>Manual Verification Policy</span>
              </div>
              <p>
                To prevent fraud and maintain strict financial audit integrity, all deposits are manually verified by our farm accountant against our commercial bank statements before balances are credited.
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl transition-colors shadow-xs flex items-center justify-center gap-2"
            >
              <span>Submit Deposit for Admin Verification</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* Right Column (5 cols): Deposit History Ledger */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-emerald-950/10 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <h3 className="font-bold text-sm text-emerald-950 font-display">
              My Deposit Requests ({myDeposits.length})
            </h3>
            <span className="text-[11px] text-stone-500">Live Status Tracking</span>
          </div>

          {myDeposits.length === 0 ? (
            <div className="py-12 text-center space-y-2 text-stone-500">
              <Wallet className="w-8 h-8 text-stone-300 mx-auto" />
              <p className="text-xs">No deposit requests submitted yet.</p>
              <p className="text-[11px] text-stone-400">
                Submit your first deposit on the left to start acquiring physical layer hens.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {myDeposits.map(dep => (
                <div
                  key={dep.id}
                  className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-950 font-mono">
                      Rs. {dep.amount.toLocaleString()}
                    </span>
                    
                    {dep.status === 'pending' && (
                      <span className="text-[11px] font-semibold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Pending Verification
                      </span>
                    )}
                    {dep.status === 'approved' && (
                      <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Approved & Credited
                      </span>
                    )}
                    {dep.status === 'rejected' && (
                      <span className="text-[11px] font-semibold text-red-800 bg-red-50 border border-red-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> Declined
                      </span>
                    )}
                  </div>

                  <div className="text-[11px] text-stone-600 flex justify-between">
                    <span>{dep.methodName}</span>
                    <span className="font-mono text-stone-700">TRX: {dep.transactionReference}</span>
                  </div>

                  <div className="text-[10px] text-stone-400 font-mono">
                    Submitted: {dep.createdAt}
                  </div>

                  {dep.adminNote && (
                    <div className="pt-1.5 border-t border-stone-200/70 text-[11px] text-stone-600">
                      <strong>Admin Note:</strong> {dep.adminNote}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
