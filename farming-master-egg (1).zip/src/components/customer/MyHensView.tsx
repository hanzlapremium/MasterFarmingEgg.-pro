import React, { useState, useEffect, useMemo } from 'react';
import { 
  Egg, 
  Clock, 
  Award, 
  MapPin, 
  CheckCircle2, 
  AlertCircle, 
  XCircle, 
  Calendar, 
  Info, 
  Activity, 
  ChevronRight,
  X,
  FileText,
  Sparkles
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Hen, PurchaseOrder, EggProductionRecord } from '../../types';

interface MyHensViewProps {
  myHens: Hen[];
  myPurchases: PurchaseOrder[];
  productionRecords: EggProductionRecord[];
  lastCollectionCycleTime: number;
  onOpenCertificate: (hen: Hen) => void;
  onAcquireHens: () => void;
}

export const MyHensView: React.FC<MyHensViewProps> = ({
  myHens,
  myPurchases,
  productionRecords,
  lastCollectionCycleTime,
  onOpenCertificate,
  onAcquireHens,
}) => {
  const [filter, setFilter] = useState<'all' | 'active' | 'pending' | 'rejected'>('all');
  const [selectedProductionHen, setSelectedProductionHen] = useState<Hen | null>(null);

  const { eggAllocations, currentUser } = useApp();

  const initialEggsAllocated = useMemo(() => {
    if (!currentUser) return 0;
    return eggAllocations
      .filter(a => a.customerId === currentUser.id && a.allocationType === 'initial_purchase')
      .reduce((sum, a) => sum + a.quantity, 0);
  }, [eggAllocations, currentUser]);

  // Live 24-Hour Production Countdown Timer (86,400 seconds cycle)
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const timer = setInterval(() => {
      setNow(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Compute countdown for 24-hour cycle from last collection reset
  const cycleDurationMs = 24 * 60 * 60 * 1000;
  const elapsedMs = Math.max(0, now - lastCollectionCycleTime);
  const remainingMs = Math.max(0, cycleDurationMs - (elapsedMs % cycleDurationMs));
  const isCollectionDue = remainingMs <= 0 || (elapsedMs > cycleDurationMs && productionRecords.length === 0);

  const hours = Math.floor(remainingMs / (1000 * 60 * 60));
  const minutes = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((remainingMs % (1000 * 60)) / 1000);

  const formattedCountdown = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  // Next expected collection time (e.g. 06:00 AM)
  const nextCollectionDate = new Date(lastCollectionCycleTime + cycleDurationMs);
  const nextCollectionTimeStr = nextCollectionDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Prepare combined ownership items:
  // 1. Active registered hens (status === 'owned')
  // 2. Pending purchase orders (awaiting verification)
  // 3. Rejected purchase orders
  const allOwnershipItems = useMemo(() => {
    const items: Array<{
      key: string;
      id: string;
      ownershipId: string;
      tagCode: string;
      breed: string;
      quantity: number;
      amountPaid: number;
      purchaseDate: string;
      status: 'active' | 'pending' | 'rejected';
      farmLocation: string;
      healthStatus: string;
      dailyEggs: string;
      initialEggs: number;
      henObj?: Hen;
      orderObj?: PurchaseOrder;
    }> = [];

    // Active hens
    myHens.forEach((hen, idx) => {
      const ownId = hen.ownershipId || `FME-CUST-${(hen.ownerId || 'OWN').slice(-4).toUpperCase()}-${hen.tagCode}`;
      items.push({
        key: `hen-${hen.id}`,
        id: hen.tagCode,
        ownershipId: ownId,
        tagCode: hen.tagCode,
        breed: hen.breed,
        quantity: 1,
        amountPaid: hen.purchasePrice || 500,
        purchaseDate: hen.acquisitionDate,
        status: 'active',
        farmLocation: `${hen.shedName} (Punjab Facility)`,
        healthStatus: hen.healthStatus === 'healthy' ? 'Healthy Active Layer' : 'Molting / Under Care',
        dailyEggs: `${hen.dailyEggYieldAvg.toFixed(2)} / bird avg`,
        initialEggs: hen.initialEggsAllocated !== undefined ? hen.initialEggsAllocated : 1,
        henObj: hen,
      });
    });

    // Pending and rejected purchases
    myPurchases.forEach(order => {
      if (order.status === 'pending') {
        items.push({
          key: `order-${order.id}`,
          id: order.id,
          ownershipId: `PENDING-${order.id}`,
          tagCode: 'Awaiting Physical Tag',
          breed: 'Layer Pullet (Commercial Strain)',
          quantity: order.quantity,
          amountPaid: order.totalAmount,
          purchaseDate: order.createdAt,
          status: 'pending',
          farmLocation: 'Quarantine / Admission Shed',
          healthStatus: 'Veterinary Check Scheduled',
          dailyEggs: 'Pending Assignment',
          initialEggs: 0,
          orderObj: order,
        });
      } else if (order.status === 'rejected') {
        items.push({
          key: `order-rej-${order.id}`,
          id: order.id,
          ownershipId: `REJECTED-${order.id}`,
          tagCode: 'N/A',
          breed: 'Layer Pullet',
          quantity: order.quantity,
          amountPaid: order.totalAmount,
          purchaseDate: order.createdAt,
          status: 'rejected',
          farmLocation: 'Declined by Farm Treasury',
          healthStatus: 'Payment Unverified',
          dailyEggs: 'Zero',
          initialEggs: 0,
          orderObj: order,
        });
      }
    });

    return items;
  }, [myHens, myPurchases]);

  const filteredItems = useMemo(() => {
    if (filter === 'all') return allOwnershipItems;
    return allOwnershipItems.filter(item => item.status === filter);
  }, [allOwnershipItems, filter]);

  return (
    <div className="space-y-6">
      
      {/* Top Banner / Header (Screenshot 3 reference) */}
      <div className="bg-white rounded-2xl p-6 border border-emerald-950/10 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-emerald-950 tracking-tight">
            MY HENS
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Track your active Hens & Eggs under physical custody.
          </p>
        </div>

        <button
          onClick={onAcquireHens}
          className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-xl shadow-xs transition-colors self-start md:self-auto"
        >
          + Acquire Hens (Rs. 500)
        </button>
      </div>

      {/* 24-Hour Production-Cycle Countdown Interface (Requirement 5) */}
      <div className="bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-950 text-white rounded-2xl p-5 sm:p-6 shadow-md border border-emerald-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-800/80 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-800/80 border border-emerald-700 flex items-center justify-center text-emerald-300">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 block font-sans">
                24-Hour Flock Production Cycle
              </span>
              <span className="text-sm font-bold font-display text-white">
                Next Expected Farm Collection Sweep
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-emerald-300">Expected Sweep:</span>
            <span className="text-xs font-mono font-bold text-amber-300 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
              {nextCollectionTimeStr}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
          <div className="sm:col-span-2 space-y-1">
            <div className="text-xs text-emerald-200">
              Collection Countdown Status:
            </div>
            {isCollectionDue ? (
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500 text-emerald-950 font-bold rounded-lg text-sm shadow-sm">
                <AlertCircle className="w-4 h-4" />
                <span>Collection Due — Farm Sweep Underway</span>
              </div>
            ) : (
              <div className="flex items-baseline gap-2">
                <span className="text-3xl sm:text-4xl font-bold font-mono text-emerald-100 tracking-wider">
                  {formattedCountdown}
                </span>
                <span className="text-xs text-emerald-300 font-mono">
                  (HH:MM:SS)
                </span>
              </div>
            )}
            <p className="text-[11px] text-emerald-300/80 leading-relaxed pt-1">
              * The countdown reflects the scheduled farm sweep. Biological egg production is variable; eggs are credited strictly upon physical tally and supervisor logging.
            </p>
          </div>

          <div className="bg-emerald-900/60 border border-emerald-800/80 rounded-xl p-3 text-xs text-emerald-200 space-y-1">
            <div className="flex justify-between">
              <span className="text-[11px] text-emerald-300">Your Active Flock:</span>
              <span className="font-mono font-bold text-white">{myHens.length} Hens</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[11px] text-emerald-300">Recorded Sweeps:</span>
              <span className="font-mono font-bold text-white">{productionRecords.length} Total</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[11px] text-emerald-300">Biosecurity Gate:</span>
              <span className="text-emerald-400 font-medium">Level 2 Certified</span>
            </div>
          </div>
        </div>

        {/* Required Flock Summary Specification */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-emerald-800/80">
          <div className="bg-emerald-950/90 p-3.5 rounded-xl border border-emerald-800 flex flex-col justify-center">
            <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">MY HENS</span>
            <div className="text-2xl font-bold font-mono text-white mt-0.5">{myHens.length}</div>
          </div>
          <div className="bg-emerald-950/90 p-3.5 rounded-xl border border-emerald-800 flex flex-col justify-center">
            <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">INITIAL EGGS</span>
            <div className="text-2xl font-bold font-mono text-amber-300 mt-0.5">{initialEggsAllocated}</div>
          </div>
          <div className="bg-emerald-950/90 p-3.5 rounded-xl border border-emerald-800 flex flex-col justify-center">
            <span className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">NEXT EXPECTED COLLECTION</span>
            <div className="text-xl font-bold font-mono text-emerald-100 mt-0.5">
              {isCollectionDue ? 'Collection Due' : formattedCountdown}
            </div>
          </div>
        </div>
      </div>

      {/* Filter Buttons */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-semibold">
        {[
          { id: 'all', label: `All (${allOwnershipItems.length})` },
          { id: 'active', label: `Active (${allOwnershipItems.filter(i => i.status === 'active').length})` },
          { id: 'pending', label: `Pending (${allOwnershipItems.filter(i => i.status === 'pending').length})` },
          { id: 'rejected', label: `Rejected (${allOwnershipItems.filter(i => i.status === 'rejected').length})` },
        ].map(btn => (
          <button
            key={btn.id}
            onClick={() => setFilter(btn.id as any)}
            className={`px-4 py-2 rounded-xl border transition-all whitespace-nowrap cursor-pointer ${
              filter === btn.id
                ? 'bg-emerald-800 text-white border-emerald-800 shadow-xs'
                : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
            }`}
          >
            {btn.label}
          </button>
        ))}
      </div>

      {/* Empty State */}
      {filteredItems.length === 0 && (
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center space-y-3">
          <Egg className="w-10 h-10 text-stone-300 mx-auto" />
          <h3 className="text-base font-bold text-stone-800">
            No hens found in '{filter.toUpperCase()}' view
          </h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            You can acquire real, individually tagged layer pullets at Rs. 500 each to start participating in verified farm bailment.
          </p>
          <button
            onClick={onAcquireHens}
            className="px-4 py-2 bg-emerald-800 text-white rounded-lg text-xs font-bold shadow-xs hover:bg-emerald-900"
          >
            Explore Available Hens
          </button>
        </div>
      )}

      {/* Hen Ownership Cards Grid (Screenshot 3 Reference Layout) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredItems.map(item => (
          <div
            key={item.key}
            className="bg-white rounded-2xl border border-emerald-950/10 shadow-xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between"
          >
            {/* Top Bar with Status Badge */}
            <div className="p-4 border-b border-stone-100 flex items-center justify-between bg-stone-50/60">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-stone-500 font-sans">
                  STATUS:
                </span>
                {item.status === 'active' && (
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-200 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-700" /> ACTIVE
                  </span>
                )}
                {item.status === 'pending' && (
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-200 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-amber-700" /> PENDING
                  </span>
                )}
                {item.status === 'rejected' && (
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-red-100 text-red-900 border border-red-200 flex items-center gap-1">
                    <XCircle className="w-3 h-3 text-red-700" /> REJECTED
                  </span>
                )}
              </div>

              <div className="flex flex-col items-end">
                <span className="font-mono font-bold text-xs text-stone-700 bg-stone-200/70 px-2 py-0.5 rounded">
                  Tag: {item.tagCode}
                </span>
                {item.ownershipId && (
                  <span className="text-[9px] font-mono text-stone-500 mt-0.5">
                    {item.ownershipId}
                  </span>
                )}
              </div>
            </div>

            {/* Hen Details Body */}
            <div className="p-5 space-y-3.5 text-xs text-stone-700">
              <div className="flex justify-between items-start pb-2 border-b border-stone-100">
                <div>
                  <span className="text-[10px] uppercase font-bold text-stone-400 block font-sans">
                    HEN NAME / BREED
                  </span>
                  <span className="font-bold text-sm text-emerald-950 font-display">
                    {item.breed}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-stone-400 block font-sans">
                    QUANTITY
                  </span>
                  <span className="font-bold font-mono text-stone-900 text-sm">
                    {item.quantity} Bird{item.quantity > 1 ? 's' : ''}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-[10px] uppercase font-semibold text-stone-400 block font-sans">
                    AMOUNT PAID
                  </span>
                  <span className="font-bold font-mono text-emerald-950 text-sm">
                    Rs. {item.amountPaid.toLocaleString()}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] uppercase font-semibold text-stone-400 block font-sans">
                    INITIAL EGGS ALLOCATED
                  </span>
                  <span className="font-bold font-mono text-amber-700 text-sm">
                    {item.initialEggs} Egg{item.initialEggs !== 1 ? 's' : ''}
                  </span>
                </div>
              </div>

              <div className="p-2.5 bg-stone-50 rounded-xl border border-stone-200/70 space-y-1.5 text-[11px]">
                <div className="flex items-center justify-between">
                  <span className="text-stone-500">Farm Location:</span>
                  <span className="font-medium text-stone-800 truncate max-w-[170px]">{item.farmLocation}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-stone-500">Health Status:</span>
                  <span className="text-emerald-800 font-semibold">{item.healthStatus}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-stone-500">Daily Recorded Eggs:</span>
                  <span className="font-mono font-bold text-emerald-950">{item.dailyEggs}</span>
                </div>
              </div>

              {/* Countdown Preview */}
              <div className="flex items-center justify-between text-xs pt-1">
                <span className="text-stone-500 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-stone-400" />
                  <span>Next Collection:</span>
                </span>
                <span className="font-mono font-bold text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {isCollectionDue ? 'Collection Due' : formattedCountdown}
                </span>
              </div>
            </div>

            {/* Actions Footer */}
            <div className="p-4 bg-stone-50 border-t border-stone-100 flex items-center justify-between gap-2">
              {item.henObj && (
                <>
                  <button
                    onClick={() => setSelectedProductionHen(item.henObj!)}
                    className="flex items-center gap-1 text-xs font-semibold text-emerald-800 hover:text-emerald-950 transition-colors py-1 px-2 rounded-lg hover:bg-stone-200/50"
                  >
                    <Activity className="w-3.5 h-3.5" />
                    <span>Production History</span>
                  </button>

                  <button
                    onClick={() => onOpenCertificate(item.henObj!)}
                    className="flex items-center gap-1 text-xs font-bold text-white bg-emerald-800 hover:bg-emerald-900 py-1.5 px-3 rounded-lg shadow-2xs transition-colors"
                  >
                    <Award className="w-3.5 h-3.5 text-emerald-300" />
                    <span>Certificate</span>
                  </button>
                </>
              )}

              {item.orderObj && (
                <div className="text-[11px] text-stone-500 italic w-full text-center py-1">
                  {item.orderObj.status === 'pending'
                    ? 'Awaiting farm supervisor confirmation'
                    : 'Order was rejected during verification'}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Production History Modal */}
      {selectedProductionHen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div>
                <h3 className="font-bold text-base text-emerald-950 font-display">
                  Flock Production History
                </h3>
                <span className="text-xs text-stone-500 font-mono">
                  Hen Tag: {selectedProductionHen.tagCode} ({selectedProductionHen.breed})
                </span>
              </div>
              <button
                onClick={() => setSelectedProductionHen(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 space-y-1">
                <div className="font-bold">Custody Bailment Formula:</div>
                <p className="text-[11px] text-emerald-800 leading-relaxed">
                  Layer poultry are maintained in biosecure communal housing ({selectedProductionHen.shedName}). Output is recorded during daily morning sweeps and allocated by flock proportion.
                </p>
              </div>

              <div className="max-h-60 overflow-y-auto divide-y divide-stone-100">
                {productionRecords.length === 0 ? (
                  <div className="py-8 text-center text-stone-500 text-xs">
                    No production sweeps logged yet by farm admin.
                  </div>
                ) : (
                  productionRecords.map(rec => (
                    <div key={rec.id} className="py-2.5 flex justify-between items-center text-xs">
                      <div>
                        <span className="font-semibold text-stone-900 block">{rec.date}</span>
                        <span className="text-[11px] text-stone-500">{rec.shedName} · {rec.eggsCollected} total collected</span>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-emerald-900">
                          {((1 / (rec.flockSize || 2000)) * rec.eggsCollected).toFixed(2)} Eggs
                        </span>
                        <span className="text-[10px] text-stone-400 block">Your Allocated Share</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="pt-2 border-t border-stone-100 flex justify-end">
              <button
                onClick={() => setSelectedProductionHen(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
