import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Store, 
  Egg, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Building2, 
  Smartphone, 
  ArrowRight, 
  ShieldCheck,
  History,
  Info,
  XCircle,
  TrendingUp,
  CreditCard,
  Check,
  ChevronRight
} from 'lucide-react';
import { EggMarket, EggSellingOrder } from '../../types';
import { SUPABASE_PROJECT_ID } from '../../lib/supabase';

interface EggMarketplaceViewProps {
  onBackToCollection?: () => void;
  defaultSubTab?: 'markets' | 'history';
}

export const EggMarketplaceView: React.FC<EggMarketplaceViewProps> = ({ 
  onBackToCollection,
  defaultSubTab = 'markets'
}) => {
  const { 
    currentUser, 
    eggMarkets, 
    eggAllocations, 
    eggSellingOrders, 
    sellEggsToMarket 
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'markets' | 'history'>(defaultSubTab);
  const [selectedMarket, setSelectedMarket] = useState<EggMarket | null>(null);

  // Selling Form States
  const [destinationType, setDestinationType] = useState<'bank' | 'wallet'>('bank');
  const [walletProvider, setWalletProvider] = useState<'Easypaisa' | 'JazzCash'>('Easypaisa');
  const [accountHolderName, setAccountHolderName] = useState(currentUser?.name || '');
  const [bankName, setBankName] = useState('Meezan Bank Ltd');
  const [accountNumber, setAccountNumber] = useState(currentUser?.phone || '');
  const [iban, setIban] = useState('');
  const [eggQuantity, setEggQuantity] = useState<number>(10);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Customer verified physical egg calculations
  const myAllocs = eggAllocations.filter(a => a.customerId === currentUser?.id);
  const totalCustomerEggsCollected = myAllocs.reduce((sum, a) => sum + a.quantity, 0);

  // Active customer orders (excluding rejected)
  const myOrders = eggSellingOrders.filter(o => o.userId === currentUser?.id);
  const eggsReservedInOrders = myOrders
    .filter(o => o.orderStatus !== 'rejected')
    .reduce((sum, o) => sum + o.eggQuantity, 0);

  // Available eggs eligible for selling
  const availableEggs = Math.max(0, totalCustomerEggsCollected - eggsReservedInOrders);

  const handleOpenMarket = (market: EggMarket) => {
    setSelectedMarket(market);
    const initialQty = Math.max(market.minimumQuantity, Math.min(10, availableEggs));
    setEggQuantity(initialQty > 0 ? initialQty : market.minimumQuantity);
    setAccountHolderName(currentUser?.name || '');
    setAccountNumber(currentUser?.phone || '');
    setFeedback(null);
  };

  const handleConfirmSelling = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMarket) return;
    setFeedback(null);

    // Strict validation
    if (eggQuantity <= 0) {
      setFeedback({ type: 'error', message: 'Please specify a valid quantity of eggs to sell.' });
      return;
    }

    if (eggQuantity < selectedMarket.minimumQuantity) {
      setFeedback({ 
        type: 'error', 
        message: `Minimum order for ${selectedMarket.marketName} is ${selectedMarket.minimumQuantity} eggs.` 
      });
      return;
    }

    if (eggQuantity > selectedMarket.maximumQuantity) {
      setFeedback({ 
        type: 'error', 
        message: `Maximum single order for ${selectedMarket.marketName} is ${selectedMarket.maximumQuantity} eggs.` 
      });
      return;
    }

    if (eggQuantity > availableEggs) {
      setFeedback({ 
        type: 'error', 
        message: `Insufficient verified eggs! You have ${availableEggs} eggs available, requested ${eggQuantity}.` 
      });
      return;
    }

    if (!accountHolderName.trim()) {
      setFeedback({ type: 'error', message: 'Account Holder Name is required for payout dispatch.' });
      return;
    }

    if (!accountNumber.trim()) {
      setFeedback({ 
        type: 'error', 
        message: destinationType === 'bank' 
          ? 'Bank Account Number / IBAN is required.' 
          : 'Mobile Wallet Number is required.' 
      });
      return;
    }

    setIsSubmitting(true);

    const payoutMethod: 'Bank Transfer' | 'Easypaisa' | 'JazzCash' = 
      destinationType === 'bank' ? 'Bank Transfer' : walletProvider;

    const fullAccountDetails = destinationType === 'bank' && iban.trim()
      ? `${accountNumber.trim()} (IBAN: ${iban.trim()})`
      : accountNumber.trim();

    const res = sellEggsToMarket({
      marketId: selectedMarket.id,
      quantity: Number(eggQuantity),
      payoutMethod,
      accountHolderName: accountHolderName.trim(),
      bankName: destinationType === 'bank' ? bankName.trim() : undefined,
      accountNumber: fullAccountDetails,
      walletName: destinationType === 'wallet' ? walletProvider : undefined,
      walletNumber: destinationType === 'wallet' ? accountNumber.trim() : undefined,
    });

    setIsSubmitting(false);

    if (res.success) {
      setFeedback({ 
        type: 'success', 
        message: `${res.message} Order saved in Selling History. Treasury will verify and execute payout.` 
      });
      setSelectedMarket(null);
      setActiveSubTab('history');
    } else {
      setFeedback({ type: 'error', message: res.message });
    }
  };

  const getOrderStatusBadge = (status: EggSellingOrder['orderStatus']) => {
    switch (status) {
      case 'paid':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Paid
          </span>
        );
      case 'processing':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 text-blue-800 border border-blue-300">
            <Clock className="w-3.5 h-3.5 text-blue-600" />
            Processing
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Rejected (Eggs Released)
          </span>
        );
      case 'pending':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            Pending Treasury Verification
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Page Header (Cream Background Inspired by Design Reference) */}
      <div className="bg-[#fffdf7] rounded-3xl p-6 sm:p-8 border border-amber-900/10 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-100/80 text-orange-800 rounded-full text-xs font-bold uppercase tracking-wider">
            <Store className="w-3.5 h-3.5 text-orange-600" />
            <span>Egg Sell & Direct Payout Portal</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-stone-900 tracking-tight">
            EGG SELL
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
            Sell your eggs directly to accredited wholesale buyers at guaranteed market rates. 
            Choose your market, specify egg quantity, and receive your cash payout directly to your Bank Account, Easypaisa, or JazzCash.
          </p>
        </div>

        {/* Verified Egg Balance Badge */}
        <div className="bg-white p-5 rounded-2xl border border-amber-200/80 shadow-xs shrink-0 text-center sm:text-right space-y-1">
          <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">
            Your Verified Egg Balance
          </span>
          <div className="text-3xl sm:text-4xl font-extrabold font-mono text-orange-600 flex items-center justify-center sm:justify-end gap-2">
            <Egg className="w-8 h-8 text-amber-400 fill-amber-400" />
            <span>{availableEggs.toLocaleString()}</span>
          </div>
          <span className="text-[11px] text-stone-400 block font-mono">
            {eggsReservedInOrders > 0 ? `(${eggsReservedInOrders} eggs reserved in active orders)` : 'All eggs ready for sale'}
          </span>
        </div>
      </div>

      {/* Navigation Sub-Tabs: 1. Markets, 2. Selling History */}
      <div className="flex items-center gap-2 border-b border-stone-200 pb-2">
        <button
          onClick={() => setActiveSubTab('markets')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'markets'
              ? 'bg-orange-500 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>Available Markets (3)</span>
        </button>

        <button
          onClick={() => setActiveSubTab('history')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'history'
              ? 'bg-orange-500 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Selling History ({myOrders.length})</span>
        </button>
      </div>

      {/* Global Feedback Banner */}
      {feedback && (
        <div className={`p-4 rounded-2xl text-xs flex items-center gap-3 ${
          feedback.type === 'error'
            ? 'bg-red-50 text-red-800 border border-red-200'
            : 'bg-emerald-50 text-emerald-900 border border-emerald-200'
        }`}>
          {feedback.type === 'error' ? (
            <AlertCircle className="w-5 h-5 shrink-0 text-red-600" />
          ) : (
            <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
          )}
          <span className="font-semibold">{feedback.message}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* VIEW A: THREE OFFICIAL EGG BUYER MARKET CARDS                             */}
      {/* ========================================================================= */}
      {activeSubTab === 'markets' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {eggMarkets.map((market, idx) => {
              const isEligible = availableEggs >= market.minimumQuantity;

              return (
                <div
                  key={market.id}
                  className="bg-white rounded-2xl border border-stone-200/90 shadow-sm border-t-4 border-orange-500 overflow-hidden flex flex-col justify-between hover:shadow-md transition-all duration-200"
                >
                  {/* Card Header & Shop Identity */}
                  <div className="p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-orange-50 border border-orange-200 flex items-center justify-center text-orange-600 shadow-xs">
                        <Store className="w-6 h-6 text-orange-600" />
                      </div>
                      <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-50 text-amber-800 border border-amber-200">
                        Market {idx + 1}
                      </span>
                    </div>

                    <div>
                      <h3 className="font-bold text-lg font-display text-stone-900 uppercase tracking-tight">
                        {market.marketName}
                      </h3>
                      <p className="text-xs text-stone-500 mt-0.5 line-clamp-2">
                        {market.description || 'Verified wholesale layer egg procurement depot.'}
                      </p>
                    </div>

                    {/* Large Orange Price Display */}
                    <div className="bg-[#fffcf7] p-4 rounded-xl border border-orange-100 space-y-1">
                      <span className="text-[11px] font-semibold text-stone-500 block uppercase tracking-wider">
                        Wholesale Price
                      </span>
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-3xl sm:text-4xl font-extrabold font-mono text-orange-600 tracking-tight">
                          Rs. {market.pricePerEgg}
                        </span>
                        <span className="text-xs font-semibold text-stone-500">
                          / egg
                        </span>
                      </div>
                    </div>

                    {/* Available Buying Capacity Badge */}
                    <div className="flex items-center justify-between p-3 bg-stone-50 rounded-xl border border-stone-100 text-xs">
                      <span className="text-stone-500">Buying Capacity:</span>
                      <span className="font-mono font-bold text-emerald-900 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 text-[11px]">
                        {market.availableCapacity.toLocaleString()} Eggs
                      </span>
                    </div>

                    {/* Small Quantity & Processing Time Badges */}
                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="p-2.5 bg-stone-50 rounded-lg border border-stone-100 text-stone-600">
                        <span className="block text-[10px] text-stone-400 font-semibold uppercase">Batch Limits</span>
                        <strong className="text-stone-800 font-mono">
                          {market.minimumQuantity} – {market.maximumQuantity} Eggs
                        </strong>
                      </div>

                      <div className="p-2.5 bg-stone-50 rounded-lg border border-stone-100 text-stone-600">
                        <span className="block text-[10px] text-stone-400 font-semibold uppercase">Processing</span>
                        <strong className="text-stone-800">
                          {market.processingTime}
                        </strong>
                      </div>
                    </div>
                  </div>

                  {/* Card Bottom: Large Orange Gradient Selection Button */}
                  <div className="p-6 pt-0">
                    <button
                      type="button"
                      onClick={() => handleOpenMarket(market)}
                      disabled={!isEligible}
                      className="w-full py-3.5 px-4 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 disabled:from-stone-200 disabled:to-stone-200 disabled:text-stone-400 disabled:cursor-not-allowed text-white font-bold rounded-xl text-xs transition-all shadow-md shadow-orange-500/20 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>
                        {!isEligible
                          ? `Requires Min ${market.minimumQuantity} Eggs`
                          : `Select This Market`}
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Transparent Bailment Guidelines Note */}
          <div className="p-4 bg-amber-50/70 rounded-2xl border border-amber-200 text-xs text-amber-900 flex items-start gap-3">
            <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-bold block">Integrity & Farm Audit Principle</span>
              <p className="text-[11px] text-amber-800 leading-relaxed">
                Only eggs allocated from genuine physical farm production and verified in your balance are eligible for market dispatch. 
                Selling requests atomically reserve eggs from your account balance. Admin accountants verify bank or wallet transactions before marking payments as completed.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* VIEW B: SELLING HISTORY LEDGER                                            */}
      {/* ========================================================================= */}
      {activeSubTab === 'history' && (
        <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden space-y-4">
          <div className="p-5 border-b border-stone-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-stone-50/50">
            <div>
              <h3 className="font-bold text-base text-stone-900 font-display">
                Your Selling Orders History ({myOrders.length})
              </h3>
              <p className="text-xs text-stone-500">
                Live ledger of wholesale egg sales submitted to accredited mandis.
              </p>
            </div>
            <button
              onClick={() => setActiveSubTab('markets')}
              className="px-3.5 py-1.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition-colors self-start sm:self-auto cursor-pointer"
            >
              + Sell More Eggs
            </button>
          </div>

          {myOrders.length === 0 ? (
            <div className="py-16 text-center text-xs text-stone-500 space-y-2">
              <Egg className="w-10 h-10 text-stone-300 mx-auto" />
              <p className="font-bold text-stone-700">No egg selling orders placed yet.</p>
              <p className="text-stone-400">
                Switch to Available Markets above and choose Green Nest, Sultan Egg Point, or Golden Harvest.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-stone-50 border-b border-stone-200 text-stone-500 font-semibold uppercase text-[10px] tracking-wider">
                    <th className="py-3 px-4">Order ID</th>
                    <th className="py-3 px-4">Market Name</th>
                    <th className="py-3 px-4">Egg Quantity</th>
                    <th className="py-3 px-4">Price / Egg</th>
                    <th className="py-3 px-4">Total Amount</th>
                    <th className="py-3 px-4">Payout Destination</th>
                    <th className="py-3 px-4">Request Date</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 font-mono">
                  {myOrders.map(order => (
                    <tr key={order.id} className="hover:bg-amber-50/30 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-stone-900">
                        {order.id}
                      </td>
                      <td className="py-3.5 px-4 font-sans font-bold text-emerald-950">
                        {order.marketName}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-orange-600">
                        {order.eggQuantity} Eggs
                      </td>
                      <td className="py-3.5 px-4 text-stone-700">
                        Rs. {order.pricePerEgg}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-emerald-900 text-sm">
                        Rs. {order.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 font-sans text-[11px] text-stone-700">
                        <span className="font-semibold block">{order.payoutMethod}</span>
                        <span className="text-stone-500 font-mono text-[10px] block">
                          {order.accountHolderName} · {order.accountNumber}
                        </span>
                        {order.bankName && (
                          <span className="text-stone-400 text-[10px] block">{order.bankName}</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-stone-500 font-sans text-[11px]">
                        {order.createdAt}
                      </td>
                      <td className="py-3.5 px-4 font-sans">
                        {getOrderStatusBadge(order.orderStatus)}
                        {order.txReference && (
                          <span className="block text-[10px] font-mono text-emerald-900 mt-1">
                            Ref: {order.txReference}
                          </span>
                        )}
                        {order.adminNotes && (
                          <span className="block text-[10px] text-stone-500 mt-0.5">
                            Note: {order.adminNotes}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* SELLING FORM MODAL (STEP 1 TO STEP 4 AS SPECIFIED IN REQUIREMENT C)        */}
      {/* ========================================================================= */}
      {selectedMarket && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl border border-stone-200 shadow-2xl max-w-lg w-full overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="px-6 py-5 bg-[#fffcf7] border-b border-orange-100 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-orange-700 bg-orange-100/80 px-2.5 py-0.5 rounded-full">
                    Mandi Selling Form
                  </span>
                  <span className="text-xs text-stone-500 font-mono">
                    Rs. {selectedMarket.pricePerEgg} / egg
                  </span>
                </div>
                <h3 className="font-bold text-lg font-display text-stone-900 mt-1">
                  {selectedMarket.marketName}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedMarket(null)}
                className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 flex items-center justify-center font-bold text-sm transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmSelling} className="p-6 space-y-5 text-xs">
              
              {/* STEP 1: Select payment destination type */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-stone-800 text-xs">
                    STEP 1: Select Payment Destination Type *
                  </label>
                  <span className="text-[11px] text-stone-400">Where you receive funds</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setDestinationType('bank')}
                    className={`p-3.5 rounded-2xl border text-left transition-all flex items-center gap-3 cursor-pointer ${
                      destinationType === 'bank'
                        ? 'border-orange-500 bg-orange-50/60 text-orange-950 ring-2 ring-orange-500/20'
                        : 'border-stone-200 hover:border-stone-300 bg-stone-50/40 text-stone-700'
                    }`}
                  >
                    <Building2 className={`w-5 h-5 ${destinationType === 'bank' ? 'text-orange-600' : 'text-stone-400'}`} />
                    <div>
                      <span className="font-bold block text-xs">1. Bank Account</span>
                      <span className="text-[10px] text-stone-500 block">IBFT / Raast Payout</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDestinationType('wallet')}
                    className={`p-3.5 rounded-2xl border text-left transition-all flex items-center gap-3 cursor-pointer ${
                      destinationType === 'wallet'
                        ? 'border-orange-500 bg-orange-50/60 text-orange-950 ring-2 ring-orange-500/20'
                        : 'border-stone-200 hover:border-stone-300 bg-stone-50/40 text-stone-700'
                    }`}
                  >
                    <Smartphone className={`w-5 h-5 ${destinationType === 'wallet' ? 'text-orange-600' : 'text-stone-400'}`} />
                    <div>
                      <span className="font-bold block text-xs">2. Mobile Wallet</span>
                      <span className="text-[10px] text-stone-500 block">Easypaisa / JazzCash</span>
                    </div>
                  </button>
                </div>
              </div>

              {/* STEP 2: Destination-specific Fields */}
              <div className="space-y-3 p-4 bg-stone-50 rounded-2xl border border-stone-200">
                <span className="font-bold text-stone-800 block text-xs">
                  STEP 2: Enter Payout Details ({destinationType === 'bank' ? 'Bank Account' : 'Mobile Wallet'}) *
                </span>

                {/* Bank Account Fields */}
                {destinationType === 'bank' && (
                  <div className="space-y-3">
                    <div>
                      <label className="font-semibold text-stone-700 block mb-1">
                        Bank Name *
                      </label>
                      <select
                        value={bankName}
                        onChange={e => setBankName(e.target.value)}
                        className="w-full px-3.5 py-2.5 border border-stone-300 rounded-xl bg-white text-xs text-stone-900 focus:outline-hidden focus:border-orange-500"
                        required
                      >
                        <option value="Meezan Bank Ltd">Meezan Bank Ltd (Islamic Banking)</option>
                        <option value="Habib Bank Ltd (HBL)">Habib Bank Ltd (HBL)</option>
                        <option value="United Bank Ltd (UBL)">United Bank Ltd (UBL)</option>
                        <option value="MCB Bank Ltd">MCB Bank Ltd</option>
                        <option value="Bank Alfalah">Bank Alfalah</option>
                        <option value="Faysal Bank">Faysal Bank</option>
                        <option value="Allied Bank Ltd">Allied Bank Ltd</option>
                        <option value="Standard Chartered">Standard Chartered Pakistan</option>
                        <option value="National Bank of Pakistan">National Bank of Pakistan (NBP)</option>
                        <option value="Other Commercial Bank">Other Commercial Bank</option>
                      </select>
                    </div>

                    <div>
                      <label className="font-semibold text-stone-700 block mb-1">
                        Account Holder Name *
                      </label>
                      <input
                        type="text"
                        value={accountHolderName}
                        onChange={e => setAccountHolderName(e.target.value)}
                        placeholder="Exact title as on bank account"
                        className="w-full px-3.5 py-2.5 border border-stone-300 rounded-xl bg-white text-xs text-stone-900 focus:outline-hidden focus:border-orange-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="font-semibold text-stone-700 block mb-1">
                        Account Number *
                      </label>
                      <input
                        type="text"
                        value={accountNumber}
                        onChange={e => setAccountNumber(e.target.value)}
                        placeholder="e.g. 01010109283491"
                        className="w-full px-3.5 py-2.5 border border-stone-300 rounded-xl bg-white font-mono text-xs text-stone-900 focus:outline-hidden focus:border-orange-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="font-semibold text-stone-700 block mb-1">
                        IBAN (Optional)
                      </label>
                      <input
                        type="text"
                        value={iban}
                        onChange={e => setIban(e.target.value)}
                        placeholder="e.g. PK42 MEZN 0001 0928 3491 0001"
                        className="w-full px-3.5 py-2.5 border border-stone-300 rounded-xl bg-white font-mono text-xs text-stone-900 focus:outline-hidden focus:border-orange-500"
                      />
                    </div>
                  </div>
                )}

                {/* Mobile Wallet Fields */}
                {destinationType === 'wallet' && (
                  <div className="space-y-3">
                    <div>
                      <label className="font-semibold text-stone-700 block mb-1">
                        Select Wallet Provider *
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {(['Easypaisa', 'JazzCash'] as const).map(w => (
                          <button
                            key={w}
                            type="button"
                            onClick={() => setWalletProvider(w)}
                            className={`py-2 px-3 rounded-xl border text-center font-bold text-xs transition-colors cursor-pointer ${
                              walletProvider === w
                                ? 'bg-orange-500 text-white border-orange-500 shadow-xs'
                                : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-50'
                            }`}
                          >
                            {w}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="font-semibold text-stone-700 block mb-1">
                        Account Holder Name *
                      </label>
                      <input
                        type="text"
                        value={accountHolderName}
                        onChange={e => setAccountHolderName(e.target.value)}
                        placeholder="Name registered on mobile wallet"
                        className="w-full px-3.5 py-2.5 border border-stone-300 rounded-xl bg-white text-xs text-stone-900 focus:outline-hidden focus:border-orange-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="font-semibold text-stone-700 block mb-1">
                        {walletProvider} Mobile Wallet Number *
                      </label>
                      <input
                        type="text"
                        value={accountNumber}
                        onChange={e => setAccountNumber(e.target.value)}
                        placeholder="e.g. 0300 1234567"
                        className="w-full px-3.5 py-2.5 border border-stone-300 rounded-xl bg-white font-mono text-xs text-stone-900 focus:outline-hidden focus:border-orange-500"
                        required
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* STEP 3: Selling Information & Auto-Calculated Total */}
              <div className="space-y-3">
                <span className="font-bold text-stone-800 block text-xs">
                  STEP 3: Selling Information & Calculation *
                </span>

                <div className="grid grid-cols-2 gap-3 p-3 bg-stone-50 rounded-xl border border-stone-200 text-[11px]">
                  <div>
                    <span className="text-stone-400 block">Selected Market:</span>
                    <strong className="text-stone-900 font-semibold">{selectedMarket.marketName}</strong>
                  </div>
                  <div>
                    <span className="text-stone-400 block">Price Per Egg:</span>
                    <strong className="text-orange-600 font-mono font-bold">Rs. {selectedMarket.pricePerEgg}</strong>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-stone-700">
                      Quantity to Sell (Eggs) *
                    </label>
                    <span className="text-[11px] text-stone-500">
                      Available: <strong className="font-mono text-emerald-900">{availableEggs}</strong>
                    </span>
                  </div>

                  <input
                    type="number"
                    min={selectedMarket.minimumQuantity}
                    max={Math.min(selectedMarket.maximumQuantity, availableEggs)}
                    value={eggQuantity}
                    onChange={e => setEggQuantity(parseInt(e.target.value) || 0)}
                    className="w-full px-3.5 py-2.5 border border-stone-300 rounded-xl font-mono text-base font-bold text-stone-900 focus:outline-hidden focus:border-orange-500"
                    required
                  />

                  {/* Quick Chips */}
                  <div className="flex flex-wrap gap-2 pt-1">
                    {[1, 2, 5, 10, 25, 50, 100].map(val => (
                      val <= availableEggs && val >= selectedMarket.minimumQuantity && (
                        <button
                          key={val}
                          type="button"
                          onClick={() => setEggQuantity(val)}
                          className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-[11px] font-mono font-medium cursor-pointer"
                        >
                          {val} Eggs
                        </button>
                      )
                    ))}
                    {availableEggs >= selectedMarket.minimumQuantity && (
                      <button
                        type="button"
                        onClick={() => setEggQuantity(Math.min(selectedMarket.maximumQuantity, availableEggs))}
                        className="px-2.5 py-1 bg-orange-100 hover:bg-orange-200 text-orange-900 font-bold rounded-lg text-[11px] font-mono cursor-pointer"
                      >
                        Sell All ({Math.min(selectedMarket.maximumQuantity, availableEggs)})
                      </button>
                    )}
                  </div>
                </div>

                {/* Auto Calculated Total Box */}
                <div className="p-4 bg-orange-50/80 rounded-2xl border border-orange-200/80 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-orange-950/70 block font-medium">Total Calculated Payout</span>
                    <span className="font-semibold text-stone-700 text-xs">
                      {eggQuantity} eggs × Rs. {selectedMarket.pricePerEgg}
                    </span>
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold font-mono text-orange-600 tabular-nums">
                    Rs. {(eggQuantity * selectedMarket.pricePerEgg).toLocaleString()}
                  </div>
                </div>
              </div>

              {/* STEP 4: Confirm Selling Request Button */}
              <div className="pt-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedMarket(null)}
                  className="w-1/3 py-3 border border-stone-300 text-stone-700 font-bold rounded-xl text-xs hover:bg-stone-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || eggQuantity < selectedMarket.minimumQuantity || eggQuantity > availableEggs}
                  className="w-2/3 py-3 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 disabled:from-stone-200 disabled:to-stone-200 disabled:text-stone-400 disabled:cursor-not-allowed text-white font-bold rounded-xl text-xs shadow-md shadow-orange-500/20 cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>{isSubmitting ? 'Reserving Eggs...' : 'CONFIRM SELLING REQUEST'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
