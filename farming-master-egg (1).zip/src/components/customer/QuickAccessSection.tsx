import React from 'react';
import { 
  Wallet, 
  ArrowUpRight, 
  Store, 
  Headphones, 
  FileText, 
  TrendingUp, 
  Layers
} from 'lucide-react';

export type QuickAccessTarget = 
  | 'deposit' 
  | 'withdraw' 
  | 'sell-eggs' 
  | 'support' 
  | 'transactions' 
  | 'investment' 
  | 'my-hens';

interface QuickAccessSectionProps {
  onSelect: (target: QuickAccessTarget) => void;
  activeTarget?: string;
}

export const QuickAccessSection: React.FC<QuickAccessSectionProps> = ({ onSelect, activeTarget }) => {
  // Streamlined Quick Access Shortcuts (Withdraw merged into Egg Sell)
  const buttons: {
    id: QuickAccessTarget;
    label: string;
    description: string;
    gradient: string;
    icon: React.ReactNode;
    shadowColor: string;
    borderAccent: string;
  }[] = [
    {
      id: 'deposit',
      label: 'Deposit',
      description: 'Add Funds for Hens',
      gradient: 'from-orange-500 via-amber-500 to-orange-600',
      icon: <Wallet className="w-6 h-6 text-white" />,
      shadowColor: 'shadow-orange-500/20',
      borderAccent: 'border-orange-200 hover:border-orange-400',
    },
    {
      id: 'sell-eggs',
      label: 'Egg Sell',
      description: 'Sell Eggs & Receive Payout',
      gradient: 'from-amber-500 via-orange-500 to-amber-600',
      icon: <Store className="w-6 h-6 text-white" />,
      shadowColor: 'shadow-amber-500/25',
      borderAccent: 'border-amber-300 hover:border-amber-500',
    },
    {
      id: 'my-hens',
      label: 'My Hens',
      description: 'Tagged Physical Flock',
      gradient: 'from-rose-500 via-red-500 to-orange-600',
      icon: <Layers className="w-6 h-6 text-white" />,
      shadowColor: 'shadow-rose-500/20',
      borderAccent: 'border-rose-200 hover:border-rose-400',
    },
    {
      id: 'investment',
      label: 'Your Investment',
      description: 'Flock Yield & Asset Value',
      gradient: 'from-yellow-500 via-amber-500 to-yellow-600',
      icon: <TrendingUp className="w-6 h-6 text-white" />,
      shadowColor: 'shadow-amber-500/20',
      borderAccent: 'border-yellow-200 hover:border-yellow-400',
    },
    {
      id: 'transactions',
      label: 'Transaction History',
      description: 'Audit Ledger & Slips',
      gradient: 'from-orange-600 via-amber-600 to-orange-700',
      icon: <FileText className="w-6 h-6 text-white" />,
      shadowColor: 'shadow-orange-600/20',
      borderAccent: 'border-orange-200 hover:border-orange-400',
    },
    {
      id: 'support',
      label: 'Support',
      description: 'WhatsApp Care Desk',
      gradient: 'from-teal-600 via-emerald-600 to-teal-700',
      icon: <Headphones className="w-6 h-6 text-white" />,
      shadowColor: 'shadow-teal-600/20',
      borderAccent: 'border-teal-200 hover:border-teal-400',
    },
  ];

  return (
    <div className="bg-white rounded-3xl p-5 sm:p-6 border border-emerald-950/10 shadow-xs mb-8">
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-stone-100">
        <div>
          <h2 className="text-sm sm:text-base font-bold font-display text-emerald-950 uppercase tracking-wider flex items-center gap-2">
            <span>QUICK ACCESS</span>
            <span className="text-[10px] font-sans font-normal text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              Operations Shortcuts
            </span>
          </h2>
        </div>
        <span className="text-xs text-stone-400 hidden sm:block">
          One-tap access to primary farming workflows
        </span>
      </div>

      {/* 6 Responsive Shortcut Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {buttons.map(btn => {
          const isActive = activeTarget === btn.id;

          return (
            <button
              key={btn.id}
              onClick={() => onSelect(btn.id)}
              className={`p-3.5 rounded-2xl border text-center transition-all duration-200 flex flex-col items-center justify-between gap-2.5 group cursor-pointer hover:-translate-y-0.5 ${
                isActive
                  ? 'bg-amber-50/70 border-orange-400 ring-2 ring-orange-500/20'
                  : `bg-stone-50/60 ${btn.borderAccent} hover:bg-white`
              }`}
            >
              <div
                className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${btn.gradient} flex items-center justify-center shadow-md ${btn.shadowColor} group-hover:scale-105 transition-transform`}
              >
                {btn.icon}
              </div>

              <div>
                <span className="font-bold text-xs text-stone-900 block leading-tight">
                  {btn.label}
                </span>
                <span className="text-[10px] text-stone-500 block mt-0.5 leading-snug truncate max-w-[110px]">
                  {btn.description}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
