import React, { useState, useMemo } from 'react';
import { 
  FileText, 
  ArrowDownLeft, 
  ArrowUpRight, 
  ShoppingBag, 
  Receipt, 
  Download, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Eye, 
  X,
  Search,
  Filter
} from 'lucide-react';
import { DepositRequest, PurchaseOrder, WithdrawalRequest, CustomerStatement, AppUser } from '../../types';
import { useApp } from '../../context/AppContext';

interface TransactionHistoryViewProps {
  currentUser: AppUser | null;
  depositRequests: DepositRequest[];
  purchases: PurchaseOrder[];
  withdrawals: WithdrawalRequest[];
  customerStatements: CustomerStatement[];
}

export const TransactionHistoryView: React.FC<TransactionHistoryViewProps> = ({
  currentUser,
  depositRequests,
  purchases,
  withdrawals,
  customerStatements,
}) => {
  const { eggSellingOrders } = useApp();
  const [filterType, setFilterType] = useState<'all' | 'deposits' | 'purchases' | 'withdrawals'>('all');
  const [selectedTx, setSelectedTx] = useState<any | null>(null);

  // Filter items for current user and build unified chronological transactions list
  const transactions = useMemo(() => {
    if (!currentUser) return [];

    const list: Array<{
      id: string;
      dateTime: string;
      rawDate: string;
      type: 'Deposit' | 'Hen Purchase' | 'Withdrawal' | 'Profit Share' | 'Egg Sell Payout';
      category: 'deposits' | 'purchases' | 'withdrawals';
      amount: number;
      isCredit: boolean;
      paymentMethod: string;
      status: string;
      details: string;
      reference: string;
      receiptUrl?: string;
      notes?: string;
    }> = [];

    // Deposits
    depositRequests.filter(d => d.customerId === currentUser.id).forEach(d => {
      list.push({
        id: d.id,
        dateTime: d.createdAt,
        rawDate: d.createdAt,
        type: 'Deposit',
        category: 'deposits',
        amount: d.amount,
        isCredit: true,
        paymentMethod: d.methodName,
        status: d.status,
        details: `Wallet balance top-up via ${d.methodName}`,
        reference: d.transactionReference,
        receiptUrl: d.receiptUrl,
        notes: d.adminNote,
      });
    });

    // Purchases
    purchases.filter(p => p.customerId === currentUser.id).forEach(p => {
      list.push({
        id: p.id,
        dateTime: p.createdAt,
        rawDate: p.createdAt,
        type: 'Hen Purchase',
        category: 'purchases',
        amount: p.totalAmount,
        isCredit: false,
        paymentMethod: p.paymentMethod,
        status: p.status,
        details: `Acquired ${p.quantity} Layer Hen${p.quantity > 1 ? 's' : ''} (Rs. 500/hen)`,
        reference: p.transactionReference,
        receiptUrl: p.receiptSlipUrl,
        notes: p.notes,
      });
    });

    // Egg Sell Orders (Unified Payout Requests)
    eggSellingOrders.filter(o => o.userId === currentUser.id).forEach(o => {
      list.push({
        id: o.id,
        dateTime: o.createdAt,
        rawDate: o.createdAt,
        type: 'Egg Sell Payout',
        category: 'withdrawals',
        amount: o.totalAmount,
        isCredit: false,
        paymentMethod: o.payoutMethod,
        status: o.orderStatus,
        details: `Sold ${o.eggQuantity} eggs to ${o.marketName} at Rs. ${o.pricePerEgg}/egg`,
        reference: o.txReference || 'Pending Mandi Verification',
        notes: o.adminNotes,
      });
    });

    // Withdrawals (Legacy/Standard)
    withdrawals.filter(w => w.customerId === currentUser.id).forEach(w => {
      list.push({
        id: w.id,
        dateTime: w.requestedAt,
        rawDate: w.requestedAt,
        type: 'Egg Sell Payout',
        category: 'withdrawals',
        amount: w.amount,
        isCredit: false,
        paymentMethod: w.paymentMethod,
        status: w.status,
        details: `Disbursal to ${w.accountTitle} (${w.accountNumber})`,
        reference: w.transactionReference || 'In Queue',
        notes: w.adminNotes,
      });
    });

    // Statements / Profit Distributions
    customerStatements.filter(s => s.customerId === currentUser.id).forEach(s => {
      list.push({
        id: s.id,
        dateTime: s.distributedAt,
        rawDate: s.distributedAt,
        type: 'Profit Share',
        category: 'deposits',
        amount: s.netPayableAmount,
        isCredit: true,
        paymentMethod: 'Flock Net Egg Sales',
        status: 'credited',
        details: `Net egg sales distribution for ${s.cyclePeriod} (${s.hensOwned} hens)`,
        reference: `FLOCK-CYCLE-${s.cyclePeriod}`,
      });
    });

    // Sort descending by date
    return list.sort((a, b) => b.rawDate.localeCompare(a.rawDate));
  }, [currentUser, depositRequests, purchases, withdrawals, eggSellingOrders, customerStatements]);

  const filteredList = useMemo(() => {
    if (filterType === 'all') return transactions;
    return transactions.filter(t => t.category === filterType);
  }, [transactions, filterType]);

  const handleDownloadReceipt = (tx: any) => {
    const text = `=========================================
FARMING MASTER EGG — OFFICIAL TRANSACTION RECEIPT
REAL FARMING · REAL HENS · REAL EGGS
Commercial Layer Enterprise, Mandra-Chakwal, Punjab
=========================================
Receipt ID:       ${tx.id}
Date & Time:      ${tx.dateTime}
Customer:         ${currentUser?.name} (${currentUser?.email})
Customer Phone:   ${currentUser?.phone}
-----------------------------------------
Transaction Type: ${tx.type}
Amount:           Rs. ${tx.amount.toLocaleString()} PKR
Payment Channel:  ${tx.paymentMethod}
Reference (TRX):  ${tx.reference}
Status:           ${tx.status.toUpperCase()}
Details:          ${tx.details}
${tx.notes ? `Admin Notes:      ${tx.notes}\n` : ''}-----------------------------------------
Official Custody & Ledger Verification:
Farming Master Egg Agro Enterprises
operations@farmingmasteregg.com
=========================================`;

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `receipt_${tx.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'verified':
      case 'approved':
      case 'paid':
      case 'credited':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-200 inline-flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-700" /> {status.toUpperCase()}
          </span>
        );
      case 'rejected':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-900 border border-red-200 inline-flex items-center gap-1">
            <XCircle className="w-3 h-3 text-red-700" /> DECLINED
          </span>
        );
      case 'under_review':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-900 border border-blue-200 inline-flex items-center gap-1">
            <Clock className="w-3 h-3 text-blue-700" /> IN REVIEW
          </span>
        );
      case 'pending':
      default:
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200 inline-flex items-center gap-1">
            <Clock className="w-3 h-3 text-amber-700" /> PENDING
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-emerald-950/10 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-emerald-950 tracking-tight">
            TRANSACTION HISTORY
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Complete financial ledger of deposits, hen purchases, withdrawals, and egg profit shares.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center gap-1.5 p-1 bg-stone-100 rounded-xl text-xs font-semibold self-start sm:self-auto overflow-x-auto">
          {[
            { id: 'all', label: `All (${transactions.length})` },
            { id: 'deposits', label: `Deposits` },
            { id: 'purchases', label: `Purchases` },
            { id: 'withdrawals', label: `Egg Sell Payouts` },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilterType(f.id as any)}
              className={`px-3 py-1.5 rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                filterType === f.id
                  ? 'bg-white text-emerald-950 shadow-xs font-bold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Transactions Table Card */}
      <div className="bg-white rounded-2xl border border-emerald-950/10 shadow-xs overflow-hidden">
        
        {filteredList.length === 0 ? (
          <div className="py-16 text-center text-xs text-stone-500 space-y-2">
            <FileText className="w-10 h-10 text-stone-300 mx-auto" />
            <p className="font-semibold text-stone-700">No transactions recorded yet.</p>
            <p>Your deposit, acquisition, and payout history will appear here with downloadable receipts.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-semibold bg-stone-50/60">
                  <th className="p-3.5">Tx ID</th>
                  <th className="p-3.5">Date & Time</th>
                  <th className="p-3.5">Type</th>
                  <th className="p-3.5">Payment Method</th>
                  <th className="p-3.5">Amount</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Reference</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredList.map(tx => (
                  <tr key={tx.id} className="hover:bg-stone-50/80 transition-colors">
                    <td className="p-3.5 font-mono font-bold text-emerald-950">{tx.id}</td>
                    <td className="p-3.5 text-stone-600 font-mono text-[11px]">{tx.dateTime}</td>
                    <td className="p-3.5">
                      <div className="font-semibold text-stone-900 flex items-center gap-1.5">
                        {tx.isCredit ? (
                          <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <ArrowUpRight className="w-3.5 h-3.5 text-orange-600" />
                        )}
                        <span>{tx.type}</span>
                      </div>
                    </td>
                    <td className="p-3.5 text-stone-700 font-medium">{tx.paymentMethod}</td>
                    <td className="p-3.5 font-mono font-bold text-sm tabular-nums">
                      <span className={tx.isCredit ? 'text-emerald-700' : 'text-stone-900'}>
                        {tx.isCredit ? '+' : '-'} Rs. {tx.amount.toLocaleString()}
                      </span>
                    </td>
                    <td className="p-3.5">{getStatusBadge(tx.status)}</td>
                    <td className="p-3.5 font-mono text-stone-600 text-[11px] truncate max-w-[130px]">
                      {tx.reference}
                    </td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedTx(tx)}
                          className="p-1.5 rounded-lg text-stone-500 hover:text-emerald-900 hover:bg-stone-100 transition-colors"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDownloadReceipt(tx)}
                          className="p-1.5 rounded-lg text-emerald-700 hover:text-emerald-900 hover:bg-emerald-50 transition-colors"
                          title="Download Receipt"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      </div>

      {/* Transaction Details Modal */}
      {selectedTx && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div>
                <h3 className="font-bold text-base text-emerald-950 font-display">
                  Transaction Receipt Details
                </h3>
                <span className="text-xs text-stone-400 font-mono">ID: {selectedTx.id}</span>
              </div>
              <button
                onClick={() => setSelectedTx(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 bg-stone-50 rounded-xl space-y-2.5 text-xs">
              <div className="flex justify-between">
                <span className="text-stone-500">Transaction Type:</span>
                <span className="font-bold text-stone-900">{selectedTx.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Timestamp:</span>
                <span className="font-mono text-stone-700">{selectedTx.dateTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Amount:</span>
                <span className="font-mono font-bold text-sm text-emerald-950">
                  Rs. {selectedTx.amount.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Payment Gateway:</span>
                <span className="font-medium text-stone-900">{selectedTx.paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Transaction Reference:</span>
                <span className="font-mono text-stone-800">{selectedTx.reference}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-stone-500">Verification Status:</span>
                <div>{getStatusBadge(selectedTx.status)}</div>
              </div>
              <div className="pt-2 border-t border-stone-200/60">
                <span className="text-stone-500 block mb-0.5">Details:</span>
                <span className="text-stone-800">{selectedTx.details}</span>
              </div>
              {selectedTx.notes && (
                <div className="pt-2 border-t border-stone-200/60 text-stone-600">
                  <span className="text-stone-500 block mb-0.5">Farm Notes:</span>
                  <span>{selectedTx.notes}</span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => setSelectedTx(null)}
                className="px-4 py-2 border border-stone-200 text-stone-700 rounded-xl text-xs font-semibold hover:bg-stone-50"
              >
                Close
              </button>

              <button
                onClick={() => handleDownloadReceipt(selectedTx)}
                className="px-4 py-2 bg-emerald-800 text-white rounded-xl text-xs font-bold hover:bg-emerald-900 flex items-center gap-1.5 shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save Digital Slip</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
