import React from 'react';
import { 
  Building2, 
  MapPin, 
  ShieldCheck, 
  Award, 
  CheckCircle, 
  Phone, 
  Mail, 
  Activity,
  Egg,
  Users
} from 'lucide-react';
import { Shed, Hen, EggProductionRecord } from '../../types';

interface FarmInfoViewProps {
  sheds: Shed[];
  hens: Hen[];
  productionRecords: EggProductionRecord[];
  onExploreMarketplace: () => void;
}

export const FarmInfoView: React.FC<FarmInfoViewProps> = ({
  sheds,
  hens,
  productionRecords,
  onExploreMarketplace,
}) => {
  const totalFarmHens = sheds.reduce((sum, s) => sum + s.currentHens, 0);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-emerald-950/10 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-emerald-950 tracking-tight">
            COMMUNITY & FARM INFORMATION
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Physical infrastructure, climate control systems, and biosecurity protocols in Mandra-Chakwal.
          </p>
        </div>

        <button
          onClick={onExploreMarketplace}
          className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-xl shadow-xs self-start sm:self-auto"
        >
          View Available Hens
        </button>
      </div>

      {/* Farm Overview Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-stone-500 uppercase block font-sans">Total Flock Size</span>
          <div className="text-2xl font-bold font-mono text-emerald-950">{totalFarmHens.toLocaleString()} Birds</div>
          <span className="text-[10px] text-stone-400">Maintained by 12 technicians</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-stone-500 uppercase block font-sans">Active Sheds</span>
          <div className="text-2xl font-bold font-mono text-emerald-950">{sheds.length} Units</div>
          <span className="text-[10px] text-stone-400">Tunnel ventilated</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-stone-500 uppercase block font-sans">Biosecurity Level</span>
          <div className="text-2xl font-bold font-display text-emerald-700">Tier 2</div>
          <span className="text-[10px] text-emerald-800 font-semibold">Disinfection gate active</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-stone-500 uppercase block font-sans">Location</span>
          <div className="text-base font-bold text-stone-900 truncate">Mandra-Chakwal</div>
          <span className="text-[10px] text-stone-400">Punjab, Pakistan</span>
        </div>
      </div>

      {/* Shed Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {sheds.map(shed => (
          <div key={shed.id} className="bg-white rounded-2xl border border-emerald-950/10 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-stone-100">
              <span className="font-mono font-bold text-xs text-emerald-800">{shed.code}</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-900 border border-emerald-200">
                Active Shed
              </span>
            </div>

            <div>
              <h3 className="font-bold text-sm text-emerald-950 font-display">{shed.name}</h3>
              <div className="text-xs text-stone-500 mt-0.5">
                Current Flock: <strong className="font-mono text-stone-800">{shed.currentHens}</strong> / {shed.capacity} Capacity
              </div>
            </div>

            <div className="p-3 bg-stone-50 rounded-xl space-y-1.5 text-xs text-stone-600 border border-stone-200/70">
              <div className="flex justify-between">
                <span>Temperature:</span>
                <span className="font-mono font-bold text-stone-900">{shed.temperatureC}°C</span>
              </div>
              <div className="flex justify-between">
                <span>Humidity:</span>
                <span className="font-mono font-bold text-stone-900">{shed.humidityPct}%</span>
              </div>
              <div className="flex justify-between">
                <span>Ventilation:</span>
                <span className="text-stone-800 truncate max-w-[150px]">{shed.ventilation}</span>
              </div>
              <div className="flex justify-between">
                <span>Drinking Net:</span>
                <span className="text-stone-800 truncate max-w-[150px]">{shed.drinkingSystem}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Contact & Official Farm Visits */}
      <div className="bg-stone-50 rounded-2xl border border-stone-200/80 p-6 space-y-3 text-xs text-stone-600">
        <h3 className="font-bold text-sm text-stone-900 font-display flex items-center gap-2">
          <Building2 className="w-4 h-4 text-emerald-800" />
          <span>Biosecurity Physical Farm Visits</span>
        </h3>
        <p className="leading-relaxed">
          Customer hen owners are welcome to schedule physical farm inspections. To preserve our strict avian biosecurity barrier, visits require 48 hours advance notice, protective suits, and sanitization tunnel clearance.
        </p>
        <div className="flex flex-wrap gap-4 pt-2 text-stone-800 font-semibold">
          <div className="flex items-center gap-1.5">
            <Phone className="w-3.5 h-3.5 text-emerald-800" />
            <span>+92 333 4920199</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Mail className="w-3.5 h-3.5 text-emerald-800" />
            <span>operations@farmingmasteregg.com</span>
          </div>
        </div>
      </div>

    </div>
  );
};
