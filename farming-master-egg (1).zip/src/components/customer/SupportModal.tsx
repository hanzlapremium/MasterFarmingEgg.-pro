import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Headphones, 
  X, 
  Phone, 
  Mail, 
  MessageCircle, 
  Clock, 
  Calendar, 
  AlertTriangle, 
  ShieldCheck, 
  ExternalLink 
} from 'lucide-react';

interface SupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateAgreement: () => void;
}

export const SupportModal: React.FC<SupportModalProps> = ({
  isOpen,
  onClose,
  onNavigateAgreement,
}) => {
  const { supportSetting } = useApp();

  if (!isOpen) return null;

  // Clean numbers for tel: and wa.me protocols
  const cleanPhoneTel = supportSetting.phoneNumber.replace(/[^0-9+]/g, '');
  const cleanWhatsapp = supportSetting.whatsappNumber.replace(/[^0-9]/g, '');
  const whatsappUrl = `https://wa.me/${cleanWhatsapp}?text=${encodeURIComponent('Assalam-o-Alaikum Farming Master Egg Support, I have an inquiry regarding my physical hen custody / egg collection records.')}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-stone-200 space-y-5 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-stone-100">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center shadow-xs">
              <Headphones className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-emerald-950 font-display">
                {supportSetting.displayName || 'Farm Customer Support'}
              </h3>
              <p className="text-xs text-stone-500">Official Helplines & Direct Assistance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Support Status Check */}
        {!supportSetting.isEnabled ? (
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl space-y-2 text-xs text-amber-900">
            <div className="flex items-center gap-2 font-bold text-amber-950">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Customer Support Currently Offline</span>
            </div>
            <p className="text-xs text-amber-800 leading-relaxed">
              Our direct customer support lines are currently closed by farm management. Normal support resumes during scheduled working hours. Physical flock feeding, daily egg collection, and biosecurity protocols continue automatically at the physical facility.
            </p>
            <div className="pt-1 text-[11px] text-amber-700 flex items-center gap-2 font-medium">
              <Clock className="w-3.5 h-3.5" />
              <span>Working Hours: {supportSetting.workingHours} ({supportSetting.availabilityDays})</span>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            
            {/* Custom Admin Message */}
            {supportSetting.customMessage && (
              <div className="p-3.5 bg-emerald-50/70 border border-emerald-100 rounded-2xl text-xs text-emerald-900 leading-relaxed">
                {supportSetting.customMessage}
              </div>
            )}

            {/* Direct Action Buttons: Call Now & WhatsApp */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              
              {/* Call Now Button */}
              <a
                href={`tel:${cleanPhoneTel}`}
                className="flex items-center justify-center gap-2.5 px-4 py-3 bg-emerald-800 hover:bg-emerald-900 text-white rounded-2xl font-bold text-xs shadow-md transition-all hover:scale-[1.02] active:scale-95"
              >
                <Phone className="w-4 h-4" />
                <span>Call Helpline</span>
              </a>

              {/* Chat on WhatsApp Button */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2.5 px-4 py-3 bg-[#25D366] hover:bg-[#1EBE5D] text-white rounded-2xl font-bold text-xs shadow-md transition-all hover:scale-[1.02] active:scale-95"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>

            {/* Configured Contact Information Cards */}
            <div className="space-y-2.5 text-xs pt-1">
              
              {/* Phone Line Card */}
              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between">
                <div className="space-y-0.5">
                  <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">
                    Direct Phone Line
                  </span>
                  <div className="font-mono font-bold text-emerald-950 text-sm">
                    {supportSetting.phoneNumber}
                  </div>
                </div>
                <a
                  href={`tel:${cleanPhoneTel}`}
                  className="px-3 py-1.5 bg-white border border-stone-200 hover:border-emerald-600 rounded-xl font-semibold text-emerald-900 text-[11px] shadow-2xs"
                >
                  Call Now
                </a>
              </div>

              {/* WhatsApp Card */}
              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between">
                <div className="space-y-0.5">
                  <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">
                    WhatsApp Business Channel
                  </span>
                  <div className="font-mono font-bold text-emerald-950 text-sm">
                    {supportSetting.whatsappNumber}
                  </div>
                </div>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 bg-white border border-stone-200 hover:border-emerald-600 rounded-xl font-semibold text-emerald-900 text-[11px] shadow-2xs flex items-center gap-1"
                >
                  <span>Open Chat</span>
                  <ExternalLink className="w-3 h-3 text-stone-400" />
                </a>
              </div>

              {/* Working Hours & Availability */}
              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 space-y-1.5">
                <div className="flex items-center gap-2 text-stone-700">
                  <Clock className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span className="font-semibold">Working Hours:</span>
                  <span className="text-stone-900 font-mono">{supportSetting.workingHours}</span>
                </div>
                <div className="flex items-center gap-2 text-stone-700">
                  <Calendar className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span className="font-semibold">Availability:</span>
                  <span className="text-stone-900">{supportSetting.availabilityDays}</span>
                </div>
                {supportSetting.email && (
                  <div className="flex items-center gap-2 text-stone-700 pt-1 border-t border-stone-200/60">
                    <Mail className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span className="font-semibold">Email:</span>
                    <a href={`mailto:${supportSetting.email}`} className="text-emerald-800 hover:underline font-mono">
                      {supportSetting.email}
                    </a>
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

        {/* Footer Link to Legal Custody Agreement */}
        <div className="pt-2 border-t border-stone-100 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={() => {
              onClose();
              onNavigateAgreement();
            }}
            className="text-xs text-emerald-800 hover:text-emerald-950 font-medium underline underline-offset-2 flex items-center gap-1.5"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>View Hen Custody Bailment Agreement</span>
          </button>

          <button
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};

