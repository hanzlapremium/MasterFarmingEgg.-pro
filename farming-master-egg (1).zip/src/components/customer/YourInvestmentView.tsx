import React, { useState } from 'react';
import { 
  Award, 
  Egg, 
  ShieldCheck, 
  FileText, 
  CheckCircle2, 
  MapPin, 
  Download, 
  Clock, 
  AlertCircle,
  ExternalLink
} from 'lucide-react';
import { Hen, PurchaseOrder, AppUser } from '../../types';

interface YourInvestmentViewProps {
  currentUser: AppUser | null;
  myHens: Hen[];
  myPurchases: PurchaseOrder[];
  onOpenCertificate: (hen: Hen) => void;
  onAcquireHens: () => void;
  onOpenAgreement: () => void;
}

export const YourInvestmentView: React.FC<YourInvestmentViewProps> = ({
  currentUser,
  myHens,
  myPurchases,
  onOpenCertificate,
  onAcquireHens,
  onOpenAgreement,
}) => {
  const totalHensPurchased = myPurchases.reduce((sum, p) => p.status === 'verified' ? sum + p.quantity : sum, 0) || myHens.length;
  const totalPurchaseAmount = myPurchases.reduce((sum, p) => p.status === 'verified' ? sum + p.totalAmount : sum, 0) || (myHens.length * 500);
  const activeHens = myHens.filter(h => h.status === 'owned');
  const pendingOrders = myPurchases.filter(p => p.status === 'pending');
  const pendingHensCount = pendingOrders.reduce((sum, p) => sum + p.quantity, 0);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-emerald-950/10 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-emerald-950 tracking-tight">
            YOUR INVESTMENT & HEN OWNERSHIP
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Verifiable commercial layer hen custody records. Physical pullets acquired at Rs. 500 initial price.
          </p>
        </div>

        <button
          onClick={onAcquireHens}
          className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-xl shadow-xs transition-colors self-start sm:self-auto"
        >
          + Acquire Hens (Rs. 500)
        </button>
      </div>

      {/* Honest Agricultural Model Disclosure */}
      <div className="bg-emerald-900 text-white rounded-2xl p-5 shadow-xs space-y-2">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Real Farming · Bailment Custody · No Guaranteed Returns</span>
        </div>
        <p className="text-xs text-emerald-100 leading-relaxed">
          This is an authentic agricultural bailment platform. Your capital directly acquires physical point-of-lay layer pullets (Rs. 500/hen) housed in commercial climate-controlled sheds in Punjab. Flock distributions represent wholesale egg sales net of audited feed mash and veterinary costs. Zero Ponzi schemes, zero fixed daily profits, zero guaranteed multipliers.
        </p>
      </div>

      {/* Key Ownership Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="bg-white p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-stone-500 uppercase block font-sans">
            Total Hens Purchased
          </span>
          <div className="text-2xl font-bold font-display text-emerald-950 font-mono tabular-nums">
            {totalHensPurchased} Birds
          </div>
          <span className="text-[10px] text-stone-400">At fixed Rs. 500 per hen</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-stone-500 uppercase block font-sans">
            Total Purchase Amount
          </span>
          <div className="text-2xl font-bold font-display text-emerald-950 font-mono tabular-nums">
            Rs. {totalPurchaseAmount.toLocaleString()}
          </div>
          <span className="text-[10px] text-stone-400">Audited pullet acquisition</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-stone-500 uppercase block font-sans">
            Active Layer Hens
          </span>
          <div className="text-2xl font-bold font-display text-emerald-700 font-mono tabular-nums">
            {activeHens.length} Active
          </div>
          <span className="text-[10px] text-emerald-800 font-medium">Housed in farm sheds</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-emerald-950/10 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-stone-500 uppercase block font-sans">
            Pending Orders
          </span>
          <div className="text-2xl font-bold font-display text-amber-700 font-mono tabular-nums">
            {pendingHensCount} Pullets
          </div>
          <span className="text-[10px] text-amber-800 font-medium">Awaiting payment audit</span>
        </div>

      </div>

      {/* Farm Location & Custody Details Card */}
      <div className="bg-white rounded-2xl border border-emerald-950/10 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-100 gap-2">
          <div>
            <h2 className="font-bold text-base text-emerald-950 font-display">
              Physical Farm Custody Facility
            </h2>
            <p className="text-xs text-stone-500">
              Where your registered layer hens are housed, fed, vaccinated, and maintained.
            </p>
          </div>

          <button
            onClick={onOpenAgreement}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg text-xs font-semibold self-start sm:self-auto transition-colors"
          >
            <FileText className="w-3.5 h-3.5 text-emerald-800" />
            <span>Hen Ownership & Care Agreement</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200/70 space-y-1">
            <span className="text-stone-400 font-bold uppercase text-[10px] block font-sans">
              Farm Location
            </span>
            <span className="font-bold text-stone-900 block">
              Mandra-Chakwal Highway, Punjab
            </span>
            <span className="text-[11px] text-stone-500 block">
              Facility Coordinates: 33.15° N, 73.12° E
            </span>
          </div>

          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200/70 space-y-1">
            <span className="text-stone-400 font-bold uppercase text-[10px] block font-sans">
              Care & Husbandry Protocol
            </span>
            <span className="font-bold text-stone-900 block">
              Commercial Layer Mash 16% CP
            </span>
            <span className="text-[11px] text-stone-500 block">
              Marek, ND, IBD Full Vaccination
            </span>
          </div>

          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200/70 space-y-1">
            <span className="text-stone-400 font-bold uppercase text-[10px] block font-sans">
              Replacement Guarantee
            </span>
            <span className="font-bold text-stone-900 block">
              60-Day Mortality Cushion
            </span>
            <span className="text-[11px] text-stone-500 block">
              Free replacement for disease losses
            </span>
          </div>
        </div>
      </div>

      {/* Owned Hens & Official Certificates List */}
      <div className="bg-white rounded-2xl border border-emerald-950/10 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-stone-200 bg-stone-50/70 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-emerald-950 font-display">
              Registered Hens & Ownership Certificates ({myHens.length})
            </h3>
            <span className="text-xs text-stone-500">
              Each bird has an individual tamper-evident tag and an official downloadable certificate.
            </span>
          </div>
        </div>

        {myHens.length === 0 ? (
          <div className="p-12 text-center text-xs text-stone-500 space-y-2">
            <Egg className="w-10 h-10 text-stone-300 mx-auto" />
            <p className="font-semibold text-stone-700">No active hen ownership records found.</p>
            <p>Once you acquire hens, your official verified ownership certificates will appear here.</p>
          </div>
        ) : (
          <div className="divide-y divide-stone-100">
            {myHens.map(hen => (
              <div
                key={hen.id}
                className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-stone-50/60 transition-colors"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-xl bg-stone-100 overflow-hidden shrink-0 border border-stone-200">
                    <img
                      src={hen.photoUrl}
                      alt={hen.tagCode}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-xs text-emerald-950 bg-stone-100 px-2 py-0.5 rounded">
                        {hen.tagCode}
                      </span>
                      <span className="font-bold text-stone-900 text-xs">{hen.breed}</span>
                    </div>
                    <div className="text-[11px] text-stone-500 flex items-center gap-2">
                      <span>{hen.shedName.split('-')[0]}</span>
                      <span>•</span>
                      <span>Acquired: {hen.acquisitionDate}</span>
                      <span>•</span>
                      <span className="text-emerald-800 font-semibold">{hen.healthStatus === 'healthy' ? 'Active Layer' : 'Observation'}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-end sm:self-auto">
                  <span className="font-mono font-bold text-xs text-emerald-950">
                    Rs. 500
                  </span>
                  <button
                    onClick={() => onOpenCertificate(hen)}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
                  >
                    <Award className="w-3.5 h-3.5 text-emerald-300" />
                    <span>View Certificate</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
