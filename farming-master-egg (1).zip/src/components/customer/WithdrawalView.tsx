import React, { useState, useEffect } from 'react';
import { 
  ArrowUpRight, 
  Wallet, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Building2, 
  Smartphone, 
  Lock, 
  ShieldCheck, 
  Info,
  XCircle,
  HelpCircle,
  Database,
  Copy,
  Check,
  ExternalLink
} from 'lucide-react';
import { WithdrawalRequest, WithdrawalSetting, AppUser } from '../../types';
import { 
  SUPABASE_PROJECT_ID, 
  SUPABASE_DEFAULT_URL, 
  SUPABASE_DEPOSITS_WITHDRAWALS_SQL,
  checkDepositsWithdrawalsHealth 
} from '../../lib/supabase';

interface WithdrawalViewProps {
  currentUser: AppUser | null;
  withdrawalSettings: WithdrawalSetting[];
  withdrawals: WithdrawalRequest[];
  onRequestWithdrawal: (
    amount: number,
    method: 'Easypaisa' | 'JazzCash' | 'Bank Transfer',
    accountTitle: string,
    accountNumber: string,
    bankName?: string
  ) => { success: boolean; message: string };
}

export const WithdrawalView: React.FC<WithdrawalViewProps> = ({
  currentUser,
  withdrawalSettings,
  withdrawals,
  onRequestWithdrawal,
}) => {
  // Only show methods that are enabled by admin in Withdrawal Settings
  const enabledSettings = withdrawalSettings.filter(s => s.isEnabled);

  const [amount, setAmount] = useState<number>(1000);
  const [selectedMethodKey, setSelectedMethodKey] = useState<string>(
    enabledSettings[0]?.methodKey || 'easypaisa'
  );
  const [accountTitle, setAccountTitle] = useState(currentUser?.name || '');
  const [accountNumber, setAccountNumber] = useState(currentUser?.phone || '');
  const [bankName, setBankName] = useState('Meezan Bank');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [copiedSql, setCopiedSql] = useState(false);
  const [showSqlModal, setShowSqlModal] = useState(false);

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_DEPOSITS_WITHDRAWALS_SQL);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 3000);
  };

  const myWithdrawals = withdrawals.filter(w => w.customerId === currentUser?.id);

  // Active withdrawal check: single active request rule!
  const activePendingWithdrawal = myWithdrawals.find(
    w => w.status === 'pending' || w.status === 'under_review' || w.status === 'approved'
  );

  const handleWithdrawalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    const setting = enabledSettings.find(s => s.methodKey === selectedMethodKey);
    const methodDisplay: 'Easypaisa' | 'JazzCash' | 'Bank Transfer' = 
      selectedMethodKey === 'bank_transfer' 
        ? 'Bank Transfer' 
        : selectedMethodKey === 'jazzcash' 
          ? 'JazzCash' 
          : 'Easypaisa';

    const res = onRequestWithdrawal(
      Number(amount),
      methodDisplay,
      accountTitle,
      accountNumber,
      selectedMethodKey === 'bank_transfer' ? bankName : undefined
    );

    if (res.success) {
      setFeedback({ 
        type: 'success', 
        message: `${res.message} Saved directly to your Supabase backend (project "${SUPABASE_PROJECT_ID}").` 
      });
      setAmount(1000);
    } else {
      setFeedback({ type: 'error', message: res.message });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-700" /> Paid
          </span>
        );
      case 'approved':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-teal-100 text-teal-900 border border-teal-300 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-teal-700" /> Approved
          </span>
        );
      case 'under_review':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 text-blue-900 border border-blue-300 flex items-center gap-1">
            <Clock className="w-3 h-3 text-blue-700" /> Under Review
          </span>
        );
      case 'rejected':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-900 border border-rose-300 flex items-center gap-1">
            <XCircle className="w-3 h-3 text-rose-700" /> Rejected
          </span>
        );
      case 'pending':
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
            <Clock className="w-3 h-3 text-amber-700" /> Pending
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Supabase Backend Integration Banner */}
      <div className="bg-emerald-950 text-white p-4 sm:p-5 rounded-2xl border border-emerald-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-emerald-900/80 rounded-xl border border-emerald-700/50 text-emerald-300">
            <Database className="w-5 h-5 text-emerald-400" />
          </div>
          <div className="space-y-0.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                Supabase Backend Connected
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-800 text-emerald-100 border border-emerald-600">
                Project: {SUPABASE_PROJECT_ID}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-900 text-emerald-200 border border-emerald-700">
                Table: public.withdrawals
              </span>
            </div>
            <p className="text-xs text-emerald-100">
              Withdrawal requests are validated with single-active-request integrity and saved to Supabase.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setShowSqlModal(!showSqlModal)}
            className="px-3 py-1.5 bg-emerald-900/90 hover:bg-emerald-800 text-emerald-200 hover:text-white border border-emerald-700 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span>{showSqlModal ? 'Hide SQL' : 'View Supabase SQL'}</span>
          </button>
          <button
            type="button"
            onClick={handleCopySql}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
          >
            {copiedSql ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSql ? 'Copied SQL!' : 'Copy SQL Script'}</span>
          </button>
        </div>
      </div>

      {/* Expandable SQL Viewer Modal / Drawer */}
      {showSqlModal && (
        <div className="p-4 bg-stone-900 text-stone-200 rounded-2xl border border-stone-800 shadow-lg space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-stone-800 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold text-emerald-400">public.deposits & public.withdrawals DDL</span>
              <span className="text-stone-400">Run this once in Supabase SQL Editor</span>
            </div>
            <a
              href={`https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}/sql/new`}
              target="_blank"
              rel="noreferrer"
              className="text-emerald-400 hover:text-emerald-300 flex items-center gap-1 text-[11px] underline"
            >
              <span>Open Supabase SQL Editor</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          <pre className="text-[11px] font-mono leading-relaxed bg-stone-950 p-3 rounded-xl overflow-x-auto text-emerald-300 max-h-60">
            {SUPABASE_DEPOSITS_WITHDRAWALS_SQL}
          </pre>
        </div>
      )}
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-emerald-950/10 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-emerald-950 tracking-tight">
            WITHDRAW FUNDS
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Disburse verified egg sales profit share directly to your Pakistani bank account or mobile wallet.
          </p>
        </div>

        <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-xl self-start sm:self-auto text-right">
          <span className="text-[11px] text-stone-500 block">Available Withdrawable Balance</span>
          <span className="text-xl sm:text-2xl font-bold font-mono text-emerald-950 tabular-nums">
            Rs. {currentUser ? currentUser.withdrawableBalance.toFixed(2) : '0.00'}
          </span>
        </div>
      </div>

      {/* Active Pending Withdrawal Lock Banner (Requirement 8) */}
      {activePendingWithdrawal && (
        <div className="bg-amber-50 rounded-2xl p-5 border border-amber-300 text-amber-950 shadow-xs space-y-2">
          <div className="flex items-center gap-2 font-bold text-sm text-amber-900">
            <Lock className="w-4 h-4 text-amber-700 shrink-0" />
            <span>Active Withdrawal in Progress — Single Request Lock</span>
          </div>
          <p className="text-xs text-amber-800 leading-relaxed">
            You currently have withdrawal request <strong className="font-mono text-stone-900">{activePendingWithdrawal.id}</strong> for <strong className="font-mono font-bold text-emerald-950">Rs. {activePendingWithdrawal.amount.toLocaleString()}</strong> via {activePendingWithdrawal.paymentMethod} ({activePendingWithdrawal.accountNumber}) which is {activePendingWithdrawal.status.replace('_', ' ').toUpperCase()}.
          </p>
          <div className="p-3 bg-white/70 rounded-xl border border-amber-200/80 text-[11px] text-amber-900 flex items-center justify-between">
            <span>Status: <strong className="uppercase">{activePendingWithdrawal.status.replace('_', ' ')}</strong></span>
            <span>Requested: <strong className="font-mono">{activePendingWithdrawal.requestedAt}</strong></span>
          </div>
          <p className="text-[11px] text-amber-700">
            In accordance with farm treasury regulations, only one active withdrawal can be processed at a time. You can submit another request once this request is marked Paid or Rejected.
          </p>
        </div>
      )}

      {/* Main Form and Guidelines Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Withdrawal Form */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-emerald-950/10 p-6 shadow-xs space-y-5">
          <h2 className="text-base font-bold font-display text-emerald-950 pb-2 border-b border-stone-100 flex items-center gap-2">
            <ArrowUpRight className="w-5 h-5 text-emerald-800" />
            <span>Submit Withdrawal Request</span>
          </h2>

          {feedback && (
            <div
              className={`p-4 rounded-xl text-xs flex items-center gap-2.5 ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 border border-emerald-300 text-emerald-900'
                  : 'bg-red-50 border border-red-300 text-red-900'
              }`}
            >
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-700 shrink-0" />
              )}
              <span>{feedback.message}</span>
            </div>
          )}

          <form onSubmit={handleWithdrawalSubmit} className="space-y-4 text-xs">
            
            {/* Amount input */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="font-semibold text-stone-700">
                  Amount to Withdraw (PKR) *
                </label>
                <span className="text-[11px] text-stone-500">
                  Minimum: <strong className="font-mono text-emerald-900 font-bold">Rs. 500</strong>
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold font-mono text-stone-500">
                  Rs.
                </span>
                <input
                  type="number"
                  min={500}
                  step={50}
                  max={currentUser ? currentUser.withdrawableBalance : 0}
                  value={amount}
                  onChange={e => setAmount(Number(e.target.value))}
                  disabled={Boolean(activePendingWithdrawal)}
                  className="w-full pl-10 pr-4 py-2.5 border border-stone-300 rounded-xl font-mono text-sm font-bold text-stone-900 focus:outline-hidden focus:border-emerald-700 disabled:bg-stone-100 disabled:cursor-not-allowed"
                  required
                />
              </div>
            </div>

            {/* Quick Amount Pills */}
            <div className="flex flex-wrap gap-2">
              {[500, 1000, 2500, 5000].map(val => (
                <button
                  type="button"
                  key={val}
                  disabled={Boolean(activePendingWithdrawal) || (currentUser ? currentUser.withdrawableBalance < val : true)}
                  onClick={() => setAmount(val)}
                  className="px-3 py-1 bg-stone-100 hover:bg-emerald-50 hover:text-emerald-900 border border-stone-200 rounded-lg text-xs font-mono font-medium disabled:opacity-40 disabled:pointer-events-none"
                >
                  Rs. {val.toLocaleString()}
                </button>
              ))}
              {currentUser && currentUser.withdrawableBalance >= 500 && (
                <button
                  type="button"
                  disabled={Boolean(activePendingWithdrawal)}
                  onClick={() => setAmount(Math.floor(currentUser.withdrawableBalance))}
                  className="px-3 py-1 bg-emerald-100 text-emerald-950 font-semibold border border-emerald-300 rounded-lg text-xs"
                >
                  Withdraw All (Rs. {Math.floor(currentUser.withdrawableBalance).toLocaleString()})
                </button>
              )}
            </div>

            {/* Payment Method Selector (Loaded dynamically from Admin Withdrawal Settings) */}
            <div>
              <label className="font-semibold text-stone-700 block mb-1">
                Select Withdrawal Method *
              </label>
              {enabledSettings.length === 0 ? (
                <div className="p-3 bg-stone-100 rounded-xl text-stone-500 text-xs italic">
                  No withdrawal methods currently enabled by farm treasury.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {enabledSettings.map(setting => {
                    const isSelected = selectedMethodKey === setting.methodKey;
                    return (
                      <div
                        key={setting.id}
                        onClick={() => !activePendingWithdrawal && setSelectedMethodKey(setting.methodKey)}
                        className={`p-3 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'border-emerald-800 bg-emerald-50/70 ring-2 ring-emerald-700/20'
                            : 'border-stone-200 hover:border-stone-300 bg-stone-50/40'
                        } ${activePendingWithdrawal ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          {setting.methodKey === 'bank_transfer' ? (
                            <Building2 className="w-4 h-4 text-emerald-800" />
                          ) : (
                            <Smartphone className="w-4 h-4 text-emerald-800" />
                          )}
                          <span className="font-bold text-xs text-stone-900">{setting.name}</span>
                        </div>
                        <span className="text-[10px] text-stone-500">
                          {setting.methodKey === 'bank_transfer' ? 'IBFT / Raast 24H' : 'Instant Wallet'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Bank Name if Bank Transfer selected */}
            {selectedMethodKey === 'bank_transfer' && (
              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Beneficiary Bank Name *
                </label>
                <select
                  value={bankName}
                  onChange={e => setBankName(e.target.value)}
                  disabled={Boolean(activePendingWithdrawal)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-xl text-xs bg-white focus:outline-hidden focus:border-emerald-700 disabled:bg-stone-100"
                >
                  <option value="Meezan Bank Ltd">Meezan Bank Ltd (Islamic)</option>
                  <option value="Habib Bank Ltd (HBL)">Habib Bank Ltd (HBL)</option>
                  <option value="United Bank Ltd (UBL)">United Bank Ltd (UBL)</option>
                  <option value="MCB Bank Ltd">MCB Bank Ltd</option>
                  <option value="Bank Alfalah">Bank Alfalah</option>
                  <option value="Faysal Bank">Faysal Bank</option>
                  <option value="Allied Bank Ltd">Allied Bank Ltd</option>
                  <option value="Standard Chartered">Standard Chartered Pakistan</option>
                  <option value="National Bank of Pakistan">National Bank of Pakistan (NBP)</option>
                  <option value="Other Commercial Bank">Other Commercial Bank</option>
                </select>
              </div>
            )}

            {/* Account Title */}
            <div>
              <label className="font-semibold text-stone-700 block mb-1">
                Account Holder Name / Title *
              </label>
              <input
                type="text"
                value={accountTitle}
                onChange={e => setAccountTitle(e.target.value)}
                placeholder="Name as registered on CNIC / Bank Account"
                disabled={Boolean(activePendingWithdrawal)}
                className="w-full px-3.5 py-2 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-hidden focus:border-emerald-700 disabled:bg-stone-100"
                required
              />
              <span className="text-[10px] text-stone-500 mt-0.5 block">
                Must match your registered customer bailment identity.
              </span>
            </div>

            {/* Account Number / IBAN */}
            <div>
              <label className="font-semibold text-stone-700 block mb-1">
                {selectedMethodKey === 'bank_transfer'
                  ? 'Bank Account Number / 24-Digit IBAN *'
                  : 'Mobile Wallet Account Number (11 Digits) *'}
              </label>
              <input
                type="text"
                value={accountNumber}
                onChange={e => setAccountNumber(e.target.value)}
                placeholder={
                  selectedMethodKey === 'bank_transfer'
                    ? 'e.g. PK42 MEZN 0001 0928 3491 0001'
                    : 'e.g. 0333 4920199'
                }
                disabled={Boolean(activePendingWithdrawal)}
                className="w-full px-3.5 py-2 border border-stone-300 rounded-xl font-mono text-xs text-stone-900 focus:outline-hidden focus:border-emerald-700 disabled:bg-stone-100"
                required
              />
            </div>

            <button
              type="submit"
              disabled={Boolean(activePendingWithdrawal) || (currentUser ? currentUser.withdrawableBalance < 500 : true)}
              className="w-full py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl text-xs transition-colors shadow-xs flex items-center justify-center gap-2 disabled:bg-stone-300 disabled:cursor-not-allowed cursor-pointer"
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>
                {activePendingWithdrawal
                  ? 'Withdrawal Locked — Existing Request Active'
                  : `Submit Withdrawal Request (Rs. ${amount.toLocaleString()})`}
              </span>
            </button>
          </form>
        </div>

        {/* Right 1 Col: Treasury Rules & Information */}
        <div className="space-y-4">
          <div className="bg-stone-50 rounded-2xl p-5 border border-stone-200/80 space-y-3 text-xs text-stone-600">
            <h3 className="font-bold text-sm text-stone-900 flex items-center gap-1.5 font-display">
              <ShieldCheck className="w-4 h-4 text-emerald-800" />
              <span>Disbursal Guidelines</span>
            </h3>

            <ul className="space-y-2 text-[11px] leading-relaxed">
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-800 font-bold">•</span>
                <span>
                  <strong>Single Active Lock:</strong> Only one pending or reviewing request may be active at any given time.
                </span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-800 font-bold">•</span>
                <span>
                  <strong>Minimum Payout:</strong> Rs. 500 per transaction across all supported Pakistani payment methods.
                </span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-800 font-bold">•</span>
                <span>
                  <strong>Disbursal Timeline:</strong> Requests submitted before 02:00 PM are verified and dispatched within 24 business hours.
                </span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-800 font-bold">•</span>
                <span>
                  <strong>Zero Hidden Fees:</strong> No withdrawal fee or hidden deduction is applied to customer egg profit shares.
                </span>
              </li>
            </ul>
          </div>

          <div className="bg-emerald-950 text-white rounded-2xl p-5 shadow-xs space-y-2 text-xs">
            <div className="font-bold text-emerald-300 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-emerald-400" />
              <span>Need Direct Assistance?</span>
            </div>
            <p className="text-[11px] text-emerald-200 leading-relaxed">
              For priority support or settlement questions, contact the official Farm Treasury WhatsApp line at <strong className="text-white font-mono">+92 333 4920199</strong>.
            </p>
          </div>
        </div>

      </div>

      {/* Customer Withdrawal History Table */}
      <div className="bg-white rounded-2xl border border-emerald-950/10 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-50/70">
          <h3 className="font-bold text-sm sm:text-base text-emerald-950 font-display">
            Your Withdrawal Requests ({myWithdrawals.length})
          </h3>
          <span className="text-xs text-stone-500">
            Real-time status updates: Pending, Under Review, Approved, Rejected, Paid.
          </span>
        </div>

        {myWithdrawals.length === 0 ? (
          <div className="py-12 text-center text-xs text-stone-500 space-y-1">
            <Wallet className="w-8 h-8 text-stone-300 mx-auto" />
            <p>You have not submitted any withdrawal requests yet.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-semibold bg-stone-50/50">
                  <th className="p-3.5">Request ID</th>
                  <th className="p-3.5">Date & Time</th>
                  <th className="p-3.5">Method</th>
                  <th className="p-3.5">Beneficiary Details</th>
                  <th className="p-3.5">Amount</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Disbursal Ref / Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 font-mono">
                {myWithdrawals.map(w => (
                  <tr key={w.id} className="hover:bg-stone-50 transition-colors">
                    <td className="p-3.5 font-bold text-emerald-950 font-sans">{w.id}</td>
                    <td className="p-3.5 font-sans text-stone-700">{w.requestedAt}</td>
                    <td className="p-3.5 font-sans font-medium text-stone-900">{w.paymentMethod}</td>
                    <td className="p-3.5 font-sans text-[11px] text-stone-600">
                      <div className="font-bold text-stone-800">{w.accountTitle}</div>
                      <div className="font-mono text-stone-500">{w.accountNumber}</div>
                      {w.bankName && <div className="text-[10px] text-stone-400">{w.bankName}</div>}
                    </td>
                    <td className="p-3.5 font-bold text-emerald-950 tabular-nums">
                      Rs. {w.amount.toLocaleString()}
                    </td>
                    <td className="p-3.5 font-sans">
                      {getStatusBadge(w.status)}
                    </td>
                    <td className="p-3.5 font-sans text-[11px] text-stone-600">
                      {w.transactionReference ? (
                        <div className="font-mono text-emerald-900 font-semibold">{w.transactionReference}</div>
                      ) : (
                        <div className="text-stone-400 italic">In Processing Queue</div>
                      )}
                      {w.adminNotes && (
                        <div className="text-[10px] text-stone-500 mt-0.5">{w.adminNotes}</div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
};
