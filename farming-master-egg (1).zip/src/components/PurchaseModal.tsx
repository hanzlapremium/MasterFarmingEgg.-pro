import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Shield, CheckCircle2, AlertCircle, ArrowRight, Building2, Smartphone, Wallet } from 'lucide-react';
import { PaymentMethod } from '../types';

export const PurchaseModal: React.FC = () => {
  const { 
    purchaseModalOpen, 
    setPurchaseModalOpen, 
    createPurchaseOrder, 
    currentUser, 
    hens, 
    depositSettings,
    setActiveView 
  } = useApp();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [quantity, setQuantity] = useState<number>(2);
  const [termsAgreed, setTermsAgreed] = useState<boolean>(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Easypaisa');
  const [transactionRef, setTransactionRef] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  if (!purchaseModalOpen) return null;

  const availableHens = hens.filter(h => h.status === 'available');
  const availableCount = availableHens.length;
  const unitPrice = 500;
  const totalAmount = quantity * unitPrice;

  // Active deposit settings from admin
  const enabledSettings = depositSettings.filter(s => s.isEnabled);

  const handleNextFromStep1 = () => {
    if (!currentUser) {
      setErrorMsg('Please sign in or register to acquire physical hens.');
      return;
    }
    if (quantity < 1) {
      setErrorMsg('Please select at least 1 hen.');
      return;
    }
    setErrorMsg('');
    setStep(2);
  };

  const handleNextFromStep2 = () => {
    if (!termsAgreed) {
      setErrorMsg('You must agree to the Hen Ownership & Farm-Care Custody Agreement to proceed.');
      return;
    }
    setErrorMsg('');
    // If customer has sufficient balance, default to Account Balance
    if (currentUser && currentUser.withdrawableBalance >= totalAmount) {
      setPaymentMethod('Account Balance');
    }
    setStep(3);
  };

  const handleSubmitOrder = () => {
    setErrorMsg('');
    const res = createPurchaseOrder(quantity, paymentMethod, transactionRef);
    if (res.success) {
      setStep(4);
    } else {
      setErrorMsg(res.message);
    }
  };

  const closeModal = () => {
    setPurchaseModalOpen(false);
    setStep(1);
    setTransactionRef('');
    setErrorMsg('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-emerald-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl border border-emerald-950/10 shadow-xl max-w-xl w-full my-8 overflow-hidden">
        
        {/* Modal Top Header */}
        <div className="px-6 py-4 bg-emerald-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-base font-display">Physical Hen Acquisition (Rs. 500 / Hen)</h3>
          </div>
          <button
            onClick={closeModal}
            className="text-emerald-300 hover:text-white p-1 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Steps Breadcrumb */}
        <div className="px-6 py-2.5 bg-stone-100 border-b border-stone-200 flex items-center justify-between text-xs font-semibold text-stone-600">
          <span className={step === 1 ? 'text-emerald-900 font-bold' : ''}>1. Quantity</span>
          <span>&gt;</span>
          <span className={step === 2 ? 'text-emerald-900 font-bold' : ''}>2. Custody Contract</span>
          <span>&gt;</span>
          <span className={step === 3 ? 'text-emerald-900 font-bold' : ''}>3. Payment Settlement</span>
          <span>&gt;</span>
          <span className={step === 4 ? 'text-emerald-900 font-bold' : ''}>4. Confirmation</span>
        </div>

        {errorMsg && (
          <div className="mx-6 mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* STEP 1: Quantity */}
        {step === 1 && (
          <div className="p-6 space-y-5">
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-emerald-950">Select Hen Quantity</h4>
              <p className="text-xs text-stone-500">
                Initial fixed acquisition price is <strong className="text-emerald-900 font-semibold font-mono">Rs. 500 per hen</strong>.
              </p>
            </div>

            <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 flex items-center justify-between text-xs">
              <div>
                <span className="text-stone-500 block">Unit Hen Price</span>
                <span className="text-base font-bold text-emerald-900 font-mono">Rs. 500 / hen</span>
              </div>
              <div className="text-right">
                <span className="text-stone-500 block">Flock Capacity</span>
                <span className="text-xs font-bold text-emerald-800">Unlimited Purchase Capacity</span>
              </div>
            </div>

            {/* Immediate 1:1 Egg Credit Highlight */}
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200/80 text-xs text-amber-950 flex items-start gap-2.5">
              <span className="text-base">🥚</span>
              <div className="space-y-0.5">
                <strong className="block font-semibold">Immediate 1:1 Egg Credit:</strong>
                <p className="text-[11px] text-amber-900 leading-relaxed">
                  Every acquired hen immediately credits 1 verified egg (1 hen = 1 egg) to your Available Eggs balance. You can sell these eggs right away without waiting 24 hours.
                </p>
              </div>
            </div>

            {/* Quantity Selector */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-stone-700 block">
                  Enter Hen Quantity *
                </label>
                <span className="text-[11px] text-stone-500 font-mono">
                  {quantity} Hen{quantity === 1 ? '' : 's'} = {quantity} Initial Egg{quantity === 1 ? '' : 's'}
                </span>
              </div>

              <input
                type="number"
                min={1}
                value={quantity}
                onChange={e => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full px-3.5 py-2.5 border border-stone-300 rounded-xl font-mono text-base font-bold text-stone-900 focus:outline-hidden focus:border-emerald-700"
                required
              />

              <div className="flex flex-wrap gap-2 pt-1">
                {[1, 2, 5, 10, 20, 50, 100].map(q => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => setQuantity(q)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                      quantity === q
                        ? 'bg-emerald-800 text-white border-emerald-800 shadow-xs'
                        : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    {q} Hens
                  </button>
                ))}
              </div>
            </div>

            {/* Customer Check */}
            {!currentUser ? (
              <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 space-y-2">
                <p>You need to sign in or register before acquiring hens so they are registered under your legal name.</p>
                <button
                  type="button"
                  onClick={() => {
                    closeModal();
                    setActiveView('customer-login');
                  }}
                  className="px-3 py-1.5 bg-emerald-800 text-white rounded text-xs font-bold"
                >
                  Sign In / Register Now
                </button>
              </div>
            ) : (
              <div className="p-3 bg-stone-50 rounded-lg text-xs space-y-1">
                <span className="text-stone-500 block">Registered Owner Title:</span>
                <span className="font-bold text-stone-900">{currentUser.name} ({currentUser.phone})</span>
              </div>
            )}

            {/* Total calculation */}
            <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-100 flex items-center justify-between">
              <span className="text-xs font-medium text-emerald-900">Total Acquisition Cost:</span>
              <span className="text-lg font-bold text-emerald-950 font-mono tabular-nums">
                Rs. {totalAmount.toLocaleString()}
              </span>
            </div>

            <button
              onClick={handleNextFromStep1}
              className="w-full py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs"
            >
              <span>Continue to Care Custody Contract</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* STEP 2: Hen Ownership and Farm-Care Agreement */}
        {step === 2 && (
          <div className="p-6 space-y-5">
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-emerald-950">Review Legal Care & Custody Contract</h4>
              <p className="text-xs text-stone-500">
                You retain legal title to the physical hen while appointing Farming Master Egg as your authorized agricultural caretaker.
              </p>
            </div>

            <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 h-52 overflow-y-auto text-xs text-stone-700 space-y-2.5 leading-relaxed">
              <div className="font-bold text-emerald-950 text-center pb-1 border-b border-stone-200">
                HEN OWNERSHIP & AGRICULTURAL FARM-CARE CUSTODY AGREEMENT
              </div>
              <p>
                <strong>1. Title of Ownership:</strong> The Customer acquires direct physical ownership of {quantity} layer hen(s) at Rs. 500/hen. Physical wing/leg band identification tags will be allocated upon verified payment.
              </p>
              <p>
                <strong>2. Farm Care & Husbandry:</strong> The Farm commits to commercial layer housing, quality feed (16% crude protein layer mash), sanitized water, routine veterinary examinations, biosecurity controls, and daily egg collection.
              </p>
              <p>
                <strong>3. Egg Harvest & Cost Deduction:</strong> Eggs collected from the flock are sold wholesale at prevailing market mandi rates. Documented operating expenses (feed, veterinary vaccines, labor, electricity) are deducted proportionately from gross egg revenue. Net proceeds, less a 10% farm custody maintenance fee, are allocated monthly to the customer's ledger.
              </p>
              <p>
                <strong>4. Non-Guaranteed Return & Risk:</strong> This is an authentic agricultural activity. Production cycles, seasonal molting, disease exposure, and egg market price volatility are genuine risks. No minimum or fixed daily profit is promised.
              </p>
              <p>
                <strong>5. Hen Mortality Policy:</strong> In the event of documented natural bird mortality during the first 60 days of custody, the Farm provides one (1) replacement layer hen from the active flock, subject to certified veterinary post-mortem records.
              </p>
            </div>

            <label className="flex items-start gap-3 cursor-pointer p-3 bg-emerald-50/60 border border-emerald-100 rounded-lg">
              <input
                type="checkbox"
                checked={termsAgreed}
                onChange={e => setTermsAgreed(e.target.checked)}
                className="mt-0.5 rounded border-stone-300 text-emerald-800 focus:ring-emerald-700"
              />
              <span className="text-xs text-stone-700 leading-relaxed">
                I accept the terms of the Hen Ownership and Farm-Care Custody Agreement. I acknowledge that agricultural egg production varies and is not a guaranteed-return scheme.
              </span>
            </label>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setStep(1)}
                className="w-1/3 py-2.5 border border-stone-200 text-stone-700 font-semibold text-xs rounded-lg hover:bg-stone-50"
              >
                Back
              </button>
              <button
                onClick={handleNextFromStep2}
                disabled={!termsAgreed}
                className="w-2/3 py-2.5 bg-emerald-800 hover:bg-emerald-900 disabled:opacity-50 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <span>Sign & Proceed to Payment</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Payment */}
        {step === 3 && (
          <div className="p-6 space-y-5">
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-emerald-950">Payment Settlement</h4>
              <p className="text-xs text-stone-500">
                Total for {quantity} hen(s): <strong className="text-emerald-900 font-mono font-bold">Rs. {totalAmount.toLocaleString()}</strong>
              </p>
            </div>

            {/* If Customer has account balance */}
            {currentUser && currentUser.withdrawableBalance >= totalAmount && (
              <div 
                onClick={() => setPaymentMethod('Account Balance')}
                className={`p-3.5 rounded-xl border cursor-pointer transition-colors ${
                  paymentMethod === 'Account Balance' 
                    ? 'bg-emerald-50 border-emerald-600 text-emerald-950' 
                    : 'bg-stone-50 border-stone-200 text-stone-700'
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 font-bold">
                    <Wallet className="w-4 h-4 text-emerald-700" />
                    <span>Pay Instantly via Account Balance</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-900">
                    Rs. {currentUser.withdrawableBalance.toFixed(2)} available
                  </span>
                </div>
                <p className="text-[11px] text-stone-500 mt-1">
                  Immediate allocation! Physical hen IDs will be assigned instantly to your account.
                </p>
              </div>
            )}

            {/* Direct Gateways configured by admin */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-stone-700 block">
                Or Pay via Admin Corporate Accounts:
              </span>
              <div className="grid grid-cols-3 gap-2">
                {enabledSettings.map(setting => (
                  <button
                    key={setting.id}
                    type="button"
                    onClick={() => setPaymentMethod(setting.name.includes('Easypaisa') ? 'Easypaisa' : setting.name.includes('JazzCash') ? 'JazzCash' : 'Bank Transfer')}
                    className={`py-2 px-2 text-[11px] font-semibold rounded-lg border text-center transition-colors ${
                      paymentMethod === (setting.name.includes('Easypaisa') ? 'Easypaisa' : setting.name.includes('JazzCash') ? 'JazzCash' : 'Bank Transfer')
                        ? 'bg-emerald-800 text-white border-emerald-800'
                        : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                    }`}
                  >
                    {setting.methodKey === 'bank_transfer' ? 'Bank Transfer' : setting.name.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            {paymentMethod !== 'Account Balance' && (
              <div className="space-y-3">
                {/* Account details */}
                {(() => {
                  const mKey = paymentMethod === 'Easypaisa' ? 'easypaisa' : paymentMethod === 'JazzCash' ? 'jazzcash' : 'bank_transfer';
                  const cfg = depositSettings.find(s => s.methodKey === mKey);
                  return cfg ? (
                    <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs space-y-1">
                      <div>Title: <strong>{cfg.accountHolderName}</strong></div>
                      <div>Account: <strong className="font-mono text-emerald-900">{cfg.accountNumber}</strong></div>
                      {cfg.bankName && <div>Bank: <strong>{cfg.bankName}</strong></div>}
                      <p className="text-[11px] text-stone-500 pt-1">{cfg.paymentInstructions}</p>
                    </div>
                  ) : null;
                })()}

                <div>
                  <label className="text-xs font-semibold text-stone-700 block mb-1">
                    Transaction Reference (TRX / TID) *
                  </label>
                  <input
                    type="text"
                    value={transactionRef}
                    onChange={e => setTransactionRef(e.target.value)}
                    placeholder="e.g. EP-883901 or TID-29018"
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs font-mono"
                    required
                  />
                </div>
              </div>
            )}

            <div className="flex items-center gap-3">
              <button
                onClick={() => setStep(2)}
                className="w-1/3 py-2.5 border border-stone-200 text-stone-700 font-semibold text-xs rounded-lg hover:bg-stone-50"
              >
                Back
              </button>
              <button
                onClick={handleSubmitOrder}
                className="w-2/3 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{paymentMethod === 'Account Balance' ? 'Confirm Instant Purchase' : 'Submit for Admin Verification'}</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Success */}
        {step === 4 && (
          <div className="p-8 text-center space-y-4">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <h4 className="text-lg font-bold text-emerald-950 font-display">
              {paymentMethod === 'Account Balance' ? 'Hen Ownership Confirmed!' : 'Purchase Order Submitted!'}
            </h4>
            <p className="text-xs text-stone-600 max-w-sm mx-auto leading-relaxed">
              {paymentMethod === 'Account Balance'
                ? `Your ${quantity} layer hen(s) are active and ${quantity} initial egg(s) have been immediately credited to your Available Eggs balance ready to sell without waiting 24 hours!`
                : `Your order for ${quantity} layer hen(s) has been submitted for verification. Upon approval, ${quantity} eggs will be instantly credited to your balance ready to sell.`}
            </p>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => {
                  closeModal();
                  setActiveView('customer-dashboard');
                }}
                className="w-full sm:w-auto px-5 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-lg cursor-pointer"
              >
                Go to Customer Dashboard
              </button>
              <button
                onClick={() => {
                  closeModal();
                  setActiveView('customer-dashboard');
                  // Trigger navigation to Sell Eggs
                  window.dispatchEvent(new CustomEvent('fme_navigate_tab', { detail: 'sell-eggs' }));
                }}
                className="w-full sm:w-auto px-5 py-2.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg cursor-pointer"
              >
                Sell Eggs Now ({quantity} Available)
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
