import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  ShieldCheck, 
  Phone, 
  Lock, 
  User, 
  ArrowRight, 
  AlertCircle, 
  CheckCircle2, 
  Loader2,
  Database,
  Sparkles
} from 'lucide-react';
import { SUPABASE_PROJECT_ID } from '../../lib/supabase';

interface CustomerAuthViewProps {
  initialMode?: 'login' | 'register';
}

export const CustomerAuthView: React.FC<CustomerAuthViewProps> = ({ initialMode = 'login' }) => {
  const { customerLogin, customerRegister, setActiveView } = useApp();
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);

  // Exact required fields:
  // Register: Real Name, Phone Number, Password
  // Login: Real Name, Password
  const [realName, setRealName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'error' | 'success'; message: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    // Client-side validations
    const trimmedName = realName.trim();
    if (!trimmedName || trimmedName.length < 2) {
      setFeedback({ type: 'error', message: 'Please enter your valid Real Name (minimum 2 characters).' });
      return;
    }

    if (mode === 'register') {
      const cleanedPhone = phoneNumber.trim().replace(/[\s-]/g, '');
      if (!cleanedPhone || cleanedPhone.length < 8) {
        setFeedback({ type: 'error', message: 'Please enter a valid Phone Number (e.g. 0300 1234567).' });
        return;
      }
    }

    if (!password || password.length < 6) {
      setFeedback({ type: 'error', message: 'Password must be at least 6 characters long.' });
      return;
    }

    setIsSubmitting(true);

    try {
      if (mode === 'login') {
        const res = await customerLogin(trimmedName, password);
        if (res.success) {
          setFeedback({ type: 'success', message: res.message });
          setTimeout(() => setActiveView('customer-dashboard'), 600);
        } else {
          setFeedback({ type: 'error', message: res.message });
        }
      } else {
        const res = await customerRegister(trimmedName, phoneNumber.trim(), password);
        if (res.success) {
          setFeedback({ type: 'success', message: res.message });
          setTimeout(() => setActiveView('customer-dashboard'), 600);
        } else {
          setFeedback({ type: 'error', message: res.message });
        }
      }
    } catch (err: any) {
      setFeedback({ type: 'error', message: err?.message || 'Authentication error occurred.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="py-16 bg-[#faf8f5] min-h-[85vh] flex items-center justify-center px-4 sm:px-6">
      <div className="bg-white rounded-3xl border border-emerald-950/10 shadow-xl max-w-md w-full overflow-hidden">
        
        {/* Header */}
        <div className="bg-emerald-950 text-white p-6 sm:p-7 text-center space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-900/80 text-emerald-300 rounded-full text-[11px] font-mono">
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span>Supabase Cloud ({SUPABASE_PROJECT_ID})</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold font-display text-white">
            {mode === 'login' ? 'Customer Sign In' : 'Register New Account'}
          </h2>
          <p className="text-xs text-emerald-200">
            {mode === 'login' 
              ? 'Enter your Real Name & Password to access your live farm ledger.' 
              : 'Create your hen owner account with your Real Name, Phone Number & Password.'}
          </p>
        </div>

        {/* Mode Toggle Bar */}
        <div className="p-1.5 bg-stone-100 border-b border-stone-200 grid grid-cols-2 text-xs font-semibold">
          <button
            type="button"
            onClick={() => { setMode('login'); setFeedback(null); }}
            className={`py-2.5 text-center rounded-xl transition-all cursor-pointer ${
              mode === 'login' ? 'bg-white text-emerald-950 shadow-xs font-bold' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Log In (2 Fields)
          </button>
          <button
            type="button"
            onClick={() => { setMode('register'); setFeedback(null); }}
            className={`py-2.5 text-center rounded-xl transition-all cursor-pointer ${
              mode === 'register' ? 'bg-white text-emerald-950 shadow-xs font-bold' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Register (3 Fields)
          </button>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div className={`m-6 mb-0 p-3.5 rounded-xl text-xs flex items-center gap-2.5 ${
            feedback.type === 'error' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
          }`}>
            {feedback.type === 'error' ? <AlertCircle className="w-4 h-4 shrink-0 text-red-600" /> : <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />}
            <span className="font-medium">{feedback.message}</span>
          </div>
        )}

        {/* Auth Form */}
        <form onSubmit={handleSubmit} className="p-6 sm:p-7 space-y-4 text-xs">
          
          {/* FIELD 1: Real Name (Both Login & Register) */}
          <div>
            <label className="font-bold text-stone-700 block mb-1.5">Real Name *</label>
            <div className="relative">
              <User className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={realName}
                onChange={e => setRealName(e.target.value)}
                placeholder="Enter your full real name"
                className="w-full pl-10 pr-3.5 py-2.5 border border-stone-200 rounded-xl text-stone-900 focus:outline-hidden focus:border-emerald-700 focus:ring-2 focus:ring-emerald-700/10 text-xs"
                required
                autoComplete="name"
              />
            </div>
          </div>

          {/* FIELD 2 (REGISTER ONLY): Phone Number */}
          {mode === 'register' && (
            <div>
              <label className="font-bold text-stone-700 block mb-1.5">Phone Number *</label>
              <div className="relative">
                <Phone className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={e => setPhoneNumber(e.target.value)}
                  placeholder="e.g. 0300 1234567"
                  className="w-full pl-10 pr-3.5 py-2.5 border border-stone-200 rounded-xl text-stone-900 focus:outline-hidden focus:border-emerald-700 focus:ring-2 focus:ring-emerald-700/10 text-xs font-mono"
                  required
                  autoComplete="tel"
                />
              </div>
              <span className="text-[10px] text-stone-400 block mt-1">Used for payment payouts and verification.</span>
            </div>
          )}

          {/* FIELD 2 / 3: Password (Both Login & Register) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="font-bold text-stone-700 block">Password *</label>
              <span className="text-[10px] text-stone-400 font-mono">SHA-256 Encrypted</span>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Minimum 6 characters"
                className="w-full pl-10 pr-3.5 py-2.5 border border-stone-200 rounded-xl text-stone-900 focus:outline-hidden focus:border-emerald-700 focus:ring-2 focus:ring-emerald-700/10 text-xs"
                required
                minLength={6}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              />
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 bg-emerald-800 hover:bg-emerald-900 disabled:bg-emerald-800/60 text-white font-bold rounded-xl transition-all shadow-md shadow-emerald-900/15 flex items-center justify-center gap-2 mt-2 cursor-pointer text-xs"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Authenticating with Supabase...</span>
              </>
            ) : (
              <>
                <span>
                  {mode === 'login' ? 'Log In to Customer Portal' : 'Register Account & Enter Portal'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Security badge and switcher */}
        <div className="p-4 bg-stone-50 border-t border-stone-100 text-center text-xs text-stone-500 space-y-1">
          <div className="flex items-center justify-center gap-1.5 text-emerald-800 font-semibold text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Salted SHA-256 Encryption & Supabase Session Storage</span>
          </div>
          <p className="text-[11px] text-stone-400">
            {mode === 'login' ? "Don't have an account yet?" : 'Already have an account?'}{' '}
            <button
              type="button"
              onClick={() => {
                setMode(mode === 'login' ? 'register' : 'login');
                setFeedback(null);
              }}
              className="text-emerald-900 font-bold underline cursor-pointer"
            >
              {mode === 'login' ? 'Register here' : 'Sign in here'}
            </button>
          </p>
        </div>

      </div>
    </div>
  );
};
