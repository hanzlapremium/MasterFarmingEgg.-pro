import React from 'react';
import { useApp } from '../context/AppContext';
import { X, Award, Printer, CheckCircle, Shield, QrCode } from 'lucide-react';

export const CertificateModal: React.FC = () => {
  const { selectedHenForCertificate, setSelectedHenForCertificate, currentUser } = useApp();

  if (!selectedHenForCertificate) return null;

  const hen = selectedHenForCertificate;
  const ownerName = hen.ownerName || currentUser?.name || 'Registered Owner';
  const certNumber = `CERT-FME-${hen.tagCode.replace('-', '')}-2026`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-emerald-950/75 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white">
      <div className="bg-white rounded-2xl border border-emerald-950/20 shadow-2xl max-w-2xl w-full my-6 overflow-hidden print:border-none print:shadow-none print:m-0">
        
        {/* Modal Top Actions (Hidden in print) */}
        <div className="px-6 py-3 bg-emerald-950 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2 text-xs font-medium text-emerald-300">
            <Award className="w-4 h-4 text-emerald-400" />
            <span>Official Hen Ownership Certificate</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1 bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-semibold rounded-md transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={() => setSelectedHenForCertificate(null)}
              className="text-emerald-300 hover:text-white p-1 rounded-md"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Certificate Paper Canvas */}
        <div className="p-8 sm:p-12 bg-[#fdfbf7] border-8 border-double border-emerald-900/30 m-4 sm:m-6 rounded-xl relative space-y-6 text-stone-800 font-serif">
          
          {/* Subtle watermark seal */}
          <div className="text-center space-y-2 border-b-2 border-emerald-900/20 pb-6">
            <div className="text-xs uppercase tracking-widest font-sans font-bold text-emerald-900">
              FARMING MASTER EGG AGRO ENTERPRISES
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-emerald-950 font-display">
              Certificate of Hen Ownership & Custody
            </h2>
            <div className="text-xs text-stone-500 font-sans">
              Serial No: <span className="font-mono font-bold text-stone-800">{certNumber}</span>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-stone-700 leading-relaxed text-center font-sans max-w-lg mx-auto">
            This is to certify that under the authorized Care and Bailment Agreement of Farming Master Egg, 
            the physical layer hen described below has been officially registered under the exclusive legal ownership of:
          </p>

          {/* Owner Box */}
          <div className="bg-emerald-50/70 border border-emerald-900/20 rounded-xl p-4 text-center font-sans">
            <div className="text-xs uppercase tracking-wider text-emerald-800 font-semibold">Title Holder</div>
            <div className="text-xl font-bold text-emerald-950 mt-1">{ownerName}</div>
            <div className="text-xs text-stone-600 mt-0.5">
              Custody Registration: <span className="font-mono text-stone-900">{hen.acquisitionDate}</span>
            </div>
          </div>

          {/* Hen Specifications Table */}
          <div className="font-sans border border-stone-200 rounded-lg overflow-hidden text-xs bg-white">
            <div className="grid grid-cols-2 divide-x divide-stone-200 border-b border-stone-200">
              <div className="p-2.5 bg-stone-50 text-stone-500">Physical Wing Tag ID</div>
              <div className="p-2.5 font-bold font-mono text-emerald-950 text-sm">{hen.tagCode}</div>
            </div>
            <div className="grid grid-cols-2 divide-x divide-stone-200 border-b border-stone-200">
              <div className="p-2.5 bg-stone-50 text-stone-500">Poultry Breed</div>
              <div className="p-2.5 font-semibold text-stone-900">{hen.breed}</div>
            </div>
            <div className="grid grid-cols-2 divide-x divide-stone-200 border-b border-stone-200">
              <div className="p-2.5 bg-stone-50 text-stone-500">Age at Registration</div>
              <div className="p-2.5 text-stone-800">{hen.ageWeeks} Weeks (Layer Stage)</div>
            </div>
            <div className="grid grid-cols-2 divide-x divide-stone-200 border-b border-stone-200">
              <div className="p-2.5 bg-stone-50 text-stone-500">Farm Location & Shed</div>
              <div className="p-2.5 text-stone-800">{hen.shedName} · Mandra Farm</div>
            </div>
            <div className="grid grid-cols-2 divide-x divide-stone-200">
              <div className="p-2.5 bg-stone-50 text-stone-500">Vaccination Status</div>
              <div className="p-2.5 text-emerald-800 font-medium">{hen.vaccinationStatus}</div>
            </div>
          </div>

          {/* Agreement Notice */}
          <p className="text-[11px] text-stone-500 text-center font-sans leading-relaxed">
            Maintained under Level-2 biosecurity protocols. All egg output from flock batches is sold wholesale with net proceeds allocated to the owner's ledger after deducting feed and management expenses.
          </p>

          {/* Signatures & Seal */}
          <div className="pt-6 border-t-2 border-emerald-900/20 grid grid-cols-3 items-end text-center font-sans text-xs">
            
            {/* Signature 1 */}
            <div className="space-y-1">
              <div className="font-serif italic text-base text-stone-800">Tariq Mahmood</div>
              <div className="border-t border-stone-400 pt-1 text-[11px] text-stone-600 font-medium">
                Farm Operations Lead
              </div>
            </div>

            {/* Farm Seal */}
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 rounded-full border-2 border-emerald-800 flex items-center justify-center bg-emerald-50 text-emerald-900 text-[10px] font-bold text-center leading-tight shadow-xs">
                OFFICIAL<br />SEAL
              </div>
            </div>

            {/* Signature 2 */}
            <div className="space-y-1">
              <div className="font-serif italic text-base text-stone-800">Dr. M. Yasir, DVM</div>
              <div className="border-t border-stone-400 pt-1 text-[11px] text-stone-600 font-medium">
                Resident Poultry Vet
              </div>
            </div>

          </div>

          {/* QR & Verification Bar */}
          <div className="pt-2 text-center text-[10px] text-stone-400 font-mono font-sans flex items-center justify-center gap-2">
            <QrCode className="w-3.5 h-3.5 text-stone-500" />
            <span>Digital Hash: SHA256-FME-{hen.id.toUpperCase()}-VERIFIED</span>
          </div>

        </div>

      </div>
    </div>
  );
};
