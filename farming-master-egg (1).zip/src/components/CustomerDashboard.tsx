import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Egg, 
  Wallet, 
  FileText, 
  Receipt, 
  Download, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  Award, 
  Bell, 
  ArrowUpRight, 
  ChevronRight, 
  Smartphone, 
  Building2, 
  Eye, 
  ShieldCheck, 
  Activity,
  Layers,
  ShoppingBag,
  TrendingUp,
  User,
  MapPin,
  Phone,
  Mail,
  Calendar,
  Lock,
  Headphones
} from 'lucide-react';

import { QuickAccessSection, QuickAccessTarget } from './customer/QuickAccessSection';
import { StatsOverviewSection } from './customer/StatsOverviewSection';
import { MyHensView } from './customer/MyHensView';
import { EggCollectionView } from './customer/EggCollectionView';
import { WithdrawalView } from './customer/WithdrawalView';
import { TransactionHistoryView } from './customer/TransactionHistoryView';
import { YourInvestmentView } from './customer/YourInvestmentView';
import { FarmInfoView } from './customer/FarmInfoView';
import { BottomNavBar } from './customer/BottomNavBar';
import { SupportModal } from './customer/SupportModal';
import { CustomerDepositView } from './customer/CustomerDepositView';
import { EggMarketplaceView } from './customer/EggMarketplaceView';

export type CustomerActiveTab = 
  | 'overview' 
  | 'sell-eggs'
  | 'my-hens' 
  | 'egg-collection'
  | 'egg-market'
  | 'withdraw'
  | 'deposit'
  | 'transactions' 
  | 'investment' 
  | 'purchases' 
  | 'farm-info'
  | 'profile' 
  | 'settings';

export const CustomerDashboard: React.FC = () => {
  const { 
    currentUser, 
    customerLogout,
    hens, 
    sheds,
    depositSettings,
    depositRequests,
    withdrawalSettings,
    withdrawals,
    purchases, 
    productionRecords, 
    eggSales,
    customerStatements, 
    lastCollectionCycleTime,
    requestWithdrawal, 
    setSelectedHenForCertificate, 
    setPurchaseModalOpen,
    setActiveView
  } = useApp();

  const [activeTab, setActiveTab] = useState<CustomerActiveTab>('overview');
  const [supportModalOpen, setSupportModalOpen] = useState<boolean>(false);

  useEffect(() => {
    const handler = (e: Event) => {
      const custom = e as CustomEvent<string>;
      if (custom.detail) {
        setActiveTab(custom.detail as CustomerActiveTab);
      }
    };
    window.addEventListener('fme_navigate_tab', handler);
    return () => window.removeEventListener('fme_navigate_tab', handler);
  }, []);

  // Customer owned hens
  const myHens = useMemo(() => {
    if (!currentUser) return [];
    return hens.filter(h => h.ownerId === currentUser.id);
  }, [hens, currentUser]);

  const myPurchases = purchases.filter(p => p.customerId === currentUser?.id);
  const myWithdrawals = withdrawals.filter(w => w.customerId === currentUser?.id);
  const myStatements = customerStatements.filter(s => s.customerId === currentUser?.id);

  // Quick Access Button Routing
  const handleQuickAccess = (target: QuickAccessTarget) => {
    switch (target) {
      case 'deposit':
        setActiveTab('deposit');
        break;
      case 'withdraw':
        setActiveTab('withdraw');
        break;
      case 'sell-eggs':
        setActiveTab('sell-eggs');
        break;
      case 'support':
        setSupportModalOpen(true);
        break;
      case 'transactions':
        setActiveTab('transactions');
        break;
      case 'investment':
        setActiveTab('investment');
        break;
      case 'my-hens':
        setActiveTab('my-hens');
        break;
      default:
        setActiveTab('overview');
    }
  };

  return (
    <div className="bg-[#faf8f5] min-h-screen py-6 sm:py-8 pb-28 md:pb-16 text-[#1c271e]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Header Card: Profile & Balance Bar */}
        <div className="bg-white rounded-2xl border border-emerald-950/10 p-5 sm:p-6 mb-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 uppercase tracking-wider">
              <span>Customer Bailment Portal</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-700 flex items-center gap-1 font-mono">
                <ShieldCheck className="w-3.5 h-3.5" /> Physical Hen Custody
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold font-display text-emerald-950 tracking-tight">
              {currentUser?.name || 'Customer Account'}
            </h1>
            <p className="text-xs text-stone-500 font-mono">
              Account ID: {currentUser?.id || 'cust-new'} · {currentUser?.email || 'Registered User'}
            </p>
          </div>

          {/* Balance & Instant Actions */}
          <div className="flex flex-wrap items-center gap-3 bg-[#f6f9f6] border border-emerald-900/10 p-3 sm:p-4 rounded-2xl">
            <div>
              <span className="text-[11px] font-semibold text-stone-500 block uppercase font-sans">
                Available Balance
              </span>
              <span className="text-xl sm:text-2xl font-bold text-emerald-950 font-mono tabular-nums">
                Rs. {currentUser ? currentUser.withdrawableBalance.toFixed(2) : '0.00'}
              </span>
            </div>
            <button
              onClick={() => setActiveTab('deposit')}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-xl transition-colors whitespace-nowrap shadow-xs cursor-pointer"
            >
              + Recharge
            </button>
            <button
              onClick={() => {
                setActiveView('marketplace');
                setPurchaseModalOpen(true);
              }}
              className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-xl transition-colors whitespace-nowrap shadow-xs cursor-pointer"
            >
              + Buy Hens (Rs. 500)
            </button>
          </div>
        </div>

        {/* 1. QUICK ACCESS SECTION (Always present on Dashboard Overview) */}
        {activeTab === 'overview' && (
          <QuickAccessSection 
            onSelect={handleQuickAccess} 
            activeTarget={activeTab} 
          />
        )}

        {/* 2. STATS OVERVIEW SECTION (Always present on Dashboard Overview) */}
        {activeTab === 'overview' && (
          <StatsOverviewSection
            depositRequests={depositRequests.filter(d => d.customerId === currentUser?.id)}
            withdrawals={myWithdrawals}
            purchases={myPurchases}
            myHens={myHens}
            productionRecords={productionRecords}
            onCardClick={(target) => {
              handleQuickAccess(target as QuickAccessTarget);
            }}
          />
        )}

        {/* Desktop Navigation Segmented Bar */}
        <div className="hidden md:flex items-center gap-1.5 p-1.5 bg-stone-200/60 rounded-2xl mb-8 overflow-x-auto text-xs font-semibold">
          {[
            { id: 'overview', label: 'Dashboard Home' },
            { id: 'sell-eggs', label: 'Egg Sell' },
            { id: 'my-hens', label: `My Hens (${myHens.length})` },
            { id: 'egg-collection', label: 'Egg Collection' },
            { id: 'deposit', label: 'Deposit' },
            { id: 'transactions', label: 'Transaction History' },
            { id: 'investment', label: 'Your Investment' },
            { id: 'purchases', label: `Orders (${myPurchases.length})` },
            { id: 'farm-info', label: 'Farm Info' },
            { id: 'settings', label: 'Profile' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as CustomerActiveTab)}
              className={`px-4 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-white text-emerald-950 font-bold shadow-xs'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100/60'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* --- VIEW ROUTER --- */}

        {/* TAB 1: OVERVIEW COMPACT SUMMARY (Recent Activity & Flock Health) */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left 2 Cols: My Active Flock Spotlight */}
            <div className="lg:col-span-2 bg-white rounded-2xl border border-emerald-950/10 p-5 sm:p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                <div>
                  <h3 className="font-bold text-base text-emerald-950 font-display">
                    Your Physical Layer Hens ({myHens.length})
                  </h3>
                  <p className="text-xs text-stone-500">
                    Individually tagged pullets maintained under formal bailment custody.
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('my-hens')}
                  className="text-xs font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1"
                >
                  <span>View All Hens</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {myHens.length === 0 ? (
                <div className="py-12 text-center space-y-3">
                  <Egg className="w-10 h-10 text-stone-300 mx-auto" />
                  <h4 className="font-bold text-sm text-stone-800">You currently own 0 physical hens</h4>
                  <p className="text-xs text-stone-500 max-w-sm mx-auto">
                    Acquire registered layer hens at <strong className="font-semibold text-stone-800">Rs. 500 each</strong>. Each hen receives an official downloadable Ownership Certificate.
                  </p>
                  <div className="pt-2 flex items-center justify-center gap-3">
                    <button
                      onClick={() => setActiveTab('deposit')}
                      className="px-4 py-2 border border-stone-300 text-stone-700 text-xs font-semibold rounded-xl hover:bg-stone-50 cursor-pointer"
                    >
                      Deposit Funds
                    </button>
                    <button
                      onClick={() => {
                        setActiveView('marketplace');
                        setPurchaseModalOpen(true);
                      }}
                      className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
                    >
                      Acquire Hens (Rs. 500)
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  {myHens.slice(0, 3).map(hen => (
                    <div
                      key={hen.id}
                      className="p-3.5 bg-stone-50 rounded-xl border border-stone-200/70 flex items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-xl overflow-hidden bg-stone-200 shrink-0 border border-stone-200">
                          <img
                            src={hen.photoUrl}
                            alt={hen.tagCode}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-xs text-emerald-950 bg-white px-1.5 py-0.5 rounded border border-stone-200">
                              {hen.tagCode}
                            </span>
                            <span className="text-xs text-stone-800 font-bold">{hen.breed}</span>
                          </div>
                          <div className="text-[11px] text-stone-500 mt-0.5">
                            {hen.shedName.split('-')[0]} · {hen.ageWeeks} wks · <span className="text-emerald-800 font-medium">{hen.healthStatus === 'healthy' ? 'Active Laying' : 'Molting Phase'}</span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => setSelectedHenForCertificate(hen)}
                        className="flex items-center gap-1 px-3 py-1.5 bg-white border border-stone-200 hover:border-emerald-700 text-emerald-900 rounded-lg text-xs font-semibold transition-colors shadow-2xs cursor-pointer"
                      >
                        <Award className="w-3.5 h-3.5 text-emerald-700" />
                        <span className="hidden sm:inline">Certificate</span>
                      </button>
                    </div>
                  ))}
                  {myHens.length > 3 && (
                    <button
                      onClick={() => setActiveTab('my-hens')}
                      className="w-full py-2.5 text-xs font-bold text-center text-emerald-800 bg-emerald-50/60 hover:bg-emerald-50 rounded-xl transition-colors cursor-pointer"
                    >
                      + View {myHens.length - 3} more active hens in My Hens
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Right 1 Col: Quick Helpful Shortcuts & Farm Help */}
            <div className="space-y-5">
              <div className="bg-white rounded-2xl border border-emerald-950/10 p-5 shadow-xs space-y-3">
                <h3 className="font-bold text-sm text-emerald-950 font-display flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-800" />
                  <span>Flock Operations Overview</span>
                </h3>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between p-2.5 bg-stone-50 rounded-xl">
                    <span className="text-stone-500">Scheduled Farm Sweep:</span>
                    <span className="font-mono font-bold text-emerald-950">06:00 AM Daily</span>
                  </div>
                  <div className="flex justify-between p-2.5 bg-stone-50 rounded-xl">
                    <span className="text-stone-500">Initial Hen Acquisition:</span>
                    <span className="font-mono font-bold text-stone-900">Rs. 500 / Bird</span>
                  </div>
                  <div className="flex justify-between p-2.5 bg-stone-50 rounded-xl">
                    <span className="text-stone-500">Facility Location:</span>
                    <span className="font-medium text-stone-900">Mandra-Chakwal</span>
                  </div>
                </div>

                <button
                  onClick={() => setActiveTab('egg-collection')}
                  className="w-full py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Egg className="w-3.5 h-3.5 text-amber-600" />
                  <span>View Full Egg Production Log</span>
                </button>
              </div>

              <div className="bg-emerald-950 text-white rounded-2xl p-5 shadow-xs space-y-2 text-xs">
                <div className="font-bold text-emerald-300 flex items-center gap-1.5">
                  <Headphones className="w-4 h-4 text-emerald-400" />
                  <span>Farm Customer Helpline</span>
                </div>
                <p className="text-[11px] text-emerald-200 leading-relaxed">
                  Have questions about deposit verification or egg collections? WhatsApp our duty supervisor at <strong className="text-white font-mono">+92 333 4920199</strong>.
                </p>
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: MY HENS PAGE */}
        {activeTab === 'my-hens' && (
          <MyHensView
            myHens={myHens}
            myPurchases={myPurchases}
            productionRecords={productionRecords}
            lastCollectionCycleTime={lastCollectionCycleTime}
            onOpenCertificate={(hen) => setSelectedHenForCertificate(hen)}
            onAcquireHens={() => {
              setActiveView('marketplace');
              setPurchaseModalOpen(true);
            }}
          />
        )}

        {/* TAB 3: EGG COLLECTION PAGE */}
        {activeTab === 'egg-collection' && (
          <EggCollectionView
            productionRecords={productionRecords}
            eggSales={eggSales}
            myHens={myHens}
          />
        )}

        {/* TAB 3B & TAB 5: UNIFIED "EGG SELL" SECTION (Handles egg selling & payout requests) */}
        {(activeTab === 'sell-eggs' || activeTab === 'egg-market' || activeTab === 'withdraw') && (
          <EggMarketplaceView onBackToCollection={() => setActiveTab('egg-collection')} />
        )}

        {/* TAB 4: DEPOSIT VIEW */}
        {activeTab === 'deposit' && (
          <CustomerDepositView />
        )}

        {/* TAB 6: TRANSACTION HISTORY PAGE */}
        {activeTab === 'transactions' && (
          <TransactionHistoryView
            currentUser={currentUser}
            depositRequests={depositRequests}
            purchases={purchases}
            withdrawals={withdrawals}
            customerStatements={customerStatements}
          />
        )}

        {/* TAB 7: YOUR INVESTMENT / OWNERSHIP PAGE */}
        {activeTab === 'investment' && (
          <YourInvestmentView
            currentUser={currentUser}
            myHens={myHens}
            myPurchases={myPurchases}
            onOpenCertificate={(hen) => setSelectedHenForCertificate(hen)}
            onAcquireHens={() => {
              setActiveView('marketplace');
              setPurchaseModalOpen(true);
            }}
            onOpenAgreement={() => setActiveView('agreement')}
          />
        )}

        {/* TAB 8: PURCHASES */}
        {activeTab === 'purchases' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between bg-white p-6 rounded-2xl border border-emerald-950/10 shadow-xs">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold font-display text-emerald-950">
                  Hen Acquisition History ({myPurchases.length})
                </h2>
                <p className="text-xs text-stone-500">
                  Track your hen orders, transaction references, and physical wing tag assignments.
                </p>
              </div>

              <button
                onClick={() => {
                  setActiveView('marketplace');
                  setPurchaseModalOpen(true);
                }}
                className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
              >
                + New Hen Order (Rs. 500)
              </button>
            </div>

            {myPurchases.length === 0 ? (
              <div className="p-12 bg-white rounded-2xl border border-stone-200 text-center space-y-2">
                <ShoppingBag className="w-10 h-10 text-stone-300 mx-auto" />
                <h4 className="font-bold text-sm text-stone-800">No purchase records found</h4>
                <p className="text-xs text-stone-500">
                  Purchased hens are verified by farm supervisors and assigned permanent wing tag codes.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {myPurchases.map(order => (
                  <div
                    key={order.id}
                    className="bg-white rounded-2xl border border-emerald-950/10 p-5 sm:p-6 shadow-xs space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-100 gap-2">
                      <div>
                        <span className="text-xs font-mono font-bold text-emerald-900">{order.id}</span>
                        <div className="text-xs text-stone-500">{order.createdAt}</div>
                      </div>

                      <div className="flex items-center gap-2">
                        {order.status === 'verified' && (
                          <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-md flex items-center gap-1">
                            <CheckCircle className="w-3.5 h-3.5" /> Verified & Assigned
                          </span>
                        )}
                        {order.status === 'pending' && (
                          <span className="text-xs font-semibold text-amber-800 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-md flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5" /> Pending Verification
                          </span>
                        )}
                        {order.status === 'rejected' && (
                          <span className="text-xs font-semibold text-red-800 bg-red-50 border border-red-200 px-2.5 py-1 rounded-md flex items-center gap-1">
                            <AlertCircle className="w-3.5 h-3.5" /> Declined
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
                      <div>
                        <span className="text-stone-500 text-[11px] block font-sans">Quantity</span>
                        <span className="font-semibold text-stone-900">{order.quantity} Hens</span>
                      </div>
                      <div>
                        <span className="text-stone-500 text-[11px] block font-sans">Total Paid</span>
                        <span className="font-bold text-emerald-950 tabular-nums">Rs. {order.totalAmount.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-stone-500 text-[11px] block font-sans">Payment Channel</span>
                        <span className="font-sans font-medium text-stone-800">{order.paymentMethod}</span>
                      </div>
                      <div>
                        <span className="text-stone-500 text-[11px] block font-sans">Tx Reference</span>
                        <span className="font-mono text-stone-800">{order.transactionReference}</span>
                      </div>
                    </div>

                    {order.assignedHenIds.length > 0 && (
                      <div className="pt-2 border-t border-stone-100 flex items-center gap-2 text-xs">
                        <span className="text-stone-500">Assigned Physical Tags:</span>
                        <div className="flex flex-wrap gap-1 font-mono font-bold text-emerald-900">
                          {order.assignedHenIds.map(id => {
                            const h = hens.find(hen => hen.id === id);
                            return (
                              <span key={id} className="bg-stone-100 px-2 py-0.5 rounded">
                                {h?.tagCode || id}
                              </span>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 9: FARM INFORMATION */}
        {activeTab === 'farm-info' && (
          <FarmInfoView
            sheds={sheds}
            hens={hens}
            productionRecords={productionRecords}
            onExploreMarketplace={() => setActiveView('marketplace')}
          />
        )}

        {/* TAB 10: SETTINGS & PROFILE */}
        {activeTab === 'settings' && (
          <div className="bg-white rounded-2xl border border-emerald-950/10 p-6 sm:p-8 shadow-xs max-w-2xl space-y-6">
            <h2 className="font-bold text-lg text-emerald-950 font-display pb-3 border-b border-stone-100">
              Customer Identity & Bailment Profile
            </h2>

            <div className="space-y-4 text-xs">
              <div className="flex items-center gap-3 p-4 bg-stone-50 rounded-xl border border-stone-200/70">
                <User className="w-5 h-5 text-emerald-800" />
                <div>
                  <span className="text-stone-500 block text-[11px]">Title Holder Legal Name</span>
                  <span className="font-bold text-sm text-stone-900">{currentUser?.name || 'Customer'}</span>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-stone-50 rounded-xl border border-stone-200/70">
                <Mail className="w-5 h-5 text-emerald-800" />
                <div>
                  <span className="text-stone-500 block text-[11px]">Primary Email</span>
                  <span className="font-bold text-sm text-stone-900">{currentUser?.email}</span>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-stone-50 rounded-xl border border-stone-200/70">
                <Phone className="w-5 h-5 text-emerald-800" />
                <div>
                  <span className="text-stone-500 block text-[11px]">Mobile Phone / WhatsApp</span>
                  <span className="font-bold text-sm text-stone-900 font-mono">{currentUser?.phone}</span>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-stone-50 rounded-xl border border-stone-200/70">
                <MapPin className="w-5 h-5 text-emerald-800" />
                <div>
                  <span className="text-stone-500 block text-[11px]">Registered Custody Address</span>
                  <span className="font-bold text-sm text-stone-900">{currentUser?.address || 'Pakistan'}</span>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
              <span>Account Registered: {currentUser?.joinedDate || '2026-11-05'}</span>
              <span className="text-emerald-800 font-medium">Bailment Status: Active</span>
            </div>
          </div>
        )}

      </div>

      {/* Mobile-First Fixed Bottom Navigation Bar (Requirement 12) */}
      <BottomNavBar
        activeTab={activeTab}
        onSelectTab={(tab) => setActiveTab(tab)}
        onLogout={customerLogout}
      />

      {/* Support Modal */}
      <SupportModal
        isOpen={supportModalOpen}
        onClose={() => setSupportModalOpen(false)}
        onNavigateAgreement={() => setActiveView('agreement')}
      />

    </div>
  );
};
