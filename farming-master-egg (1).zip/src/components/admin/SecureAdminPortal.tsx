import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  ShieldCheck, 
  Lock, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  Users, 
  Egg, 
  ShoppingBag, 
  Wallet, 
  Settings, 
  Activity, 
  Receipt, 
  FileText, 
  Bell, 
  ClipboardList, 
  TrendingUp, 
  RefreshCw, 
  PlusCircle, 
  Save, 
  Building2, 
  Smartphone, 
  Download, 
  LogOut, 
  ArrowLeft,
  Eye,
  EyeOff,
  Check,
  ChevronRight,
  Database,
  Calendar,
  Copy,
  Mail,
  Loader2
} from 'lucide-react';
import { 
  AdminActiveSection, 
  DepositMethodKey, 
  WithdrawalMethodKey,
  WithdrawalSetting,
  HenBreed, 
  HenHealthStatus, 
  ExpenseCategory 
} from '../../types';
import { SUPABASE_SCHEMA_SQL } from '../../data/supabaseSchema';
import { 
  fetchAllAppointments, 
  saveLocalAppointment, 
  SUPABASE_PROJECT_ID, 
  SUPABASE_DEFAULT_URL,
  SUPABASE_APPOINTMENTS_SQL, 
  SUPABASE_DEPOSITS_WITHDRAWALS_SQL,
  AppointmentRecord,
  testSupabaseHealth,
  supabase
} from '../../lib/supabase';

export const SecureAdminPortal: React.FC = () => {
  const { 
    isAdminAuthenticated, 
    adminLogin, 
    adminLogout, 
    currentUser, 
    setIsAdminRoute,
    setActiveView,
    adminSection,
    setAdminSection,
    hens,
    sheds,
    customers,
    depositSettings,
    depositRequests,
    withdrawalSettings,
    withdrawals,
    purchases, 
    productionRecords, 
    eggSales,
    expenses,
    financialCycles,
    customerStatements, 
    auditLogs,
    notifications,
    lastCollectionCycleTime,
    triggerEggCycleReset,
    addHen,
    updateHenStatus,
    recordMortality,
    recordProduction,
    recordEggSale,
    recordExpense,
    runMonthlyAllocation,
    processDepositRequest,
    updateDepositSetting,
    updateWithdrawalSetting,
    verifyPurchaseOrder,
    processWithdrawal,
    supportSetting,
    updateSupportSetting,
    eggAllocations,
    availableVerifiedEggs,
    allocateFlockProduction,
    adjustCustomerEggs,
    eggMarkets,
    updateEggMarket,
    eggSellingOrders,
    processEggSellingOrder,
    refreshLiveRequests,
    isRefreshingRequests,
    lastSyncTime,
    resetWebsiteData
  } = useApp();

  // Admin Login Credentials State (Authorized email: hanzlapremium@gmail.com)
  const [adminEmailInput, setAdminEmailInput] = useState('hanzlapremium@gmail.com');
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  // Status feedback toast
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  // Modals for request details & approvals
  const [selectedDepositForModal, setSelectedDepositForModal] = useState<any | null>(null);
  const [depositModalAdminNote, setDepositModalAdminNote] = useState<string>('');
  const [depositFilter, setDepositFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  const [selectedWithdrawalForModal, setSelectedWithdrawalForModal] = useState<any | null>(null);
  const [withdrawalModalTxRef, setWithdrawalModalTxRef] = useState<string>('');
  const [withdrawalModalNotes, setWithdrawalModalNotes] = useState<string>('');
  const [withdrawalFilter, setWithdrawalFilter] = useState<'all' | 'pending' | 'under_review' | 'approved' | 'paid' | 'rejected'>('all');

  const [selectedPurchaseForModal, setSelectedPurchaseForModal] = useState<any | null>(null);

  // Form states:
  // 1. Add Hen
  const [newHenTag, setNewHenTag] = useState(`FME-A${Math.floor(200 + Math.random() * 300)}`);
  const [newHenBreed, setNewHenBreed] = useState<HenBreed>('Rhode Island Red');
  const [newHenAge, setNewHenAge] = useState<number>(24);
  const [newHenShed, setNewHenShed] = useState(sheds[0]?.id || 'shed-1');
  const [newHenVaccine, setNewHenVaccine] = useState('Full Commercial Protocol Complete');

  // 2. Deposit Settings form state (editable in place)
  const [editingSettings, setEditingSettings] = useState(depositSettings);

  // 2b. Withdrawal Settings form state
  const [editingWithdrawalSettings, setEditingWithdrawalSettings] = useState(withdrawalSettings);

  // 3. Egg Production
  const [prodDate, setProdDate] = useState(new Date().toISOString().split('T')[0]);
  const [prodShedId, setProdShedId] = useState(sheds[0]?.id || 'shed-1');
  const [prodCollected, setProdCollected] = useState<number>(1850);
  const [prodDamaged, setProdDamaged] = useState<number>(12);
  const [prodReserved, setProdReserved] = useState<number>(18);
  const [prodNotes, setProdNotes] = useState('Morning collection verified.');

  // 4. Egg Sales
  const [saleDate, setSaleDate] = useState(new Date().toISOString().split('T')[0]);
  const [saleQty, setSaleQty] = useState<number>(4500);
  const [saleRate, setSaleRate] = useState<number>(14.75);
  const [saleBuyer, setSaleBuyer] = useState('Rawalpindi Wholesale Mandi');
  const [saleDest, setSaleDest] = useState('Rawalpindi Ganj Mandi');

  // 5. Farm Expense
  const [expDate, setExpDate] = useState(new Date().toISOString().split('T')[0]);
  const [expCat, setExpCat] = useState<ExpenseCategory>('feed');
  const [expAmount, setExpAmount] = useState<number>(38500);
  const [expDesc, setExpDesc] = useState('70 Bags Layer Mash 16% CP');
  const [expVoucher, setExpVoucher] = useState(`VCH-2026-${Math.floor(1000 + Math.random() * 9000)}`);

  // 6. Allocation Period
  const [allocPeriod, setAllocPeriod] = useState('November 2026');

  // 7. Support Settings Form State
  const [supportPhone, setSupportPhone] = useState(supportSetting.phoneNumber);
  const [supportWhatsapp, setSupportWhatsapp] = useState(supportSetting.whatsappNumber);
  const [supportName, setSupportName] = useState(supportSetting.displayName);
  const [supportDays, setSupportDays] = useState(supportSetting.availabilityDays);
  const [supportHours, setSupportHours] = useState(supportSetting.workingHours);
  const [supportEmail, setSupportEmail] = useState(supportSetting.email || '');
  const [supportMessage, setSupportMessage] = useState(supportSetting.customMessage);
  const [supportEnabled, setSupportEnabled] = useState(supportSetting.isEnabled);
  const [supportEditing, setSupportEditing] = useState(false);

  useEffect(() => {
    setSupportPhone(supportSetting.phoneNumber);
    setSupportWhatsapp(supportSetting.whatsappNumber);
    setSupportName(supportSetting.displayName);
    setSupportDays(supportSetting.availabilityDays);
    setSupportHours(supportSetting.workingHours);
    setSupportEmail(supportSetting.email || '');
    setSupportMessage(supportSetting.customMessage);
    setSupportEnabled(supportSetting.isEnabled);
  }, [supportSetting]);

  // 8. Admin Egg Allocation & Adjustment Form State
  const [allocShedId, setAllocShedId] = useState<string>('all');
  const [customAllocQty, setCustomAllocQty] = useState<number>(0);
  const [adjCustomer, setAdjCustomer] = useState<string>('');
  const [adjQty, setAdjQty] = useState<number>(1);
  const [adjReason, setAdjReason] = useState<string>('Supervisor physical inventory recount adjustment');

  // 9. Farm Visits & Appointments (Supabase Backend)
  const [appointmentsList, setAppointmentsList] = useState<AppointmentRecord[]>([]);
  const [isLiveSupabase, setIsLiveSupabase] = useState(false);
  const [loadingAppointments, setLoadingAppointments] = useState(false);
  const [copiedAdminSql, setCopiedAdminSql] = useState(false);
  const [supabaseHealthMsg, setSupabaseHealthMsg] = useState('Checking Supabase connection...');

  // 10. Egg Markets & Selling Orders (Supabase Tables F & G)
  const [editingMarketId, setEditingMarketId] = useState<string | null>(null);
  const [marketEditName, setMarketEditName] = useState<string>('');
  const [marketEditPrice, setMarketEditPrice] = useState<number>(50);
  const [marketEditMin, setMarketEditMin] = useState<number>(10);
  const [marketEditMax, setMarketEditMax] = useState<number>(500);
  const [marketEditCapacity, setMarketEditCapacity] = useState<number>(1000);
  const [marketEditTime, setMarketEditTime] = useState<string>('2 - 4 Hours');
  const [orderProcessingId, setOrderProcessingId] = useState<string | null>(null);
  const [orderPayoutRef, setOrderPayoutRef] = useState<string>('');
  const [orderInternalNotes, setOrderInternalNotes] = useState<string>('');
  const [orderFilter, setOrderFilter] = useState<'all' | 'pending' | 'processing' | 'paid' | 'rejected'>('all');
  const [orderRejectionModalId, setOrderRejectionModalId] = useState<string | null>(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState<string>('Daily market intake quota exceeded');

  // Sub-tabs for unified admin sections
  const [henSubTab, setHenSubTab] = useState<'inventory' | 'purchases' | 'ownership'>('inventory');
  const [eggSubTab, setEggSubTab] = useState<'inventory' | 'production' | 'allocation'>('inventory');
  const [paymentSubTab, setPaymentSubTab] = useState<'deposit' | 'withdrawal'>('deposit');
  const [websiteSubTab, setWebsiteSubTab] = useState<'supabase' | 'audit'>('supabase');

  const refreshAppointments = async () => {
    setLoadingAppointments(true);
    try {
      const res = await fetchAllAppointments();
      setAppointmentsList(res.records);
      setIsLiveSupabase(res.isLiveSupabase);
      const health = await testSupabaseHealth();
      setSupabaseHealthMsg(health.status);
    } catch (e: any) {
      console.warn('Error fetching appointments:', e);
    } finally {
      setLoadingAppointments(false);
    }
  };

  useEffect(() => {
    refreshAppointments();
  }, []);

  const updateAppointmentStatus = async (id: string, newStatus: 'pending' | 'confirmed' | 'completed' | 'cancelled') => {
    const updated = appointmentsList.map(item => item.id === id ? { ...item, status: newStatus } : item);
    setAppointmentsList(updated);
    const target = appointmentsList.find(item => item.id === id);
    if (target) {
      saveLocalAppointment({ ...target, status: newStatus });
    }
    // Also update in Supabase if live
    try {
      await supabase.from('appointments').update({ status: newStatus }).eq('id', id);
    } catch (e) {
      console.warn('Notice updating appointment status in Supabase:', e);
    }
  };

  // If a normal customer attempts to access /secure-farm-control
  if (!isAdminAuthenticated && currentUser && currentUser.role === 'customer') {
    return (
      <div className="min-h-screen bg-stone-900 flex items-center justify-center p-4">
        <div className="bg-stone-950 border border-red-800/80 p-8 rounded-2xl max-w-md w-full text-center space-y-4 text-white shadow-2xl">
          <div className="w-14 h-14 bg-red-950/80 border border-red-700 text-red-400 rounded-full flex items-center justify-center mx-auto">
            <Lock className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold font-display text-red-400">
            403 Forbidden - Access Restricted
          </h2>
          <p className="text-xs text-stone-300 leading-relaxed">
            Your logged-in customer account (<span className="text-white font-mono">{currentUser.email}</span>) does not hold administrative farm operations privileges.
          </p>
          <div className="p-3 bg-red-950/40 border border-red-900 rounded-lg text-[11px] text-red-300 text-left">
            Security Notice: All unauthorized route traversal attempts are recorded in the agricultural audit log.
          </div>
          <div className="pt-2 space-y-2">
            <button
              onClick={async () => {
                // Log out customer account to allow admin sign in
                if (typeof window !== 'undefined') {
                  localStorage.removeItem('fme_customer_session_user');
                }
                window.location.reload();
              }}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition-colors shadow-sm flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Sign Out to Admin Login</span>
            </button>

            <button
              onClick={() => {
                setIsAdminRoute(false);
                window.location.hash = '';
                setActiveView('customer-dashboard');
              }}
              className="w-full py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 font-medium text-xs rounded-lg transition-colors"
            >
              Return to Customer Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  // If not authenticated as Admin: Private Gate Screen
  if (!isAdminAuthenticated) {
    const handleLoginSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      setLoginError('');
      setIsAuthenticating(true);

      try {
        const res = await adminLogin(adminEmailInput, adminPasswordInput);
        if (!res.success) {
          setLoginError(res.message);
        } else {
          showToast(res.message);
        }
      } catch (err: any) {
        setLoginError(err?.message || 'Authentication error.');
      } finally {
        setIsAuthenticating(false);
      }
    };

    return (
      <div className="min-h-screen bg-stone-950 flex items-center justify-center p-4">
        <div className="bg-[#0f1712] border border-emerald-900/60 p-8 sm:p-9 rounded-3xl max-w-md w-full text-white shadow-2xl space-y-6">
          <div className="text-center space-y-2">
            <div className="w-13 h-13 bg-emerald-900/70 text-emerald-400 rounded-2xl flex items-center justify-center mx-auto border border-emerald-700/60 shadow-inner">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-950 border border-emerald-800/80 rounded-full text-[11px] font-mono text-emerald-300">
              <Lock className="w-3 h-3 text-emerald-400" />
              <span>Protected Admin Portal</span>
            </div>
            <h1 className="text-2xl font-bold font-display text-white tracking-tight">
              FARMING MASTER EGG
            </h1>
            <p className="text-xs text-stone-400 leading-relaxed">
              Restricted to authorized farm administrator (<strong className="text-emerald-300">hanzlapremium@gmail.com</strong>). Normal customer accounts cannot access this console.
            </p>
          </div>

          {loginError && (
            <div className="p-3.5 bg-red-950/80 border border-red-800 rounded-xl text-xs text-red-200 flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span className="leading-snug">{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
            <div>
              <label className="font-semibold text-stone-300 block mb-1.5">
                Authorized Admin Email *
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={adminEmailInput}
                  onChange={e => setAdminEmailInput(e.target.value)}
                  placeholder="hanzlapremium@gmail.com"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-stone-900/90 border border-emerald-900/80 rounded-xl text-white font-mono text-xs focus:outline-hidden focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400/30"
                  required
                  autoFocus
                />
              </div>
              <span className="text-[10px] text-emerald-400/80 mt-1 block">
                Single designated administrator: <code>hanzlapremium@gmail.com</code>
              </span>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-semibold text-stone-300 block">
                  Admin Password *
                </label>
                <span className="text-[10px] text-stone-500 font-mono">
                  Controlled via environment
                </span>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={adminPasswordInput}
                  onChange={e => setAdminPasswordInput(e.target.value)}
                  placeholder="Enter administrator password"
                  className="w-full pl-10 pr-10 py-2.5 bg-stone-900/90 border border-emerald-900/80 rounded-xl text-white font-mono text-xs focus:outline-hidden focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400/30"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-200 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isAuthenticating}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-800/50 text-white font-bold rounded-xl transition-all text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/30 cursor-pointer mt-2"
            >
              {isAuthenticating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Sign In as Administrator</span>
                </>
              )}
            </button>
          </form>

          <div className="pt-2 text-center">
            <button
              type="button"
              onClick={() => {
                setIsAdminRoute(false);
                if (typeof window !== 'undefined') {
                  window.location.hash = '';
                  if (window.location.pathname.startsWith('/admin') || window.location.pathname.includes('secure-farm-control')) {
                    window.history.replaceState(null, '', '/');
                  }
                }
                setActiveView('home');
              }}
              className="text-xs text-stone-400 hover:text-white underline inline-flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Exit to Public Customer Website</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // --- Handlers for Admin Operations ---
  const handleAddHenSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const shedObj = sheds.find(s => s.id === newHenShed) || sheds[0];
    addHen({
      tagCode: newHenTag,
      breed: newHenBreed,
      ageWeeks: newHenAge,
      healthStatus: 'healthy',
      shedId: shedObj.id,
      shedName: shedObj.name,
      flockCode: `FLK-${newHenBreed.slice(0, 3).toUpperCase()}-2026`,
      purchasePrice: 500,
      status: 'available',
      acquisitionDate: new Date().toISOString().split('T')[0],
      vaccinationStatus: newHenVaccine,
      photoUrl: '/src/assets/images/layer_hens_close_1793810684205.jpg',
      dailyEggYieldAvg: 0.85,
    });
    setNewHenTag(`FME-A${Math.floor(300 + Math.random() * 600)}`);
    showToast(`Physical hen ${newHenTag} registered in ${shedObj.name}.`);
  };

  const handleSaveDepositSetting = (methodKey: DepositMethodKey) => {
    const setting = editingSettings.find(s => s.methodKey === methodKey);
    if (!setting) return;
    updateDepositSetting(methodKey, setting);
    showToast(`Updated payment settings for ${setting.name}.`);
  };

  const handleSaveWithdrawalSetting = (methodKey: WithdrawalMethodKey) => {
    const setting = editingWithdrawalSettings.find(s => s.methodKey === methodKey);
    if (!setting) return;
    updateWithdrawalSetting(methodKey, setting);
    showToast(`Updated withdrawal settings for ${setting.name}.`);
  };

  const handleRecordProductionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const shedObj = sheds.find(s => s.id === prodShedId) || sheds[0];
    const netSaleable = Math.max(0, prodCollected - prodDamaged - prodReserved);
    const layingRate = Number(((prodCollected / shedObj.currentHens) * 100).toFixed(1));

    recordProduction({
      date: prodDate,
      shedId: shedObj.id,
      shedName: shedObj.name,
      flockSize: shedObj.currentHens,
      eggsCollected: prodCollected,
      eggsDamaged: prodDamaged,
      eggsReserved: prodReserved,
      eggsAvailableForSale: netSaleable,
      layingPercentage: layingRate,
      notes: prodNotes,
      loggedBy: 'Tariq Mahmood (Farm Mgr)',
    });
    showToast(`Production logged: ${prodCollected} eggs collected.`);
  };

  const handleRecordEggSaleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const gross = Number((saleQty * saleRate).toFixed(2));
    recordEggSale({
      date: saleDate,
      quantityEggs: saleQty,
      ratePerEgg: saleRate,
      grossAmount: gross,
      buyerName: saleBuyer,
      marketLocation: saleDest,
      paymentStatus: 'paid',
      invoiceNumber: `INV-EGG-${Date.now().toString().slice(-6)}`,
    });
    showToast(`Recorded wholesale egg sale of Rs. ${gross.toLocaleString()}.`);
  };

  const handleRecordExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    recordExpense({
      date: expDate,
      category: expCat,
      amount: expAmount,
      description: expDesc,
      voucherNumber: expVoucher,
      receiptAvailable: true,
    });
    setExpVoucher(`VCH-2026-${Math.floor(1000 + Math.random() * 9000)}`);
    showToast(`Logged ${expCat.toUpperCase()} expense of Rs. ${expAmount.toLocaleString()}.`);
  };

  const handleDownloadBackup = () => {
    const backupData = {
      system: 'FARMING MASTER EGG - LIVE DATABASE SNAPSHOT',
      exportedAt: new Date().toISOString(),
      hensCount: hens.length,
      customersCount: customers.length,
      depositSettings,
      depositRequests,
      purchases,
      withdrawals,
      productionRecords,
      eggSales,
      expenses,
      financialCycles,
      customerStatements,
      auditLogs,
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `farming_master_egg_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    showToast('Database backup downloaded successfully.');
  };

  // Metrics
  const pendingDeposits = depositRequests.filter(d => d.status === 'pending');
  const pendingPurchases = purchases.filter(p => p.status === 'pending');
  const pendingWithdrawals = withdrawals.filter(w => w.status === 'pending');
  const availableHens = hens.filter(h => h.status === 'available');
  const ownedHens = hens.filter(h => h.status === 'owned');
  const pendingAppointmentsCount = appointmentsList.filter(a => a.status === 'pending').length;

  const menuSections: { id: AdminActiveSection; label: string; badge?: number }[] = [
    { id: 'overview', label: '1. Dashboard' },
    { id: 'customers', label: `2. Customers (${customers.length})` },
    { id: 'hens', label: `3. Hen Management (${hens.length})`, badge: pendingPurchases.length },
    { id: 'deposits', label: '4. Deposits', badge: pendingDeposits.length },
    { id: 'withdrawals', label: '5. Withdrawals', badge: pendingWithdrawals.length },
    { id: 'egg-management', label: '6. Egg Management' },
    { id: 'egg-markets', label: '7. Egg Markets' },
    { id: 'selling-orders', label: '8. Selling Orders', badge: eggSellingOrders.filter(o => o.orderStatus === 'pending').length },
    { id: 'payment-settings', label: '9. Payment Settings' },
    { id: 'support-settings', label: '10. Support Settings' },
    { id: 'website-settings', label: '11. Website Settings' },
  ];

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col">
      
      {/* Admin Top Navigation */}
      <header className="bg-emerald-950 text-white px-6 py-3 flex items-center justify-between border-b border-emerald-900 sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-800 border border-emerald-700 flex items-center justify-center text-emerald-300">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold text-sm font-display tracking-tight text-white leading-tight">
              FARMING MASTER EGG · SECURE FARM CONTROL
            </h1>
            <span className="text-[10px] text-emerald-400 font-mono">
              Private Route: /secure-farm-control · Role: Operations Lead
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2.5 text-xs">
          <button
            onClick={async () => {
              await refreshLiveRequests();
              showToast('Synchronized with live Supabase database tables!');
            }}
            disabled={isRefreshingRequests}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors border font-medium cursor-pointer ${
              isRefreshingRequests
                ? 'bg-emerald-900 text-emerald-300 border-emerald-700 animate-pulse'
                : 'bg-emerald-850 hover:bg-emerald-800 text-emerald-200 hover:text-white border-emerald-700'
            }`}
            title="Check live requests from Supabase"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingRequests ? 'animate-spin text-emerald-400' : 'text-emerald-300'}`} />
            <span>{isRefreshingRequests ? 'Syncing...' : 'Sync Requests'}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse ml-0.5" />
          </button>

          <button
            onClick={() => setIsResetModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-900/60 hover:bg-amber-800 text-amber-200 hover:text-white rounded-lg transition-colors border border-amber-700 font-medium cursor-pointer"
            title="Reset all demo customer accounts, purchases, and requests"
          >
            <RefreshCw className="w-3.5 h-3.5 text-amber-300" />
            <span>Reset All Data</span>
          </button>

          <button
            onClick={() => {
              setIsAdminRoute(false);
              window.location.hash = '';
              setActiveView('home');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-850 hover:bg-emerald-800 text-emerald-200 hover:text-white rounded-lg transition-colors border border-emerald-700 font-medium"
            title="Switch to customer-facing public site"
          >
            <Eye className="w-3.5 h-3.5 text-emerald-300" />
            <span>Preview Public Site</span>
          </button>

          <button
            onClick={adminLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-red-900/60 hover:bg-red-800 text-red-100 rounded-lg transition-colors border border-red-700"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Lock & Exit Console</span>
          </button>
        </div>
      </header>

      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-14 right-6 z-50 bg-emerald-900 text-white px-4 py-2.5 rounded-xl shadow-lg border border-emerald-700 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-300" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Website Complete Reset Confirmation Modal */}
      {isResetModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center gap-3 text-red-700 pb-2 border-b border-stone-100">
              <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <h3 className="font-bold text-base text-stone-900 font-display">
                  Reset All Website Data
                </h3>
                <span className="text-xs text-stone-500">Irreversible Clean Fresh Start</span>
              </div>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              This will completely wipe all test/demo customer accounts, hen purchase orders, deposit requests, withdrawals, egg balances, and egg selling orders from both the local database cache and Supabase backend.
            </p>

            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900 space-y-1">
              <span className="font-bold block">What will be preserved:</span>
              <ul className="list-disc pl-4 space-y-0.5 text-amber-800">
                <li>Your main Admin Account & PIN (<code>admin2026</code>)</li>
                <li>Farm Sheds & Physical Layer Hen Catalog (Rs. 500)</li>
                <li>Official Mandi Market Rates (Rs. 40, 50, 60)</li>
                <li>Payment Gateway Settings (Easypaisa, JazzCash, Bank)</li>
              </ul>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setIsResetModalOpen(false)}
                disabled={isResetting}
                className="px-4 py-2 border border-stone-300 text-stone-700 rounded-xl text-xs font-semibold hover:bg-stone-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isResetting}
                onClick={async () => {
                  setIsResetting(true);
                  try {
                    await resetWebsiteData();
                    showToast('Website data has been successfully reset! Starting clean.');
                    setIsResetModalOpen(false);
                  } catch (e: any) {
                    showToast(`Notice: ${e.message || 'Reset completed.'}`);
                    setIsResetModalOpen(false);
                  } finally {
                    setIsResetting(false);
                  }
                }}
                className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
              >
                {isResetting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Resetting Data...</span>
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Confirm Complete Reset</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Layout: Sidebar + Viewport */}
      <div className="flex-1 flex flex-col md:flex-row">
        
        {/* Sidebar (240px - 280px) */}
        <aside className="w-full md:w-64 bg-white border-r border-stone-200 p-4 shrink-0 space-y-1 overflow-y-auto">
          <div className="text-[11px] font-bold uppercase tracking-wider text-stone-400 px-3 py-1 mb-1">
            Admin Sections
          </div>
          {menuSections.map(s => {
            const isActive = adminSection === s.id;
            return (
              <button
                key={s.id}
                onClick={() => setAdminSection(s.id)}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-lg transition-colors text-left ${
                  isActive
                    ? 'bg-emerald-800 text-white font-bold shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <span className="truncate">{s.label}</span>
                {s.badge !== undefined && s.badge > 0 && (
                  <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                    isActive ? 'bg-amber-400 text-emerald-950' : 'bg-amber-100 text-amber-900'
                  }`}>
                    {s.badge}
                  </span>
                )}
              </button>
            );
          })}
        </aside>

        {/* Content Viewport */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto max-w-6xl space-y-6">
          
          {/* 1. OVERVIEW */}
          {adminSection === 'overview' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <h2 className="text-xl font-bold font-display text-emerald-950">
                  1. Farm Operations Executive Overview
                </h2>
                <span className="text-xs text-stone-500 font-mono">
                  Clean Verified State · Initial Hen Price: Rs. 500
                </span>
              </div>

              {/* KPI Strip */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-xs text-stone-500">Total Physical Hens</span>
                  <div className="text-2xl font-bold font-display text-emerald-950 font-mono tabular-nums">{hens.length}</div>
                  <div className="text-[11px] text-stone-500">{availableHens.length} available · {ownedHens.length} owned</div>
                </div>

                <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-xs text-stone-500">Registered Customers</span>
                  <div className="text-2xl font-bold font-display text-emerald-950 font-mono tabular-nums">{customers.length}</div>
                  <div className="text-[11px] text-stone-500">Real customer records only</div>
                </div>

                <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-xs text-stone-500">Pending Deposits</span>
                  <div className="text-2xl font-bold font-display text-amber-900 font-mono tabular-nums">{pendingDeposits.length}</div>
                  <div className="text-[11px] text-stone-500">Awaiting manual bank check</div>
                </div>

                <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-xs text-stone-500">Pending Hen Purchases</span>
                  <div className="text-2xl font-bold font-display text-emerald-950 font-mono tabular-nums">{pendingPurchases.length}</div>
                  <div className="text-[11px] text-stone-500">Awaiting ID tag assignment</div>
                </div>
              </div>

              {/* Action Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Deposit Review Widget */}
                <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-emerald-950">Deposit Requests Queue</h3>
                    <button onClick={() => setAdminSection('deposits')} className="text-xs text-emerald-800 font-semibold hover:underline">
                      View All ({depositRequests.length}) &gt;
                    </button>
                  </div>
                  {pendingDeposits.length === 0 ? (
                    <p className="text-xs text-stone-500 italic py-4">No pending deposits requiring verification.</p>
                  ) : (
                    <div className="space-y-2 text-xs">
                      {pendingDeposits.slice(0, 3).map(d => (
                        <div key={d.id} className="p-3 bg-stone-50 rounded-lg border border-stone-200 flex justify-between items-center">
                          <div>
                            <span className="font-bold text-stone-900">{d.customerName}</span>
                            <span className="text-stone-500 text-[11px] block">{d.methodName} · TRX: {d.transactionReference}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-emerald-950">Rs. {d.amount}</span>
                            <button
                              onClick={() => processDepositRequest(d.id, 'approve')}
                              className="px-2 py-1 bg-emerald-800 text-white rounded text-[11px] font-semibold"
                            >
                              Approve
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Hen Inventory Status */}
                <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-emerald-950">Hen Inventory Status</h3>
                    <button onClick={() => setAdminSection('hens')} className="text-xs text-emerald-800 font-semibold hover:underline">
                      Manage Registry ({hens.length}) &gt;
                    </button>
                  </div>
                  <div className="p-4 bg-emerald-50 rounded-lg text-xs space-y-1 text-emerald-950">
                    <div className="flex justify-between">
                      <span>Available for Customer Purchase:</span>
                      <strong className="font-mono text-emerald-900">{availableHens.length} Hens</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Customer-Owned (Under Custody):</span>
                      <strong className="font-mono text-emerald-900">{ownedHens.length} Hens</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Initial Listed Price:</span>
                      <strong className="font-mono text-emerald-900">Rs. 500 / Hen</strong>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* 2. CUSTOMER MANAGEMENT */}
          {adminSection === 'customers' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <div>
                  <h2 className="text-xl font-bold font-display text-emerald-950">2. Customer Registry</h2>
                  <p className="text-xs text-stone-500">Registered customers, balances, and custody holdings</p>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden">
                {customers.length === 0 ? (
                  <div className="py-12 text-center text-xs text-stone-500 space-y-2">
                    <Users className="w-8 h-8 text-stone-300 mx-auto" />
                    <p className="font-semibold text-stone-700">No customer records in database</p>
                    <p className="text-[11px]">All demo customer profiles have been cleaned. Real customers appear here upon registration.</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                          <th className="p-3">Customer ID</th>
                          <th className="p-3">Full Legal Name</th>
                          <th className="p-3">Email Address</th>
                          <th className="p-3">Phone</th>
                          <th className="p-3">Withdrawable Balance</th>
                          <th className="p-3">Joined Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {customers.map(c => (
                          <tr key={c.id}>
                            <td className="p-3 text-emerald-950 font-bold">{c.id}</td>
                            <td className="p-3 font-sans font-medium text-stone-900">{c.name}</td>
                            <td className="p-3 text-stone-700">{c.email}</td>
                            <td className="p-3 text-stone-700">{c.phone}</td>
                            <td className="p-3 font-bold text-emerald-900">Rs. {c.withdrawableBalance.toFixed(2)}</td>
                            <td className="p-3 text-stone-500">{c.joinedDate}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 3. HEN INVENTORY */}
          {adminSection === 'hens' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <div>
                  <h2 className="text-xl font-bold font-display text-emerald-950">3. Physical Hen Inventory</h2>
                  <p className="text-xs text-stone-500">Real layer hens with physical wing tag codes (Initial Price: Rs. 500)</p>
                </div>
              </div>

              {/* Automated Flock Status & Customer Ownership Banner */}
              <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-100 pb-3">
                  <div>
                    <h3 className="font-bold text-sm text-emerald-950 font-display">
                      Automated Flock Management & Customer Ownership
                    </h3>
                    <p className="text-xs text-stone-500">
                      Customers acquire hens automatically without manual registration. Unique IDs, tags, and 1:1 initial eggs are system-generated upon purchase.
                    </p>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[11px] font-bold rounded-full border border-emerald-300">
                    Auto-Assignment Active
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-100">
                    <span className="text-stone-500 block text-[11px]">Total Farm Flock</span>
                    <strong className="text-base font-bold text-emerald-950 font-mono">{hens.length} Hens</strong>
                  </div>
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                    <span className="text-emerald-800 block text-[11px]">Customer Owned</span>
                    <strong className="text-base font-bold text-emerald-900 font-mono">{ownedHens.length} Hens</strong>
                  </div>
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-100">
                    <span className="text-amber-800 block text-[11px]">Farm Available Pool</span>
                    <strong className="text-base font-bold text-amber-900 font-mono">{availableHens.length} Hens</strong>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-xl border border-blue-100">
                    <span className="text-blue-800 block text-[11px]">Acquisition Rate</span>
                    <strong className="text-base font-bold text-blue-900 font-mono">Rs. 500 / Hen</strong>
                  </div>
                </div>
              </div>

              {/* Hen Table */}
              <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden">
                <div className="p-3.5 bg-stone-50 border-b border-stone-200 text-xs font-semibold text-stone-700">
                  Current Physical Inventory ({hens.length} Hens)
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                        <th className="p-3">Tag Code</th>
                        <th className="p-3">Breed</th>
                        <th className="p-3">Age</th>
                        <th className="p-3">Shed</th>
                        <th className="p-3">Status</th>
                        <th className="p-3">Owner</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {hens.map(h => (
                        <tr key={h.id}>
                          <td className="p-3 font-bold text-emerald-950">{h.tagCode}</td>
                          <td className="p-3 font-sans text-stone-900">{h.breed}</td>
                          <td className="p-3 text-stone-600">{h.ageWeeks} wks</td>
                          <td className="p-3 font-sans text-stone-600">{h.shedName.split('-')[0]}</td>
                          <td className="p-3 font-sans">
                            {h.status === 'available' ? (
                              <span className="text-emerald-800 font-semibold bg-emerald-50 px-2 py-0.5 rounded">Available</span>
                            ) : (
                              <span className="text-amber-800 font-semibold bg-amber-50 px-2 py-0.5 rounded">Customer Owned</span>
                            )}
                          </td>
                          <td className="p-3 font-sans text-stone-700">{h.ownerName || '—'}</td>
                          <td className="p-3 text-right font-sans space-x-2">
                            <button
                              onClick={() => updateHenStatus(h.id, { healthStatus: h.healthStatus === 'healthy' ? 'molting' : 'healthy' })}
                              className="text-[11px] text-stone-600 hover:text-emerald-900 underline"
                            >
                              Toggle Molt
                            </button>
                            <button
                              onClick={() => recordMortality(h.id, 'Natural causes during summer heat peak')}
                              className="text-[11px] text-red-600 hover:text-red-800 underline"
                            >
                              Log Mortality
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* 4. HEN OWNERSHIP */}
          {adminSection === 'ownership' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <div>
                  <h2 className="text-xl font-bold font-display text-emerald-950">4. Hen Ownership Records</h2>
                  <p className="text-xs text-stone-500">Customer ownership title records and issued custody certificates</p>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden">
                {ownedHens.length === 0 ? (
                  <div className="py-12 text-center text-xs text-stone-500 space-y-2">
                    <Egg className="w-8 h-8 text-stone-300 mx-auto" />
                    <p className="font-semibold text-stone-700">Zero customer-owned hens currently</p>
                    <p className="text-[11px]">All demo ownership records were wiped. When customers buy hens, ownership titles appear here.</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                          <th className="p-3">Hen Tag</th>
                          <th className="p-3">Breed</th>
                          <th className="p-3">Owner Name</th>
                          <th className="p-3">Acquisition Date</th>
                          <th className="p-3">Shed Location</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {ownedHens.map(h => (
                          <tr key={h.id}>
                            <td className="p-3 font-bold text-emerald-950">{h.tagCode}</td>
                            <td className="p-3 font-sans text-stone-900">{h.breed}</td>
                            <td className="p-3 font-sans font-semibold text-emerald-900">{h.ownerName}</td>
                            <td className="p-3 text-stone-600">{h.acquisitionDate}</td>
                            <td className="p-3 font-sans text-stone-700">{h.shedName}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 5. PURCHASE MANAGEMENT */}
          {adminSection === 'purchases' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <div>
                  <h2 className="text-xl font-bold font-display text-emerald-950">5. Purchase Orders & Verification</h2>
                  <p className="text-xs text-stone-500">Verify customer payments and assign unique physical hen tag IDs</p>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden">
                {purchases.length === 0 ? (
                  <div className="py-12 text-center text-xs text-stone-500 space-y-1">
                    <ShoppingBag className="w-8 h-8 text-stone-300 mx-auto" />
                    <p>No purchase orders in database.</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                          <th className="p-3">Order ID</th>
                          <th className="p-3">Customer</th>
                          <th className="p-3">Qty</th>
                          <th className="p-3">Total (Rs.)</th>
                          <th className="p-3">Gateway</th>
                          <th className="p-3">Tx Reference</th>
                          <th className="p-3">Status</th>
                          <th className="p-3 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {purchases.map(p => (
                          <tr key={p.id}>
                            <td className="p-3 font-bold text-emerald-950">{p.id}</td>
                            <td className="p-3 font-sans">
                              <div className="font-semibold text-stone-900">{p.customerName}</div>
                              <div className="text-[11px] text-stone-500">{p.customerPhone}</div>
                            </td>
                            <td className="p-3 text-stone-900">{p.quantity}</td>
                            <td className="p-3 font-bold text-emerald-950">Rs. {p.totalAmount}</td>
                            <td className="p-3 font-sans text-stone-700">{p.paymentMethod}</td>
                            <td className="p-3 text-stone-800">{p.transactionReference}</td>
                            <td className="p-3 font-sans">
                              {p.status === 'verified' ? (
                                <span className="text-emerald-800 font-semibold bg-emerald-50 px-2 py-0.5 rounded">Verified</span>
                              ) : (
                                <span className="text-amber-800 font-semibold bg-amber-50 px-2 py-0.5 rounded">Pending</span>
                              )}
                            </td>
                            <td className="p-3 text-right font-sans">
                              {p.status === 'pending' && (
                                <button
                                  onClick={() => {
                                    const res = verifyPurchaseOrder(p.id);
                                    if (res.success) showToast(res.message);
                                    else alert(res.message);
                                  }}
                                  className="px-3 py-1 bg-emerald-800 hover:bg-emerald-900 text-white rounded-md text-xs font-semibold shadow-xs"
                                >
                                  Verify & Assign Tags
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 6. DEPOSIT MANAGEMENT */}
          {adminSection === 'deposits' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-200 gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                      <Database className="w-3 h-3 text-emerald-700" /> Supabase: {SUPABASE_PROJECT_ID}
                    </span>
                    <span className="text-[10px] font-mono text-stone-500">public.deposits</span>
                  </div>
                  <h2 className="text-xl font-bold font-display text-emerald-950">6. Customer Deposit Requests</h2>
                  <p className="text-xs text-stone-500">Review payment slips, verify bank/wallet transactions, and credit customer balances</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(SUPABASE_DEPOSITS_WITHDRAWALS_SQL);
                      showToast('Copied Supabase Deposits & Withdrawals SQL to clipboard!');
                    }}
                    className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5 text-stone-600" />
                    <span>Copy Supabase SQL</span>
                  </button>
                  <a
                    href={`https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}/sql/new`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Database className="w-3.5 h-3.5" />
                    <span>SQL Editor</span>
                  </a>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden">
                {depositRequests.length === 0 ? (
                  <div className="py-12 text-center text-xs text-stone-500 space-y-1">
                    <Wallet className="w-8 h-8 text-stone-300 mx-auto" />
                    <p>No deposit requests in queue.</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                          <th className="p-3">Req ID</th>
                          <th className="p-3">Customer</th>
                          <th className="p-3">Method</th>
                          <th className="p-3">TRX Reference</th>
                          <th className="p-3">Amount</th>
                          <th className="p-3">Status</th>
                          <th className="p-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {depositRequests.map(d => (
                          <tr key={d.id}>
                            <td className="p-3 font-bold text-emerald-950">{d.id}</td>
                            <td className="p-3 font-sans">
                              <div className="font-semibold text-stone-900">{d.customerName}</div>
                              <div className="text-[11px] text-stone-500">{d.customerPhone}</div>
                            </td>
                            <td className="p-3 font-sans text-stone-800">{d.methodName}</td>
                            <td className="p-3 font-bold text-stone-900">{d.transactionReference}</td>
                            <td className="p-3 font-bold text-emerald-900">Rs. {d.amount.toLocaleString()}</td>
                            <td className="p-3 font-sans">
                              {d.status === 'approved' && <span className="text-emerald-800 font-semibold bg-emerald-50 px-2 py-0.5 rounded">Approved</span>}
                              {d.status === 'pending' && <span className="text-amber-800 font-semibold bg-amber-50 px-2 py-0.5 rounded">Pending Verification</span>}
                              {d.status === 'rejected' && <span className="text-red-800 font-semibold bg-red-50 px-2 py-0.5 rounded">Rejected</span>}
                            </td>
                            <td className="p-3 text-right font-sans space-x-2">
                              {d.status === 'pending' && (
                                <>
                                  <button
                                    onClick={() => {
                                      processDepositRequest(d.id, 'approve');
                                      showToast(`Approved deposit of Rs. ${d.amount} for ${d.customerName}.`);
                                    }}
                                    className="px-2.5 py-1 bg-emerald-800 hover:bg-emerald-900 text-white rounded text-xs font-semibold shadow-xs"
                                  >
                                    Approve & Credit
                                  </button>
                                  <button
                                    onClick={() => {
                                      processDepositRequest(d.id, 'reject', 'TRX reference invalid or not received in merchant account.');
                                      showToast(`Rejected deposit for ${d.customerName}.`);
                                    }}
                                    className="px-2.5 py-1 bg-stone-100 hover:bg-red-50 text-red-700 border border-stone-200 rounded text-xs font-semibold"
                                  >
                                    Decline
                                  </button>
                                </>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 7. DEPOSIT SETTINGS */}
          {adminSection === 'deposit-settings' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <div>
                  <h2 className="text-xl font-bold font-display text-emerald-950">7. Deposit Gateway Configuration</h2>
                  <p className="text-xs text-stone-500">Configure corporate payment methods, accounts, and customer instructions</p>
                </div>
              </div>

              <div className="space-y-6">
                {editingSettings.map(setting => (
                  <div
                    key={setting.id}
                    className="bg-white p-6 rounded-xl border border-stone-200 shadow-xs space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-100 gap-2">
                      <div className="flex items-center gap-2">
                        {setting.methodKey === 'bank_transfer' ? <Building2 className="w-5 h-5 text-emerald-800" /> : <Smartphone className="w-5 h-5 text-emerald-800" />}
                        <h3 className="font-bold text-base text-emerald-950 font-display">{setting.name}</h3>
                      </div>

                      <div className="flex items-center gap-3">
                        <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-stone-700">
                          <input
                            type="checkbox"
                            checked={setting.isEnabled}
                            onChange={e => {
                              const updated = editingSettings.map(s => s.methodKey === setting.methodKey ? { ...s, isEnabled: e.target.checked } : s);
                              setEditingSettings(updated);
                            }}
                            className="rounded border-stone-300 text-emerald-800 focus:ring-emerald-700"
                          />
                          <span>{setting.isEnabled ? 'Method Active' : 'Disabled'}</span>
                        </label>

                        <button
                          onClick={() => handleSaveDepositSetting(setting.methodKey)}
                          className="flex items-center gap-1 px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-bold shadow-xs transition-colors"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>Save & Update</span>
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div>
                        <label className="font-semibold text-stone-700 block mb-1">Account Holder Name *</label>
                        <input
                          type="text"
                          value={setting.accountHolderName}
                          onChange={e => {
                            const val = e.target.value;
                            setEditingSettings(prev => prev.map(s => s.methodKey === setting.methodKey ? { ...s, accountHolderName: val } : s));
                          }}
                          className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                        />
                      </div>

                      <div>
                        <label className="font-semibold text-stone-700 block mb-1">
                          {setting.methodKey === 'bank_transfer' ? 'IBAN / Account Number *' : 'Mobile Wallet Number *'}
                        </label>
                        <input
                          type="text"
                          value={setting.accountNumber}
                          onChange={e => {
                            const val = e.target.value;
                            setEditingSettings(prev => prev.map(s => s.methodKey === setting.methodKey ? { ...s, accountNumber: val } : s));
                          }}
                          className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900 font-mono text-xs"
                        />
                      </div>

                      {setting.methodKey === 'bank_transfer' && (
                        <div>
                          <label className="font-semibold text-stone-700 block mb-1">Bank Name & Branch</label>
                          <input
                            type="text"
                            value={setting.bankName || ''}
                            onChange={e => {
                              const val = e.target.value;
                              setEditingSettings(prev => prev.map(s => s.methodKey === setting.methodKey ? { ...s, bankName: val } : s));
                            }}
                            className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                          />
                        </div>
                      )}

                      <div>
                        <label className="font-semibold text-stone-700 block mb-1">Account Category / Details</label>
                        <input
                          type="text"
                          value={setting.accountDetails || ''}
                          onChange={e => {
                            const val = e.target.value;
                            setEditingSettings(prev => prev.map(s => s.methodKey === setting.methodKey ? { ...s, accountDetails: val } : s));
                          }}
                          className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="font-semibold text-stone-700 block mb-1">Payment Instructions to Customer</label>
                        <textarea
                          rows={2}
                          value={setting.paymentInstructions || ''}
                          onChange={e => {
                            const val = e.target.value;
                            setEditingSettings(prev => prev.map(s => s.methodKey === setting.methodKey ? { ...s, paymentInstructions: val } : s));
                          }}
                          className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 10. SUPPORT SETTINGS */}
          {adminSection === 'support-settings' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-200 gap-3">
                <div>
                  <h2 className="text-xl font-bold font-display text-emerald-950">10. Customer Support Settings</h2>
                  <p className="text-xs text-stone-500">
                    Configure customer care phone lines, WhatsApp channels, working hours, and operational announcements.
                  </p>
                </div>

                {/* Enable / Disable Support Status Pill & Toggle */}
                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${
                    supportEnabled
                      ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                      : 'bg-amber-100 text-amber-900 border-amber-300'
                  }`}>
                    <span className={`w-2 h-2 rounded-full ${supportEnabled ? 'bg-emerald-600 animate-pulse' : 'bg-amber-600'}`} />
                    <span>{supportEnabled ? 'SUPPORT ACTIVE' : 'SUPPORT DISABLED'}</span>
                  </span>

                  <button
                    type="button"
                    onClick={() => {
                      const nextState = !supportEnabled;
                      setSupportEnabled(nextState);
                      updateSupportSetting({ isEnabled: nextState });
                      showToast(`Customer support is now ${nextState ? 'ENABLED (Online)' : 'DISABLED (Offline)'}.`);
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer ${
                      supportEnabled
                        ? 'bg-amber-600 hover:bg-amber-700 text-white'
                        : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                    }`}
                  >
                    {supportEnabled ? 'Disable Support' : 'Enable Support'}
                  </button>
                </div>
              </div>

              {/* Support Settings Form & Preview */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Form Controls (2 Cols) */}
                <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-5">
                  <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                    <h3 className="font-bold text-sm text-emerald-950 font-display">
                      Helpdesk & Contact Parameters
                    </h3>
                    <div className="flex items-center gap-2">
                      {!supportEditing ? (
                        <button
                          type="button"
                          onClick={() => setSupportEditing(true)}
                          className="px-3.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold cursor-pointer"
                        >
                          Edit Settings
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setSupportEditing(false)}
                          className="px-3.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-lg text-xs font-semibold cursor-pointer"
                        >
                          Cancel
                        </button>
                      )}
                    </div>
                  </div>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      updateSupportSetting({
                        phoneNumber: supportPhone.trim(),
                        whatsappNumber: supportWhatsapp.trim(),
                        displayName: supportName.trim(),
                        availabilityDays: supportDays.trim(),
                        workingHours: supportHours.trim(),
                        email: supportEmail.trim(),
                        customMessage: supportMessage.trim(),
                        isEnabled: supportEnabled,
                      });
                      setSupportEditing(false);
                      showToast('Support configuration saved to database successfully!');
                    }}
                    className="space-y-4 text-xs"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      
                      {/* Field 1: Support Phone Number */}
                      <div>
                        <label className="font-bold text-stone-700 block mb-1">
                          1. Support Phone Number *
                        </label>
                        <input
                          type="text"
                          value={supportPhone}
                          onChange={e => setSupportPhone(e.target.value)}
                          disabled={!supportEditing}
                          placeholder="+92 333 4920199"
                          className="w-full px-3 py-2.5 border border-stone-300 rounded-xl font-mono text-stone-900 disabled:bg-stone-50 disabled:text-stone-600"
                          required
                        />
                        <span className="text-[10px] text-stone-400 mt-0.5 block">Format: +92 3XX XXXXXXX</span>
                      </div>

                      {/* Field 2: WhatsApp Support Number */}
                      <div>
                        <label className="font-bold text-stone-700 block mb-1">
                          2. WhatsApp Support Number *
                        </label>
                        <input
                          type="text"
                          value={supportWhatsapp}
                          onChange={e => setSupportWhatsapp(e.target.value)}
                          disabled={!supportEditing}
                          placeholder="923334920199"
                          className="w-full px-3 py-2.5 border border-stone-300 rounded-xl font-mono text-stone-900 disabled:bg-stone-50 disabled:text-stone-600"
                          required
                        />
                        <span className="text-[10px] text-stone-400 mt-0.5 block">Numeric country code (e.g. 923334920199)</span>
                      </div>

                      {/* Field 3: Support Display Name */}
                      <div>
                        <label className="font-bold text-stone-700 block mb-1">
                          3. Support Display Name *
                        </label>
                        <input
                          type="text"
                          value={supportName}
                          onChange={e => setSupportName(e.target.value)}
                          disabled={!supportEditing}
                          placeholder="Farming Master Operations Helpdesk"
                          className="w-full px-3 py-2.5 border border-stone-300 rounded-xl text-stone-900 disabled:bg-stone-50 disabled:text-stone-600"
                          required
                        />
                      </div>

                      {/* Field 4: Support Availability */}
                      <div>
                        <label className="font-bold text-stone-700 block mb-1">
                          4. Support Availability Days *
                        </label>
                        <input
                          type="text"
                          value={supportDays}
                          onChange={e => setSupportDays(e.target.value)}
                          disabled={!supportEditing}
                          placeholder="Monday – Saturday"
                          className="w-full px-3 py-2.5 border border-stone-300 rounded-xl text-stone-900 disabled:bg-stone-50 disabled:text-stone-600"
                          required
                        />
                      </div>

                      {/* Field 5: Support Working Hours */}
                      <div>
                        <label className="font-bold text-stone-700 block mb-1">
                          5. Support Working Hours *
                        </label>
                        <input
                          type="text"
                          value={supportHours}
                          onChange={e => setSupportHours(e.target.value)}
                          disabled={!supportEditing}
                          placeholder="09:00 AM – 08:00 PM PKT"
                          className="w-full px-3 py-2.5 border border-stone-300 rounded-xl font-mono text-stone-900 disabled:bg-stone-50 disabled:text-stone-600"
                          required
                        />
                      </div>

                      {/* Field 6: Optional Support Email */}
                      <div>
                        <label className="font-bold text-stone-700 block mb-1">
                          6. Optional Support Email
                        </label>
                        <input
                          type="email"
                          value={supportEmail}
                          onChange={e => setSupportEmail(e.target.value)}
                          disabled={!supportEditing}
                          placeholder="operations@farmingmasteregg.com"
                          className="w-full px-3 py-2.5 border border-stone-300 rounded-xl font-mono text-stone-900 disabled:bg-stone-50 disabled:text-stone-600"
                        />
                      </div>

                    </div>

                    {/* Field 7: Custom Support Message */}
                    <div>
                      <label className="font-bold text-stone-700 block mb-1">
                        7. Custom Support Message
                      </label>
                      <textarea
                        rows={3}
                        value={supportMessage}
                        onChange={e => setSupportMessage(e.target.value)}
                        disabled={!supportEditing}
                        placeholder="Explain support response protocols, visit booking, or operational assistance details."
                        className="w-full px-3 py-2.5 border border-stone-300 rounded-xl text-stone-900 disabled:bg-stone-50 disabled:text-stone-600 leading-relaxed"
                      />
                    </div>

                    {/* Buttons Row */}
                    <div className="pt-2 flex items-center justify-between border-t border-stone-100">
                      <div className="text-[11px] text-stone-400">
                        Last updated: <span className="font-mono">{supportSetting.updatedAt}</span>
                      </div>

                      <div className="flex items-center gap-3">
                        {supportEditing && (
                          <button
                            type="submit"
                            className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl text-xs shadow-xs transition-colors cursor-pointer"
                          >
                            Save Settings
                          </button>
                        )}
                      </div>
                    </div>
                  </form>
                </div>

                {/* Live Customer Preview Card (1 Col) */}
                <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500">
                      Live Customer Preview
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${supportEnabled ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                      {supportEnabled ? 'Active' : 'Offline'}
                    </span>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-stone-200 space-y-3 text-xs shadow-xs">
                    <div className="font-bold text-emerald-950 font-display text-sm">
                      {supportName || 'Farm Customer Support'}
                    </div>

                    {!supportEnabled ? (
                      <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200 text-amber-900 text-[11px]">
                        Support currently offline. Working hours: {supportHours}
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="p-2 bg-emerald-50 rounded-lg text-emerald-950 font-mono font-bold flex items-center justify-between text-xs">
                          <span>Phone:</span>
                          <span>{supportPhone}</span>
                        </div>
                        <div className="p-2 bg-emerald-50 rounded-lg text-emerald-950 font-mono font-bold flex items-center justify-between text-xs">
                          <span>WhatsApp:</span>
                          <span>{supportWhatsapp}</span>
                        </div>
                        <div className="text-[11px] text-stone-600">
                          <div><strong>Hours:</strong> {supportHours}</div>
                          <div><strong>Days:</strong> {supportDays}</div>
                          {supportEmail && <div><strong>Email:</strong> {supportEmail}</div>}
                        </div>
                      </div>
                    )}

                    {supportMessage && (
                      <p className="text-[11px] text-stone-500 italic pt-1 border-t border-stone-100">
                        "{supportMessage}"
                      </p>
                    )}
                  </div>

                  <p className="text-[11px] text-stone-500 leading-relaxed">
                    Changes saved here instantly update the customer dashboard "Support" button and modal without redeploying code.
                  </p>
                </div>

              </div>
            </div>
          )}

          {/* 11. FARM VISITS & APPOINTMENTS (SUPABASE BACKEND) */}
          {adminSection === 'appointments' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-200 gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold font-display text-emerald-950">11. Farm Visits & Appointment Requests</h2>
                    <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full uppercase">
                      Supabase Backend
                    </span>
                  </div>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Live appointment bookings submitted by customers and visitors, synchronized with Supabase project <span className="font-mono text-emerald-800 font-semibold">{SUPABASE_PROJECT_ID}</span>.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={refreshAppointments}
                    disabled={loadingAppointments}
                    className="px-3.5 py-2 bg-white hover:bg-stone-50 border border-stone-300 text-stone-800 rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loadingAppointments ? 'animate-spin text-emerald-700' : ''}`} />
                    <span>{loadingAppointments ? 'Syncing...' : 'Refresh from Supabase'}</span>
                  </button>

                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(SUPABASE_APPOINTMENTS_SQL);
                      setCopiedAdminSql(true);
                      setTimeout(() => setCopiedAdminSql(false), 2500);
                    }}
                    className="px-3.5 py-2 bg-emerald-900 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    {copiedAdminSql ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedAdminSql ? 'SQL Copied!' : 'Copy Supabase SQL'}</span>
                  </button>
                </div>
              </div>

              {/* Supabase Connection Banner */}
              <div className="p-4 bg-white rounded-xl border border-stone-200 shadow-2xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-900 flex items-center justify-center shrink-0">
                    <Database className="w-5 h-5 text-emerald-800" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <strong className="text-xs text-stone-900 font-bold">Supabase PostgreSQL Backend:</strong>
                      <span className="font-mono text-xs text-emerald-800 font-bold">{SUPABASE_PROJECT_ID}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        isLiveSupabase 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {isLiveSupabase ? '● Live Supabase Cloud' : '● Local Queue & Registry'}
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-500 mt-0.5">
                      Endpoint: <code className="font-mono">{SUPABASE_DEFAULT_URL}</code> • Table: <code className="font-mono text-emerald-800">public.appointments</code>
                    </p>
                  </div>
                </div>

                <div className="text-[11px] text-stone-600 bg-stone-50 px-3 py-1.5 rounded-lg border border-stone-200/80">
                  <span className="font-semibold text-stone-700">Health: </span>
                  <span>{supabaseHealthMsg}</span>
                </div>
              </div>

              {/* KPI Summary Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs">
                  <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">Total Bookings</span>
                  <div className="text-2xl font-bold font-mono text-stone-900 mt-1">{appointmentsList.length}</div>
                  <span className="text-[10px] text-stone-500">Across all visiting dates</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-amber-200 bg-amber-50/20 shadow-xs">
                  <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider block">Pending Review</span>
                  <div className="text-2xl font-bold font-mono text-amber-700 mt-1">
                    {appointmentsList.filter(a => a.status === 'pending').length}
                  </div>
                  <span className="text-[10px] text-amber-800">Biosecurity clearance required</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-emerald-200 bg-emerald-50/20 shadow-xs">
                  <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">Confirmed Passes</span>
                  <div className="text-2xl font-bold font-mono text-emerald-800 mt-1">
                    {appointmentsList.filter(a => a.status === 'confirmed').length}
                  </div>
                  <span className="text-[10px] text-emerald-700">Gate passes issued</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs">
                  <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">Visitors Expected</span>
                  <div className="text-2xl font-bold font-mono text-stone-900 mt-1">
                    {appointmentsList.reduce((acc, a) => acc + (a.visitor_count || 1), 0)}
                  </div>
                  <span className="text-[10px] text-stone-500">Total physical persons</span>
                </div>
              </div>

              {/* Collapsible Supabase SQL Setup Script for the table */}
              <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-emerald-800" />
                    <h3 className="font-bold text-xs text-stone-900 font-display">
                      Supabase Table Schema: <code className="font-mono text-emerald-800">public.appointments</code>
                    </h3>
                  </div>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(SUPABASE_APPOINTMENTS_SQL);
                      setCopiedAdminSql(true);
                      setTimeout(() => setCopiedAdminSql(false), 2500);
                    }}
                    className="text-xs text-emerald-800 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    {copiedAdminSql ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedAdminSql ? 'Copied!' : 'Copy SQL Script'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-stone-500 leading-relaxed">
                  Run this SQL in your Supabase project dashboard (Project ID: <strong className="font-mono text-stone-900">{SUPABASE_PROJECT_ID}</strong>) under <strong>SQL Editor</strong> to configure table columns and public insert policies.
                </p>
                <pre className="p-3 bg-stone-900 text-emerald-400 font-mono text-[10px] rounded-lg overflow-x-auto max-h-32">
                  {SUPABASE_APPOINTMENTS_SQL}
                </pre>
              </div>

              {/* Appointments Records List Table */}
              <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden">
                <div className="px-5 py-3 border-b border-stone-200 bg-stone-50 flex items-center justify-between">
                  <h3 className="font-bold text-xs text-stone-900 font-display">
                    Farm Appointment Bookings ({appointmentsList.length})
                  </h3>
                  <span className="text-[11px] text-stone-500">
                    Auto-refreshed from Supabase & local registry
                  </span>
                </div>

                {appointmentsList.length === 0 ? (
                  <div className="p-12 text-center space-y-3">
                    <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-800 mx-auto">
                      <Calendar className="w-6 h-6" />
                    </div>
                    <h4 className="font-bold text-sm text-stone-900">No Appointments Recorded Yet</h4>
                    <p className="text-xs text-stone-500 max-w-md mx-auto">
                      When customers or prospective hen owners submit the visit request form on the public "Contact & Visit" page, their details will appear here in real-time.
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-stone-50 text-stone-600 border-b border-stone-200">
                        <tr>
                          <th className="py-2.5 px-4 font-semibold">Visitor & Contact</th>
                          <th className="py-2.5 px-4 font-semibold">Preferred Date</th>
                          <th className="py-2.5 px-4 font-semibold">Visitors</th>
                          <th className="py-2.5 px-4 font-semibold">Notes / Purpose</th>
                          <th className="py-2.5 px-4 font-semibold">Status</th>
                          <th className="py-2.5 px-4 font-semibold">Backend Sync</th>
                          <th className="py-2.5 px-4 font-semibold text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {appointmentsList.map(apt => (
                          <tr key={apt.id} className="hover:bg-stone-50/70">
                            <td className="py-3 px-4">
                              <div className="font-bold text-stone-900">{apt.full_name}</div>
                              <div className="flex items-center gap-2 mt-0.5">
                                <span className="font-mono text-stone-600 text-[11px]">{apt.phone_number}</span>
                                <a
                                  href={`https://wa.me/${apt.phone_number.replace(/[^0-9]/g, '')}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-[10px] text-emerald-700 hover:text-emerald-900 font-semibold underline"
                                >
                                  WhatsApp
                                </a>
                              </div>
                              {apt.email && (
                                <div className="text-[10px] text-stone-400">{apt.email}</div>
                              )}
                            </td>
                            <td className="py-3 px-4">
                              <span className="font-medium text-stone-900">{apt.visit_date}</span>
                              <span className="block text-[10px] text-stone-400">
                                {new Date(apt.created_at).toLocaleDateString()}
                              </span>
                            </td>
                            <td className="py-3 px-4">
                              <span className="inline-flex items-center px-2 py-0.5 bg-stone-100 rounded text-stone-800 font-semibold font-mono text-xs">
                                {apt.visitor_count} person(s)
                              </span>
                            </td>
                            <td className="py-3 px-4 max-w-xs text-stone-600 text-[11px]">
                              {apt.notes ? apt.notes : <span className="text-stone-300 italic">Standard flock inspection</span>}
                            </td>
                            <td className="py-3 px-4">
                              <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold capitalize ${
                                apt.status === 'confirmed'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : apt.status === 'completed'
                                  ? 'bg-blue-100 text-blue-800'
                                  : apt.status === 'cancelled'
                                  ? 'bg-red-100 text-red-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}>
                                {apt.status}
                              </span>
                            </td>
                            <td className="py-3 px-4">
                              {apt.synced_to_supabase ? (
                                <span className="inline-flex items-center gap-1 text-[10px] text-emerald-700 font-medium">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                  Supabase Synced
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-[10px] text-stone-500 font-medium">
                                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                                  Queued locally
                                </span>
                              )}
                            </td>
                            <td className="py-3 px-4 text-right space-x-1">
                              {apt.status === 'pending' && (
                                <button
                                  onClick={() => updateAppointmentStatus(apt.id, 'confirmed')}
                                  className="px-2.5 py-1 bg-emerald-800 hover:bg-emerald-900 text-white rounded text-[10px] font-bold cursor-pointer"
                                  title="Approve biosecurity clearance & issue gate pass"
                                >
                                  Approve Pass
                                </button>
                              )}
                              {apt.status === 'confirmed' && (
                                <button
                                  onClick={() => updateAppointmentStatus(apt.id, 'completed')}
                                  className="px-2.5 py-1 bg-blue-800 hover:bg-blue-900 text-white rounded text-[10px] font-bold cursor-pointer"
                                  title="Mark visit concluded"
                                >
                                  Concluded
                                </button>
                              )}
                              {apt.status !== 'cancelled' && (
                                <button
                                  onClick={() => updateAppointmentStatus(apt.id, 'cancelled')}
                                  className="px-2 py-1 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded text-[10px] cursor-pointer"
                                  title="Cancel appointment"
                                >
                                  Cancel
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 12. EGG PRODUCTION */}
          {adminSection === 'production' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <h2 className="text-xl font-bold font-display text-emerald-950">8. Egg Production Sweeps</h2>
              </div>

              {/* Record Form */}
              <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-xs space-y-4">
                <h3 className="font-bold text-sm text-emerald-950 font-display">Record Daily Egg Collection</h3>
                <form onSubmit={handleRecordProductionSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Collection Date</label>
                    <input
                      type="date"
                      value={prodDate}
                      onChange={e => setProdDate(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                      required
                    />
                  </div>

                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Farm Shed</label>
                    <select
                      value={prodShedId}
                      onChange={e => setProdShedId(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                    >
                      {sheds.map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Total Eggs Collected</label>
                    <input
                      type="number"
                      value={prodCollected}
                      onChange={e => setProdCollected(parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg font-mono text-stone-900"
                      required
                    />
                  </div>

                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Damaged / Broken</label>
                    <input
                      type="number"
                      value={prodDamaged}
                      onChange={e => setProdDamaged(parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg font-mono text-stone-900"
                      required
                    />
                  </div>

                  <div className="lg:col-span-3">
                    <label className="font-medium text-stone-700 block mb-1">Observations / Notes</label>
                    <input
                      type="text"
                      value={prodNotes}
                      onChange={e => setProdNotes(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                    />
                  </div>

                  <div className="flex items-end">
                    <button
                      type="submit"
                      className="w-full py-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-lg text-xs"
                    >
                      Log Production Record
                    </button>
                  </div>
                </form>
              </div>

              {/* Production Table */}
              <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden">
                <div className="p-3.5 bg-stone-50 border-b border-stone-200 text-xs font-semibold text-stone-700">
                  Recorded Egg Collection Entries ({productionRecords.length})
                </div>
                {productionRecords.length === 0 ? (
                  <div className="py-8 text-center text-xs text-stone-500">No egg collection entries logged yet.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                          <th className="p-3">Date</th>
                          <th className="p-3">Shed</th>
                          <th className="p-3">Flock</th>
                          <th className="p-3">Collected</th>
                          <th className="p-3">Damaged</th>
                          <th className="p-3">Net Saleable</th>
                          <th className="p-3">Laying Rate</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {productionRecords.map(r => (
                          <tr key={r.id}>
                            <td className="p-3 font-sans font-medium text-emerald-950">{r.date}</td>
                            <td className="p-3 font-sans text-stone-800">{r.shedName.split('-')[0]}</td>
                            <td className="p-3 text-stone-600">{r.flockSize}</td>
                            <td className="p-3 font-bold text-emerald-950">{r.eggsCollected}</td>
                            <td className="p-3 text-amber-700">{r.eggsDamaged}</td>
                            <td className="p-3 font-semibold text-emerald-900">{r.eggsAvailableForSale}</td>
                            <td className="p-3 text-stone-800">{r.layingPercentage}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 14. WHOLESALE EGG MANDIS & CUSTOMER SELLING ORDERS (Supabase Tables F & G) */}
          {adminSection === 'egg-markets' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-200 gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-300 font-mono">
                      Supabase Realtime Tables: egg_markets & egg_selling_orders
                    </span>
                  </div>
                  <h2 className="text-xl font-bold font-display text-emerald-950 mt-1">
                    14. Wholesale Egg Mandis & Customer Selling Orders
                  </h2>
                  <p className="text-xs text-stone-500">
                    Live market rates (PKR 40 - 60), daily buyer intake capacity, customer egg liquidation, and direct wallet payouts.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(SUPABASE_SCHEMA_SQL);
                      showToast('Copied full 13-Table Supabase SQL to clipboard!');
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-semibold shadow-xs cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Supabase SQL</span>
                  </button>
                </div>
              </div>

              {/* Quick Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-[11px] font-bold text-stone-500 uppercase">Wholesale Mandis</span>
                  <div className="text-2xl font-bold font-mono text-emerald-950">{eggMarkets.length}</div>
                  <span className="text-[10px] text-stone-400">Green Nest, Sultan, Golden</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-[11px] font-bold text-stone-500 uppercase">Total Eggs Sold</span>
                  <div className="text-2xl font-bold font-mono text-amber-700">
                    {eggSellingOrders.reduce((acc, o) => acc + o.eggQuantity, 0).toLocaleString()}
                  </div>
                  <span className="text-[10px] text-stone-400">Allocated eggs liquidated</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-[11px] font-bold text-stone-500 uppercase">Pending Payouts</span>
                  <div className="text-2xl font-bold font-mono text-rose-700">
                    Rs. {eggSellingOrders.filter(o => o.orderStatus === 'pending').reduce((acc, o) => acc + o.totalAmount, 0).toLocaleString()}
                  </div>
                  <span className="text-[10px] text-rose-600 font-medium">
                    {eggSellingOrders.filter(o => o.orderStatus === 'pending').length} orders awaiting review
                  </span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-[11px] font-bold text-stone-500 uppercase">Paid to Customers</span>
                  <div className="text-2xl font-bold font-mono text-emerald-700">
                    Rs. {eggSellingOrders.filter(o => o.orderStatus === 'paid').reduce((acc, o) => acc + o.totalAmount, 0).toLocaleString()}
                  </div>
                  <span className="text-[10px] text-emerald-600 font-medium">Successfully processed</span>
                </div>
              </div>

              {/* Three Wholesale Mandis Cards (Live Configuration) */}
              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                  <div>
                    <h3 className="font-bold text-base text-emerald-950 font-display">
                      Wholesale Market Pricing & Intake Capacities (Table: egg_markets)
                    </h3>
                    <p className="text-xs text-stone-500">
                      Configure rates per egg, minimum/maximum order thresholds, daily mandi quotas, and clearance speed.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  {eggMarkets.map((market) => (
                    <div
                      key={market.id}
                      className={`rounded-2xl border p-5 space-y-4 transition-all ${
                        editingMarketId === market.id 
                          ? 'border-emerald-600 bg-emerald-50/40 ring-2 ring-emerald-600/20' 
                          : 'border-stone-200 bg-stone-50/50 hover:border-stone-300'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className={`w-2 h-2 rounded-full ${market.isActive ? 'bg-emerald-500' : 'bg-stone-300'}`} />
                            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                              {market.isActive ? 'Open for Selling' : 'Intake Closed'}
                            </span>
                          </div>
                          <h4 className="text-base font-bold text-emerald-950 font-display mt-1">{market.marketName}</h4>
                        </div>
                        <div className="text-right">
                          <span className="text-xl font-bold font-mono text-emerald-950">
                            Rs. {market.pricePerEgg}
                          </span>
                          <span className="text-[10px] text-stone-500 block">/ fresh egg</span>
                        </div>
                      </div>

                      {editingMarketId === market.id ? (
                        <div className="space-y-3 pt-2 border-t border-emerald-200 text-xs">
                          <div>
                            <label className="text-[11px] font-bold text-emerald-950 block mb-1">
                              Price Per Egg (PKR)
                            </label>
                            <input
                              type="number"
                              value={marketEditPrice}
                              onChange={e => setMarketEditPrice(Number(e.target.value))}
                              className="w-full px-3 py-1.5 bg-white border border-emerald-300 rounded-lg text-xs font-mono font-bold text-emerald-950"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="text-[11px] font-semibold text-stone-600 block mb-1">Min Eggs</label>
                              <input
                                type="number"
                                value={marketEditMin}
                                onChange={e => setMarketEditMin(Number(e.target.value))}
                                className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-mono"
                              />
                            </div>
                            <div>
                              <label className="text-[11px] font-semibold text-stone-600 block mb-1">Max Eggs</label>
                              <input
                                type="number"
                                value={marketEditMax}
                                onChange={e => setMarketEditMax(Number(e.target.value))}
                                className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-mono"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="text-[11px] font-semibold text-stone-600 block mb-1">Quota Capacity</label>
                              <input
                                type="number"
                                value={marketEditCapacity}
                                onChange={e => setMarketEditCapacity(Number(e.target.value))}
                                className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-mono"
                              />
                            </div>
                            <div>
                              <label className="text-[11px] font-semibold text-stone-600 block mb-1">Clearance Time</label>
                              <input
                                type="text"
                                value={marketEditTime}
                                onChange={e => setMarketEditTime(e.target.value)}
                                className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs"
                              />
                            </div>
                          </div>

                          <div className="flex items-center gap-2 pt-2">
                            <button
                              onClick={async () => {
                                await updateEggMarket(market.id, {
                                  pricePerEgg: marketEditPrice,
                                  minimumQuantity: marketEditMin,
                                  maximumQuantity: marketEditMax,
                                  availableCapacity: marketEditCapacity,
                                  processingTime: marketEditTime
                                });
                                setEditingMarketId(null);
                                showToast(`Updated ${market.marketName} parameters in Supabase.`);
                              }}
                              className="flex-1 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg font-bold text-xs shadow-xs"
                            >
                              Save Changes
                            </button>
                            <button
                              onClick={() => setEditingMarketId(null)}
                              className="px-3 py-1.5 bg-stone-200 hover:bg-stone-300 text-stone-700 rounded-lg font-medium text-xs"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="space-y-2 text-xs pt-2 border-t border-stone-200">
                            <div className="flex justify-between text-stone-600">
                              <span>Lot Range:</span>
                              <span className="font-mono font-semibold text-stone-900">
                                {market.minimumQuantity} - {market.maximumQuantity} eggs
                              </span>
                            </div>
                            <div className="flex justify-between text-stone-600">
                              <span>Intake Capacity:</span>
                              <span className="font-mono font-semibold text-stone-900">
                                {market.availableCapacity.toLocaleString()} eggs
                              </span>
                            </div>
                            <div className="flex justify-between text-stone-600">
                              <span>Clearance Time:</span>
                              <span className="font-semibold text-emerald-900">{market.processingTime}</span>
                            </div>
                          </div>

                          <div className="pt-2 flex items-center gap-2">
                            <button
                              onClick={() => {
                                setEditingMarketId(market.id);
                                setMarketEditPrice(market.pricePerEgg);
                                setMarketEditMin(market.minimumQuantity);
                                setMarketEditMax(market.maximumQuantity);
                                setMarketEditCapacity(market.availableCapacity);
                                setMarketEditTime(market.processingTime);
                              }}
                              className="flex-1 py-2 bg-white hover:bg-stone-100 text-emerald-900 border border-stone-300 rounded-xl font-bold text-xs transition-colors cursor-pointer"
                            >
                              Edit Rate & Capacity
                            </button>
                            <button
                              onClick={async () => {
                                await updateEggMarket(market.id, { isActive: !market.isActive });
                                showToast(`${market.marketName} ${!market.isActive ? 'enabled' : 'disabled'}.`);
                              }}
                              className={`px-3 py-2 text-xs font-semibold rounded-xl border transition-colors cursor-pointer ${
                                market.isActive 
                                  ? 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100' 
                                  : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                              }`}
                            >
                              {market.isActive ? 'Pause' : 'Enable'}
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Customer Egg Selling Orders Ledger (Table: egg_selling_orders) */}
              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-100 gap-3">
                  <div>
                    <h3 className="font-bold text-base text-emerald-950 font-display">
                      Customer Egg Selling Orders (Table: egg_selling_orders)
                    </h3>
                    <p className="text-xs text-stone-500">
                      Liquidated egg orders from customer flocks awaiting bank/wallet payout settlement.
                    </p>
                  </div>

                  {/* Filter Tabs */}
                  <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-xl text-xs font-medium">
                    {(['all', 'pending', 'paid', 'rejected'] as const).map(f => (
                      <button
                        key={f}
                        onClick={() => setOrderFilter(f)}
                        className={`px-3 py-1.5 rounded-lg capitalize transition-colors cursor-pointer ${
                          orderFilter === f 
                            ? 'bg-white text-emerald-950 font-bold shadow-xs' 
                            : 'text-stone-600 hover:text-stone-900'
                        }`}
                      >
                        {f} ({
                          f === 'all' 
                            ? eggSellingOrders.length 
                            : eggSellingOrders.filter(o => o.orderStatus === f).length
                        })
                      </button>
                    ))}
                  </div>
                </div>

                {eggSellingOrders.filter(o => orderFilter === 'all' ? true : o.orderStatus === orderFilter).length === 0 ? (
                  <div className="p-8 text-center text-xs text-stone-500">
                    No egg selling orders found matching filter "{orderFilter}".
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-stone-200 text-stone-500 uppercase tracking-wider font-semibold text-[11px]">
                          <th className="p-3">Order ID & Date</th>
                          <th className="p-3">Customer</th>
                          <th className="p-3">Wholesale Mandi</th>
                          <th className="p-3 text-right">Eggs Sold</th>
                          <th className="p-3 text-right">Mandi Rate</th>
                          <th className="p-3 text-right">Total Payout</th>
                          <th className="p-3">Payout Account</th>
                          <th className="p-3">Status</th>
                          <th className="p-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {eggSellingOrders
                          .filter(o => orderFilter === 'all' ? true : o.orderStatus === orderFilter)
                          .map((order) => {
                            const market = eggMarkets.find(m => m.id === order.marketId);
                            const customer = customers.find(c => c.id === order.userId);
                            const isPending = order.orderStatus === 'pending';

                            return (
                              <tr key={order.id} className="hover:bg-stone-50 transition-colors">
                                <td className="p-3 font-mono">
                                  <div className="font-bold text-emerald-950">{order.id}</div>
                                  <div className="text-[10px] text-stone-400">
                                    {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'Today'}
                                  </div>
                                </td>
                                <td className="p-3">
                                  <div className="font-semibold text-stone-900">{customer?.name || order.accountHolderName}</div>
                                  <div className="text-[10px] text-stone-400 font-mono">{order.userId}</div>
                                </td>
                                <td className="p-3 font-medium text-stone-800">
                                  {market?.marketName || order.marketId}
                                </td>
                                <td className="p-3 text-right font-mono font-bold text-amber-700">
                                  {order.eggQuantity.toLocaleString()}
                                </td>
                                <td className="p-3 text-right font-mono text-stone-600">
                                  Rs. {order.pricePerEgg}
                                </td>
                                <td className="p-3 text-right font-mono font-bold text-emerald-950">
                                  Rs. {order.totalAmount.toLocaleString()}
                                </td>
                                <td className="p-3">
                                  <div className="font-semibold text-stone-900 flex items-center gap-1.5">
                                    <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-stone-100 border border-stone-200 text-stone-700 uppercase">
                                      {order.payoutMethod}
                                    </span>
                                    <span>{order.accountHolderName}</span>
                                  </div>
                                  <div className="text-[11px] font-mono text-stone-500">
                                    {order.accountNumber || order.walletNumber}
                                    {order.bankName && <span className="ml-1 text-stone-400">({order.bankName})</span>}
                                  </div>
                                </td>
                                <td className="p-3">
                                  <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                                    order.orderStatus === 'paid'
                                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                      : order.orderStatus === 'pending'
                                      ? 'bg-amber-100 text-amber-800 border border-amber-200 animate-pulse'
                                      : 'bg-rose-100 text-rose-800 border border-rose-200'
                                  }`}>
                                    {order.orderStatus}
                                  </span>
                                  {order.txReference && (
                                    <div className="text-[10px] text-stone-400 font-mono mt-0.5">
                                      Ref: {order.txReference}
                                    </div>
                                  )}
                                </td>
                                <td className="p-3 text-right">
                                  {isPending ? (
                                    <div className="flex items-center justify-end gap-1.5">
                                      <button
                                        onClick={() => {
                                          setOrderProcessingId(order.id);
                                          setOrderPayoutRef(`TR-${Math.floor(100000 + Math.random() * 900000)}`);
                                        }}
                                        className="px-2.5 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-bold transition-colors shadow-xs cursor-pointer"
                                      >
                                        Mark Paid
                                      </button>
                                      <button
                                        onClick={() => {
                                          setOrderRejectionModalId(order.id);
                                        }}
                                        className="px-2 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                                      >
                                        Reject
                                      </button>
                                    </div>
                                  ) : (
                                    <span className="text-stone-400 text-[11px]">
                                      {order.orderStatus === 'paid' ? 'Paid & Audited' : 'Refunded'}
                                    </span>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Approval Modal */}
              {orderProcessingId && (
                <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
                  <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4 text-xs">
                    <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                      <h4 className="font-bold text-base text-emerald-950 font-display">
                        Confirm Egg Mandi Payout
                      </h4>
                      <button
                        onClick={() => setOrderProcessingId(null)}
                        className="text-stone-400 hover:text-stone-600 text-lg font-bold"
                      >
                        ✕
                      </button>
                    </div>

                    <p className="text-stone-600 leading-relaxed">
                      Enter the bank wire or mobile wallet transaction reference after transmitting funds to the customer. This will update the Supabase record to <strong>completed</strong>.
                    </p>

                    <div>
                      <label className="font-bold text-stone-700 block mb-1">
                        Bank / Mobile Wallet Reference (TID / UTR) *
                      </label>
                      <input
                        type="text"
                        value={orderPayoutRef}
                        onChange={e => setOrderPayoutRef(e.target.value)}
                        placeholder="e.g. EP-9823471 or FT-PK-98124"
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-900"
                        autoFocus
                      />
                    </div>

                    <div className="flex items-center gap-2 pt-2">
                      <button
                        onClick={async () => {
                          if (!orderPayoutRef.trim()) {
                            alert('Please enter a valid payout transaction reference.');
                            return;
                          }
                          await processEggSellingOrder(orderProcessingId, 'paid', orderPayoutRef.trim());
                          showToast(`Order ${orderProcessingId} marked as completed and paid.`);
                          setOrderProcessingId(null);
                          setOrderPayoutRef('');
                        }}
                        className="flex-1 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl font-bold text-xs shadow-xs cursor-pointer"
                      >
                        Confirm & Complete Payout
                      </button>
                      <button
                        onClick={() => setOrderProcessingId(null)}
                        className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-semibold text-xs cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Rejection Modal */}
              {orderRejectionModalId && (
                <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
                  <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4 text-xs">
                    <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                      <h4 className="font-bold text-base text-rose-900 font-display">
                        Reject Egg Selling Order & Refund Eggs
                      </h4>
                      <button
                        onClick={() => setOrderRejectionModalId(null)}
                        className="text-stone-400 hover:text-stone-600 text-lg font-bold"
                      >
                        ✕
                      </button>
                    </div>

                    <p className="text-stone-600 leading-relaxed">
                      Rejecting this order will return the reserved eggs back to the customer's available egg balance and mark the record as <strong>rejected</strong> in Supabase.
                    </p>

                    <div>
                      <label className="font-bold text-stone-700 block mb-1">
                        Reason for Rejection *
                      </label>
                      <input
                        type="text"
                        value={rejectionReasonInput}
                        onChange={e => setRejectionReasonInput(e.target.value)}
                        placeholder="e.g. Daily intake quota reached, invalid account info"
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900"
                      />
                    </div>

                    <div className="flex items-center gap-2 pt-2">
                      <button
                        onClick={async () => {
                          await processEggSellingOrder(orderRejectionModalId, 'rejected', rejectionReasonInput.trim());
                          showToast(`Order ${orderRejectionModalId} rejected and eggs refunded.`);
                          setOrderRejectionModalId(null);
                        }}
                        className="flex-1 py-2.5 bg-rose-700 hover:bg-rose-800 text-white rounded-xl font-bold text-xs shadow-xs cursor-pointer"
                      >
                        Reject & Refund Eggs
                      </button>
                      <button
                        onClick={() => setOrderRejectionModalId(null)}
                        className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-semibold text-xs cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

          {/* 9. EGG SALES */}
          {adminSection === 'sales' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <h2 className="text-xl font-bold font-display text-emerald-950">9. Egg Wholesale Sales</h2>
              </div>

              <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-xs space-y-4">
                <h3 className="font-bold text-sm text-emerald-950 font-display">Record Wholesale Mandi Sale</h3>
                <form onSubmit={handleRecordEggSaleSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Date</label>
                    <input
                      type="date"
                      value={saleDate}
                      onChange={e => setSaleDate(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                      required
                    />
                  </div>
                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Quantity (Eggs)</label>
                    <input
                      type="number"
                      value={saleQty}
                      onChange={e => setSaleQty(parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg font-mono text-stone-900"
                      required
                    />
                  </div>
                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Rate / Egg (Rs.)</label>
                    <input
                      type="number"
                      step="0.05"
                      value={saleRate}
                      onChange={e => setSaleRate(parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg font-mono text-stone-900"
                      required
                    />
                  </div>
                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Buyer / Mandi Trader</label>
                    <input
                      type="text"
                      value={saleBuyer}
                      onChange={e => setSaleBuyer(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                      required
                    />
                  </div>
                  <div className="flex items-end">
                    <button
                      type="submit"
                      className="w-full py-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-lg text-xs"
                    >
                      Log Sale
                    </button>
                  </div>
                </form>
              </div>

              <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden">
                <div className="p-3.5 bg-stone-50 border-b border-stone-200 text-xs font-semibold text-stone-700">
                  Sales Ledger ({eggSales.length})
                </div>
                {eggSales.length === 0 ? (
                  <div className="py-8 text-center text-xs text-stone-500">No egg sales records logged yet.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                          <th className="p-3">Invoice</th>
                          <th className="p-3">Date</th>
                          <th className="p-3">Quantity</th>
                          <th className="p-3">Rate</th>
                          <th className="p-3">Gross Revenue</th>
                          <th className="p-3">Buyer</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {eggSales.map(s => (
                          <tr key={s.id}>
                            <td className="p-3 font-bold text-emerald-950">{s.invoiceNumber}</td>
                            <td className="p-3 font-sans text-stone-700">{s.date}</td>
                            <td className="p-3 text-stone-900">{s.quantityEggs.toLocaleString()}</td>
                            <td className="p-3 text-stone-800">Rs. {s.ratePerEgg}</td>
                            <td className="p-3 font-bold text-emerald-900">Rs. {s.grossAmount.toLocaleString()}</td>
                            <td className="p-3 font-sans text-stone-800">{s.buyerName}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 10. FARM EXPENSES */}
          {adminSection === 'expenses' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <h2 className="text-xl font-bold font-display text-emerald-950">10. Farm Operating Expenses</h2>
              </div>

              <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-xs space-y-4">
                <h3 className="font-bold text-sm text-emerald-950 font-display">Log Farm Expense</h3>
                <form onSubmit={handleRecordExpenseSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Date</label>
                    <input
                      type="date"
                      value={expDate}
                      onChange={e => setExpDate(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                      required
                    />
                  </div>
                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Category</label>
                    <select
                      value={expCat}
                      onChange={e => setExpCat(e.target.value as ExpenseCategory)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                    >
                      <option value="feed">Layer Feed</option>
                      <option value="veterinary">Veterinary / Vaccines</option>
                      <option value="labour">Farm Hands Labour</option>
                      <option value="electricity">Electricity / Solar</option>
                      <option value="maintenance">Maintenance</option>
                      <option value="transport">Transport</option>
                    </select>
                  </div>
                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Amount (Rs.)</label>
                    <input
                      type="number"
                      value={expAmount}
                      onChange={e => setExpAmount(parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg font-mono text-stone-900"
                      required
                    />
                  </div>
                  <div>
                    <label className="font-medium text-stone-700 block mb-1">Description</label>
                    <input
                      type="text"
                      value={expDesc}
                      onChange={e => setExpDesc(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg text-stone-900"
                      required
                    />
                  </div>
                  <div className="flex items-end">
                    <button
                      type="submit"
                      className="w-full py-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-lg text-xs"
                    >
                      Record Expense
                    </button>
                  </div>
                </form>
              </div>

              <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden">
                <div className="p-3.5 bg-stone-50 border-b border-stone-200 text-xs font-semibold text-stone-700">
                  Documented Vouchers ({expenses.length})
                </div>
                {expenses.length === 0 ? (
                  <div className="py-8 text-center text-xs text-stone-500">No expenses logged yet.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                          <th className="p-3">Voucher</th>
                          <th className="p-3">Date</th>
                          <th className="p-3">Category</th>
                          <th className="p-3">Amount</th>
                          <th className="p-3">Description</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {expenses.map(e => (
                          <tr key={e.id}>
                            <td className="p-3 font-bold text-emerald-950">{e.voucherNumber}</td>
                            <td className="p-3 font-sans text-stone-700">{e.date}</td>
                            <td className="p-3 font-sans uppercase text-[11px] font-semibold text-emerald-800">{e.category}</td>
                            <td className="p-3 font-bold text-red-700">Rs. {e.amount.toLocaleString()}</td>
                            <td className="p-3 font-sans text-stone-800">{e.description}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 11. CUSTOMER STATEMENTS */}
          {adminSection === 'statements' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <h2 className="text-xl font-bold font-display text-emerald-950">11. Customer Financial Statements</h2>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={allocPeriod}
                    onChange={e => setAllocPeriod(e.target.value)}
                    className="px-3 py-1.5 border border-stone-200 rounded-lg text-xs font-mono"
                  />
                  <button
                    onClick={() => {
                      runMonthlyAllocation(allocPeriod);
                      showToast(`Ran allocation cycle for ${allocPeriod}.`);
                    }}
                    className="flex items-center gap-1 px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-bold shadow-xs"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Run & Publish Cycle</span>
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden">
                <div className="p-3.5 bg-stone-50 border-b border-stone-200 text-xs font-semibold text-stone-700">
                  Published Statements ({customerStatements.length})
                </div>
                {customerStatements.length === 0 ? (
                  <div className="py-8 text-center text-xs text-stone-500">No monthly statements published yet.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                          <th className="p-3">Period</th>
                          <th className="p-3">Customer</th>
                          <th className="p-3">Hens</th>
                          <th className="p-3">Gross Share</th>
                          <th className="p-3">Operating Exp</th>
                          <th className="p-3">Net Credited</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {customerStatements.map(s => (
                          <tr key={s.id}>
                            <td className="p-3 font-sans font-bold text-emerald-950">{s.cyclePeriod}</td>
                            <td className="p-3 font-sans text-stone-900">{s.customerName}</td>
                            <td className="p-3 text-stone-700">{s.hensOwned} birds</td>
                            <td className="p-3 text-emerald-900">Rs. {s.grossRevenueShare.toFixed(2)}</td>
                            <td className="p-3 text-red-700">-Rs. {s.operatingExpenseShare.toFixed(2)}</td>
                            <td className="p-3 font-bold text-emerald-950">Rs. {s.netPayableAmount.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 8. WITHDRAWAL MANAGEMENT */}
          {adminSection === 'withdrawals' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-200 gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                      <Database className="w-3 h-3 text-emerald-700" /> Supabase: {SUPABASE_PROJECT_ID}
                    </span>
                    <span className="text-[10px] font-mono text-stone-500">public.withdrawals</span>
                  </div>
                  <h2 className="text-xl font-bold font-display text-emerald-950">8. Customer Withdrawal Management</h2>
                  <p className="text-xs text-stone-500">Review payout requests, verify account titles, and mark completed payments as Paid.</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(SUPABASE_DEPOSITS_WITHDRAWALS_SQL);
                      showToast('Copied Supabase Deposits & Withdrawals SQL to clipboard!');
                    }}
                    className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5 text-stone-600" />
                    <span>Copy Supabase SQL</span>
                  </button>
                  <button
                    onClick={() => setAdminSection('withdrawal-settings')}
                    className="px-3 py-1.5 bg-emerald-800 text-white rounded-lg text-xs font-semibold hover:bg-emerald-900 cursor-pointer"
                  >
                    Configure Gateways
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden">
                {withdrawals.length === 0 ? (
                  <div className="py-12 text-center text-xs text-stone-500">No withdrawal requests logged.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                          <th className="p-3">Req Date</th>
                          <th className="p-3">Customer</th>
                          <th className="p-3">Method</th>
                          <th className="p-3">Beneficiary Details</th>
                          <th className="p-3">Amount</th>
                          <th className="p-3">Status</th>
                          <th className="p-3">Tx Ref / Notes</th>
                          <th className="p-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {withdrawals.map(w => (
                          <tr key={w.id} className="hover:bg-stone-50/70 transition-colors">
                            <td className="p-3 font-sans text-stone-600">{w.requestedAt}</td>
                            <td className="p-3 font-sans font-medium text-stone-900">
                              <div>{w.customerName}</div>
                              <div className="text-[10px] text-stone-400 font-mono">{w.customerId}</div>
                            </td>
                            <td className="p-3 font-sans text-stone-800 font-semibold">{w.paymentMethod}</td>
                            <td className="p-3 font-sans text-stone-700">
                              <div className="font-bold">{w.accountTitle}</div>
                              <div className="font-mono text-[11px] text-stone-600">{w.accountNumber}</div>
                              {w.bankName && <div className="text-[10px] text-stone-400">{w.bankName}</div>}
                            </td>
                            <td className="p-3 font-bold text-emerald-950 text-sm">Rs. {w.amount.toLocaleString()}</td>
                            <td className="p-3 font-sans">
                              {w.status === 'paid' && <span className="text-emerald-900 font-bold bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded text-[11px]">Paid</span>}
                              {w.status === 'approved' && <span className="text-teal-900 font-semibold bg-teal-50 border border-teal-200 px-2 py-0.5 rounded text-[11px]">Approved</span>}
                              {w.status === 'under_review' && <span className="text-blue-900 font-semibold bg-blue-50 border border-blue-200 px-2 py-0.5 rounded text-[11px]">Under Review</span>}
                              {w.status === 'pending' && <span className="text-amber-900 font-semibold bg-amber-50 border border-amber-200 px-2 py-0.5 rounded text-[11px]">Pending</span>}
                              {w.status === 'rejected' && <span className="text-red-900 font-semibold bg-red-50 border border-red-200 px-2 py-0.5 rounded text-[11px]">Declined</span>}
                            </td>
                            <td className="p-3 font-mono text-[11px] text-stone-600">
                              <div>{w.transactionReference || '—'}</div>
                              {w.adminNotes && <div className="text-[10px] text-stone-400 font-sans italic">{w.adminNotes}</div>}
                            </td>
                            <td className="p-3 text-right font-sans">
                              <div className="flex items-center justify-end gap-1.5 flex-wrap">
                                {w.status === 'pending' && (
                                  <button
                                    onClick={() => {
                                      processWithdrawal(w.id, 'under_review');
                                      showToast(`Marked request ${w.id} as Under Review.`);
                                    }}
                                    className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 rounded text-[11px] font-semibold cursor-pointer"
                                  >
                                    Review
                                  </button>
                                )}
                                {(w.status === 'pending' || w.status === 'under_review') && (
                                  <button
                                    onClick={() => {
                                      processWithdrawal(w.id, 'approve');
                                      showToast(`Approved request ${w.id} for payment queue.`);
                                    }}
                                    className="px-2 py-1 bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-200 rounded text-[11px] font-semibold cursor-pointer"
                                  >
                                    Approve Queue
                                  </button>
                                )}
                                {(w.status === 'pending' || w.status === 'under_review' || w.status === 'approved') && (
                                  <>
                                    <button
                                      onClick={() => {
                                        const ref = prompt('Enter Bank / Wallet Disbursal Transaction Reference ID:', `TRX-DISB-${Date.now().toString().slice(-6)}`);
                                        if (ref !== null) {
                                          processWithdrawal(w.id, 'pay', ref || `TRX-DISB-${Date.now().toString().slice(-6)}`, 'Payment sent to beneficiary account');
                                          showToast(`Marked withdrawal of Rs. ${w.amount} as Paid.`);
                                        }
                                      }}
                                      className="px-2.5 py-1 bg-emerald-800 hover:bg-emerald-900 text-white rounded text-[11px] font-bold cursor-pointer"
                                    >
                                      Mark Paid
                                    </button>
                                    <button
                                      onClick={() => {
                                        const reason = prompt('Reason for declining withdrawal (amount will be refunded to customer):', 'Account number verification failed');
                                        if (reason !== null) {
                                          processWithdrawal(w.id, 'reject', undefined, reason || 'Account verification declined');
                                          showToast(`Declined and refunded withdrawal.`);
                                        }
                                      }}
                                      className="px-2 py-1 bg-red-50 hover:bg-red-100 text-red-800 border border-red-200 rounded text-[11px] font-semibold cursor-pointer"
                                    >
                                      Decline
                                    </button>
                                  </>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 9. WITHDRAWAL SETTINGS (Requirement 7) */}
          {adminSection === 'withdrawal-settings' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <div>
                  <h2 className="text-xl font-bold font-display text-emerald-950">9. Withdrawal Settings</h2>
                  <p className="text-xs text-stone-500">
                    Configure official farm payout channels: Easypaisa, JazzCash, and Bank Transfer. Only enabled methods appear in the customer withdrawal form.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {editingWithdrawalSettings.map(setting => (
                  <div key={setting.id} className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                      <div className="flex items-center gap-2">
                        {setting.methodKey === 'bank_transfer' ? (
                          <Building2 className="w-5 h-5 text-emerald-800" />
                        ) : (
                          <Smartphone className="w-5 h-5 text-emerald-800" />
                        )}
                        <h3 className="font-bold text-sm text-emerald-950">{setting.name}</h3>
                      </div>
                      
                      {/* Enable/Disable Toggle */}
                      <button
                        type="button"
                        onClick={() => {
                          setEditingWithdrawalSettings(prev => prev.map(s => s.id === setting.id ? { ...s, isEnabled: !s.isEnabled } : s));
                        }}
                        className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                          setting.isEnabled 
                            ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' 
                            : 'bg-stone-100 text-stone-500 border border-stone-300'
                        }`}
                      >
                        {setting.isEnabled ? 'Enabled' : 'Disabled'}
                      </button>
                    </div>

                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="font-semibold text-stone-700 block mb-1">Payment Method Name *</label>
                        <input
                          type="text"
                          value={setting.name}
                          onChange={e => {
                            const val = e.target.value;
                            setEditingWithdrawalSettings(prev => prev.map(s => s.id === setting.id ? { ...s, name: val } : s));
                          }}
                          className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs"
                        />
                      </div>

                      <div>
                        <label className="font-semibold text-stone-700 block mb-1">Disbursing Account Holder Name *</label>
                        <input
                          type="text"
                          value={setting.accountHolderName}
                          onChange={e => {
                            const val = e.target.value;
                            setEditingWithdrawalSettings(prev => prev.map(s => s.id === setting.id ? { ...s, accountHolderName: val } : s));
                          }}
                          className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs"
                        />
                      </div>

                      <div>
                        <label className="font-semibold text-stone-700 block mb-1">
                          {setting.methodKey === 'bank_transfer' ? 'Bank Account Number *' : 'Mobile Wallet Number *'}
                        </label>
                        <input
                          type="text"
                          value={setting.accountNumber}
                          onChange={e => {
                            const val = e.target.value;
                            setEditingWithdrawalSettings(prev => prev.map(s => s.id === setting.id ? { ...s, accountNumber: val } : s));
                          }}
                          className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs font-mono"
                        />
                      </div>

                      {setting.methodKey === 'bank_transfer' && (
                        <>
                          <div>
                            <label className="font-semibold text-stone-700 block mb-1">Bank Name</label>
                            <input
                              type="text"
                              value={setting.bankName || ''}
                              onChange={e => {
                                const val = e.target.value;
                                setEditingWithdrawalSettings(prev => prev.map(s => s.id === setting.id ? { ...s, bankName: val } : s));
                              }}
                              className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs"
                            />
                          </div>

                          <div>
                            <label className="font-semibold text-stone-700 block mb-1">Branch Name (Optional)</label>
                            <input
                              type="text"
                              value={setting.branchName || ''}
                              onChange={e => {
                                const val = e.target.value;
                                setEditingWithdrawalSettings(prev => prev.map(s => s.id === setting.id ? { ...s, branchName: val } : s));
                              }}
                              className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs"
                            />
                          </div>

                          <div>
                            <label className="font-semibold text-stone-700 block mb-1">IBAN (Optional)</label>
                            <input
                              type="text"
                              value={setting.iban || ''}
                              onChange={e => {
                                const val = e.target.value;
                                setEditingWithdrawalSettings(prev => prev.map(s => s.id === setting.id ? { ...s, iban: val } : s));
                              }}
                              className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs font-mono"
                            />
                          </div>
                        </>
                      )}

                      <div>
                        <label className="font-semibold text-stone-700 block mb-1">Payment Instructions for Customer</label>
                        <textarea
                          rows={2}
                          value={setting.paymentInstructions || ''}
                          onChange={e => {
                            const val = e.target.value;
                            setEditingWithdrawalSettings(prev => prev.map(s => s.id === setting.id ? { ...s, paymentInstructions: val } : s));
                          }}
                          className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs"
                        />
                      </div>
                    </div>

                    <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                      <span className="text-[10px] text-stone-400">Updated: {setting.updatedAt}</span>
                      <button
                        type="button"
                        onClick={() => handleSaveWithdrawalSetting(setting.methodKey)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-lg text-xs cursor-pointer shadow-xs"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>Save Changes</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 12. EGG COLLECTION & ALLOCATIONS */}
          {adminSection === 'egg-collection' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-200 gap-3">
                <div>
                  <h2 className="text-xl font-bold font-display text-emerald-950">12. Egg Production & Customer Allocation Management</h2>
                  <p className="text-xs text-stone-500">
                    Physical collections, verified inventory pool, customer allocations, and audited adjustments.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      triggerEggCycleReset();
                      showToast('Successfully recorded daily collection sweep & reset 24H customer timer.');
                    }}
                    className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-2 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Reset 24H Flock Cycle Timer</span>
                  </button>
                </div>
              </div>

              {/* Physical Inventory & Tally Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-[11px] font-bold text-stone-500 uppercase">Total Collected</span>
                  <div className="text-xl font-bold font-mono text-emerald-950">
                    {productionRecords.reduce((acc, r) => acc + r.eggsCollected, 0).toLocaleString()}
                  </div>
                  <span className="text-[10px] text-stone-400">Across {productionRecords.length} sweeps</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-[11px] font-bold text-stone-500 uppercase">Damaged / Broken</span>
                  <div className="text-xl font-bold font-mono text-rose-700">
                    {productionRecords.reduce((acc, r) => acc + r.eggsDamaged, 0).toLocaleString()}
                  </div>
                  <span className="text-[10px] text-stone-400">Honest cull count</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-[11px] font-bold text-stone-500 uppercase">Wholesale Sold</span>
                  <div className="text-xl font-bold font-mono text-stone-800">
                    {eggSales.reduce((acc, s) => acc + s.quantityEggs, 0).toLocaleString()}
                  </div>
                  <span className="text-[10px] text-stone-400">Dispatched to mandis</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs space-y-1">
                  <span className="text-[11px] font-bold text-stone-500 uppercase">Customer Allocated</span>
                  <div className="text-xl font-bold font-mono text-amber-700">
                    {eggAllocations.reduce((acc, a) => acc + a.quantity, 0).toLocaleString()}
                  </div>
                  <span className="text-[10px] text-stone-400">Across {eggAllocations.length} records</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-emerald-500/40 shadow-xs space-y-1 bg-gradient-to-b from-emerald-50/60 to-white">
                  <span className="text-[11px] font-bold text-emerald-800 uppercase">Verified Available</span>
                  <div className="text-2xl font-bold font-mono text-emerald-950">
                    {availableVerifiedEggs.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-emerald-700 font-semibold">Reserve Pool</span>
                </div>
              </div>

              {/* Two Column Grid: Allocation Generator + Audited Adjustments */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Panel 1: Allocate Verified Harvest to Active Flock Customers */}
                <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
                  <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                    <h3 className="font-bold text-sm text-emerald-950 font-display">
                      Allocate Verified Production to Customers
                    </h3>
                    <span className="text-[11px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {hens.filter(h => h.status === 'owned').length} Active Owned Hens
                    </span>
                  </div>

                  <p className="text-xs text-stone-600 leading-relaxed">
                    Distributes verified physical eggs from the holding pool to registered customer accounts according to their active hen ownership ratio.
                  </p>

                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="font-bold text-stone-700 block mb-1">Target Farm Shed / Flock</label>
                      <select
                        value={allocShedId}
                        onChange={e => setAllocShedId(e.target.value)}
                        className="w-full px-3 py-2 border border-stone-300 rounded-xl text-stone-900"
                      >
                        <option value="all">All Commercial Sheds (Flock Proportionate)</option>
                        {sheds.map(s => (
                          <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="font-bold text-stone-700 block mb-1">
                        Eggs to Distribute (Leave 0 for automatic available pool allocation)
                      </label>
                      <input
                        type="number"
                        min="0"
                        max={availableVerifiedEggs}
                        value={customAllocQty}
                        onChange={e => setCustomAllocQty(parseInt(e.target.value) || 0)}
                        className="w-full px-3 py-2 border border-stone-300 rounded-xl font-mono text-stone-900"
                      />
                      <span className="text-[10px] text-stone-400 mt-0.5 block">
                        Maximum unreserved available: {availableVerifiedEggs} eggs
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        const res = allocateFlockProduction(allocShedId, customAllocQty > 0 ? customAllocQty : undefined);
                        showToast(res.message);
                      }}
                      disabled={availableVerifiedEggs <= 0 || hens.filter(h => h.status === 'owned').length === 0}
                      className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-900 disabled:bg-stone-300 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Execute Allocation & Restart 24H Cycle</span>
                    </button>
                  </div>
                </div>

                {/* Panel 2: Audited Corrections & Adjustments */}
                <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
                  <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                    <h3 className="font-bold text-sm text-emerald-950 font-display">
                      Audited Egg Adjustment (Corrections)
                    </h3>
                    <span className="text-[11px] font-mono text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      Permanent Audit Trail
                    </span>
                  </div>

                  <p className="text-xs text-stone-600 leading-relaxed">
                    Correct accounting errors, physical inventory recount discrepancies, or damaged batch offsets with permanent audit logging.
                  </p>

                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="font-bold text-stone-700 block mb-1">Select Customer Account *</label>
                      <select
                        value={adjCustomer}
                        onChange={e => setAdjCustomer(e.target.value)}
                        className="w-full px-3 py-2 border border-stone-300 rounded-xl text-stone-900"
                      >
                        <option value="">-- Choose Customer --</option>
                        {customers.map(c => (
                          <option key={c.id} value={c.id}>{c.name} ({c.email})</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="font-bold text-stone-700 block mb-1">Quantity Adjustment (+/-)</label>
                        <input
                          type="number"
                          value={adjQty}
                          onChange={e => setAdjQty(parseInt(e.target.value) || 0)}
                          className="w-full px-3 py-2 border border-stone-300 rounded-xl font-mono text-stone-900"
                        />
                      </div>
                      <div>
                        <label className="font-bold text-stone-700 block mb-1">Supervisor Clearance</label>
                        <input
                          type="text"
                          value="Tariq Mahmood (Operations Lead)"
                          disabled
                          className="w-full px-3 py-2 border border-stone-200 bg-stone-50 rounded-xl text-stone-500 text-[11px]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="font-bold text-stone-700 block mb-1">Audited Correction Reason *</label>
                      <input
                        type="text"
                        value={adjReason}
                        onChange={e => setAdjReason(e.target.value)}
                        placeholder="e.g. Physical inventory recount discrepancy corrected"
                        className="w-full px-3 py-2 border border-stone-300 rounded-xl text-stone-900 text-xs"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (!adjCustomer) {
                          showToast('Please select a customer.');
                          return;
                        }
                        if (adjQty === 0) {
                          showToast('Adjustment quantity cannot be 0.');
                          return;
                        }
                        adjustCustomerEggs(adjCustomer, adjQty, adjReason);
                        showToast(`Successfully adjusted ${adjQty} eggs for selected customer.`);
                        setAdjQty(1);
                      }}
                      className="w-full py-2.5 bg-amber-700 hover:bg-amber-800 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
                    >
                      <FileText className="w-4 h-4" />
                      <span>Post Audited Adjustment</span>
                    </button>
                  </div>
                </div>

              </div>

              {/* Customer Egg Allocations Ledger Table */}
              <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
                <div className="p-4 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-sm text-emerald-950 font-display">
                      Customer Egg Allocations Ledger ({eggAllocations.length} entries)
                    </h3>
                    <p className="text-xs text-stone-500">
                      Permanent verifiable records of initial purchase allocations and daily collection credits.
                    </p>
                  </div>
                </div>

                {eggAllocations.length === 0 ? (
                  <div className="py-12 text-center text-xs text-stone-500">
                    No customer egg allocations logged yet.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                          <th className="p-3">Allocation ID</th>
                          <th className="p-3">Customer</th>
                          <th className="p-3">Type</th>
                          <th className="p-3">Batch / Shed</th>
                          <th className="p-3">Eggs</th>
                          <th className="p-3">Timestamp</th>
                          <th className="p-3">Notes</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {eggAllocations.map(a => (
                          <tr key={a.id} className="hover:bg-stone-50 transition-colors">
                            <td className="p-3 font-bold text-emerald-950">{a.id}</td>
                            <td className="p-3 font-sans text-stone-800">{a.customerName}</td>
                            <td className="p-3 font-sans">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                a.allocationType === 'initial_purchase'
                                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                  : a.allocationType === 'daily_collection'
                                  ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                                  : 'bg-teal-100 text-teal-900 border border-teal-300'
                              }`}>
                                {a.allocationType === 'initial_purchase' ? 'Initial Purchase' : a.allocationType === 'daily_collection' ? 'Daily Sweep' : 'Adjustment'}
                              </span>
                            </td>
                            <td className="p-3 font-sans text-stone-600">{a.shedName || a.batchId || 'Farm Stock'}</td>
                            <td className="p-3 font-bold text-emerald-900 text-sm">+{a.quantity}</td>
                            <td className="p-3 text-stone-600 text-[11px]">{a.date}</td>
                            <td className="p-3 font-sans text-stone-500 text-[11px] max-w-xs truncate">{a.notes}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 13. REPORTS */}
          {adminSection === 'reports' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <h2 className="text-xl font-bold font-display text-emerald-950">13. Agricultural Operations Reports</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs space-y-2">
                  <span className="text-xs font-bold text-stone-700 uppercase">Flock Status Report</span>
                  <div className="text-sm font-semibold text-emerald-950">3 Active Commercial Sheds</div>
                  <p className="text-xs text-stone-500">Mandra-Chakwal Highway Facility · Biosecurity Level 2 Verified</p>
                </div>
                <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs space-y-2">
                  <span className="text-xs font-bold text-stone-700 uppercase">Average Feed Ratio</span>
                  <div className="text-sm font-semibold text-emerald-950">118g Layer Mash / Hen / Day</div>
                  <p className="text-xs text-stone-500">16% Crude Protein balanced formulation</p>
                </div>
                <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs space-y-2">
                  <span className="text-xs font-bold text-stone-700 uppercase">Mandi Rate Baseline</span>
                  <div className="text-sm font-semibold text-emerald-950">Rs. 14.75 / Egg Wholesale</div>
                  <p className="text-xs text-stone-500">Rawalpindi Ganj Mandi Index</p>
                </div>
              </div>
            </div>
          )}

          {/* 14. NOTIFICATIONS */}
          {adminSection === 'notifications' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <h2 className="text-xl font-bold font-display text-emerald-950">14. Farm Notifications Broadcast</h2>
              </div>
              <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-xs space-y-3">
                <h3 className="font-bold text-sm text-emerald-950">System Broadcasts ({notifications.length})</h3>
                <div className="space-y-2 text-xs">
                  {notifications.map(n => (
                    <div key={n.id} className="p-3 bg-stone-50 rounded-lg border border-stone-200 flex justify-between items-start gap-4">
                      <div>
                        <span className="font-bold text-stone-900">{n.title}</span>
                        <p className="text-stone-600 text-[11px]">{n.message}</p>
                      </div>
                      <span className="text-[10px] text-stone-400 font-mono shrink-0">{n.date}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 15. AUDIT LOGS */}
          {adminSection === 'audit' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <h2 className="text-xl font-bold font-display text-emerald-950">15. Immutable Operations Audit Log</h2>
                <span className="text-xs text-stone-500 font-mono">Append-Only Audit Stream</span>
              </div>
              <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-6 space-y-3 divide-y divide-stone-100 text-xs">
                {auditLogs.map(log => (
                  <div key={log.id} className="pt-3 first:pt-0 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <div>
                      <div className="font-bold text-emerald-950 flex items-center gap-2">
                        <span>{log.action}</span>
                        <span className="text-[10px] uppercase font-mono text-stone-500">[{log.category}]</span>
                      </div>
                      <p className="text-stone-600 text-[11px]">{log.details}</p>
                    </div>
                    <div className="text-right text-[11px] text-stone-400 font-mono shrink-0">
                      <div>{log.actor}</div>
                      <div>{log.timestamp}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 16. WEBSITE & DB SETTINGS */}
          {adminSection === 'settings' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                <div>
                  <h2 className="text-xl font-bold font-display text-emerald-950">16. Website & Database Management</h2>
                  <p className="text-xs text-stone-500">Database backups, migrations, and platform configuration</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Backup & Export */}
                <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-xs space-y-3">
                  <h3 className="font-bold text-sm text-emerald-950 font-display">Database Backup & Archive</h3>
                  <p className="text-xs text-stone-600 leading-relaxed">
                    Generate an instant JSON snapshot of all live hen inventory, deposit records, purchases, and audit trails.
                  </p>
                  <button
                    onClick={handleDownloadBackup}
                    className="flex items-center gap-1.5 px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-bold shadow-xs transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Production Backup (.json)</span>
                  </button>
                </div>

                {/* Supabase Schema */}
                <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-xs space-y-3">
                  <h3 className="font-bold text-sm text-emerald-950 font-display">PostgreSQL DDL Migration</h3>
                  <p className="text-xs text-stone-600 leading-relaxed">
                    19+ normalized tables with Row Level Security (RLS) policies for Supabase deployment.
                  </p>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(SUPABASE_SCHEMA_SQL);
                      showToast('Copied full PostgreSQL schema to clipboard.');
                    }}
                    className="flex items-center gap-1.5 px-4 py-2 border border-stone-300 hover:bg-stone-50 text-stone-800 rounded-lg text-xs font-semibold"
                  >
                    <span>Copy Full PostgreSQL DDL</span>
                  </button>
                </div>

              </div>
            </div>
          )}

        </main>
      </div>

    </div>
  );
};
