import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  ShieldCheck, 
  CheckCircle2, 
  Database, 
  Loader2, 
  Copy, 
  Check, 
  Calendar,
  Users,
  AlertCircle
} from 'lucide-react';
import { 
  saveAppointmentToSupabase, 
  testSupabaseHealth, 
  SUPABASE_PROJECT_ID, 
  SUPABASE_APPOINTMENTS_SQL,
  AppointmentRecord
} from '../../lib/supabase';

export const ContactView: React.FC = () => {
  const [visitorName, setVisitorName] = useState('');
  const [visitorPhone, setVisitorPhone] = useState('');
  const [visitorEmail, setVisitorEmail] = useState('');
  const [visitDate, setVisitDate] = useState('');
  const [visitorCount, setVisitorCount] = useState(2);
  const [visitorNotes, setVisitorNotes] = useState('');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedRecord, setSubmittedRecord] = useState<AppointmentRecord | null>(null);
  const [supabaseSyncResult, setSupabaseSyncResult] = useState<{
    synced: boolean;
    tableNotCreated?: boolean;
    message: string;
  } | null>(null);

  const [copiedSql, setCopiedSql] = useState(false);
  const [showSqlGuide, setShowSqlGuide] = useState(false);
  const [backendHealth, setBackendHealth] = useState<{
    connected: boolean;
    status: string;
    tableFound: boolean;
  }>({
    connected: true,
    status: 'Checking Supabase backend...',
    tableFound: false,
  });

  // Check Supabase health on component mount
  useEffect(() => {
    let isMounted = true;
    testSupabaseHealth().then(health => {
      if (isMounted) {
        setBackendHealth({
          connected: health.connected,
          status: health.status,
          tableFound: health.tableFound,
        });
      }
    });
    return () => {
      isMounted = false;
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!visitorName.trim() || !visitorPhone.trim() || !visitDate) {
      return;
    }

    setIsSubmitting(true);
    setSupabaseSyncResult(null);

    try {
      const result = await saveAppointmentToSupabase({
        name: visitorName,
        phone: visitorPhone,
        date: visitDate,
        visitorCount: Number(visitorCount) || 1,
        email: visitorEmail,
        notes: visitorNotes,
      });

      setSubmittedRecord(result.record);
      setSupabaseSyncResult({
        synced: result.syncedToSupabase,
        tableNotCreated: result.tableNotCreated,
        message: result.message,
      });
    } catch (err: any) {
      console.error('Error submitting appointment:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_APPOINTMENTS_SQL);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  const resetForm = () => {
    setSubmittedRecord(null);
    setSupabaseSyncResult(null);
    setVisitorName('');
    setVisitorPhone('');
    setVisitorEmail('');
    setVisitDate('');
    setVisitorCount(2);
    setVisitorNotes('');
  };

  return (
    <div className="py-12 bg-stone-50/70 min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Header */}
        <div className="text-center space-y-3 max-w-xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-100/80 text-emerald-900 rounded-full text-xs font-semibold uppercase tracking-wider">
            <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
            Direct Communications & Farm Visits
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold font-display text-emerald-950 tracking-tight">
            Contact Us & Visit the Farm
          </h1>
          <p className="text-sm text-stone-600 leading-relaxed">
            We welcome our hen-owning community to inspect physical birds, observe layer sheds, and verify biological biosecurity protocols.
          </p>

          {/* Supabase backend connection status indicator */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-stone-100 border border-stone-200/90 rounded-full text-xs text-stone-700 shadow-2xs">
            <Database className="w-3.5 h-3.5 text-emerald-700" />
            <span>Supabase Backend:</span>
            <span className="font-mono font-semibold text-emerald-800">{SUPABASE_PROJECT_ID}</span>
            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Live Sync
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
          
          {/* Farm Location, Contact & Biosecurity */}
          <div className="bg-white rounded-2xl border border-emerald-950/10 p-6 sm:p-8 shadow-xs space-y-6">
            <h3 className="text-xl font-bold font-display text-emerald-950">
              Farm Physical Location
            </h3>

            <div className="space-y-4 text-xs text-stone-700">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-emerald-800 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-stone-900 font-semibold">Farming Master Egg Agro Complex</strong>
                  <span>Plot 14-B, Mandra-Chakwal Highway, Tehsil Gujar Khan, Rawalpindi / Chakwal District, Punjab, Pakistan.</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-emerald-800 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-stone-900 font-semibold">Farm Operations & WhatsApp</strong>
                  <span>+92 333 4920199 / +92 300 5148920 (09:00 AM – 06:00 PM PKT)</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-emerald-800 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-stone-900 font-semibold">Official Correspondence</strong>
                  <span>operations@farmingmasteregg.com</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-emerald-800 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-stone-900 font-semibold">Public & Customer Visiting Windows</strong>
                  <span>Tuesdays & Saturdays: 10:00 AM – 03:00 PM (Prior Appointment Required)</span>
                </div>
              </div>
            </div>

            {/* Biosecurity notice */}
            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100 text-xs text-emerald-950 space-y-2">
              <div className="flex items-center gap-2 font-bold text-emerald-900">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>Level-2 Biosecurity Protocol for Visitors</span>
              </div>
              <p className="text-[11px] text-emerald-900/90 leading-relaxed">
                To protect our layers against virulent Newcastle Disease and Avian Influenza, visitors must not have visited another commercial poultry farm within the preceding 72 hours. Protective boot covers and sterile farm suits are provided at the security gate.
              </p>
            </div>
          </div>

          {/* Visit Booking Form with Supabase integration */}
          <div className="bg-white rounded-2xl border border-emerald-950/10 p-6 sm:p-8 shadow-xs space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold font-display text-emerald-950">
                  Schedule an On-Site Inspection
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Appointments are saved directly to the Supabase database.
                </p>
              </div>
              <div className="p-2 bg-emerald-50 rounded-lg text-emerald-800">
                <Calendar className="w-5 h-5" />
              </div>
            </div>

            {submittedRecord ? (
              <div className="p-6 bg-emerald-50/80 rounded-2xl border border-emerald-200 text-left space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-7 h-7 text-emerald-700 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-base text-emerald-950 font-display">
                      Appointment Request Recorded!
                    </h4>
                    <p className="text-xs text-emerald-900/90 mt-1 leading-relaxed">
                      Thank you, <strong className="text-stone-900">{submittedRecord.full_name}</strong>. Farm supervisor Tariq Mahmood will contact you via WhatsApp at <span className="font-mono font-semibold text-emerald-950">{submittedRecord.phone_number}</span> to confirm biosecurity clearance and gate pass for your visit on <strong>{submittedRecord.visit_date}</strong>.
                    </p>
                  </div>
                </div>

                {/* Supabase Sync Badge */}
                <div className="p-3.5 bg-white rounded-xl border border-emerald-200/80 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-stone-700 flex items-center gap-1.5">
                      <Database className="w-4 h-4 text-emerald-700" />
                      Supabase Cloud Status
                    </span>
                    {supabaseSyncResult?.synced ? (
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-semibold rounded-md text-[10px] uppercase">
                        Synced to Table
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 bg-amber-100 text-amber-800 font-semibold rounded-md text-[10px] uppercase">
                        Saved Locally & Queued
                      </span>
                    )}
                  </div>

                  <p className="text-[11px] text-stone-600">
                    {supabaseSyncResult?.message}
                  </p>

                  <div className="pt-2 border-t border-stone-100 text-[11px] grid grid-cols-2 gap-2 text-stone-500">
                    <div>
                      <span>Booking Ref: </span>
                      <span className="font-mono text-stone-900 font-medium">{submittedRecord.id}</span>
                    </div>
                    <div>
                      <span>Visitor Count: </span>
                      <span className="font-medium text-stone-900">{submittedRecord.visitor_count} person(s)</span>
                    </div>
                  </div>
                </div>

                {/* If the table has not been created yet in user's Supabase dashboard, provide 1-click SQL copy */}
                {supabaseSyncResult?.tableNotCreated && (
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs space-y-2">
                    <div className="flex items-start gap-2 text-amber-900">
                      <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <strong className="block font-semibold">Supabase Setup Tip</strong>
                        <p className="text-[11px] text-amber-800 leading-relaxed">
                          The request is safely preserved in the farm registry. To have Supabase store it directly into your project's PostgreSQL table, run this quick SQL in your Supabase SQL Editor.
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowSqlGuide(!showSqlGuide)}
                      className="text-[11px] text-amber-900 underline font-semibold hover:text-amber-950"
                    >
                      {showSqlGuide ? 'Hide SQL Script' : 'View / Copy Supabase SQL Script'}
                    </button>

                    {showSqlGuide && (
                      <div className="mt-2 space-y-2">
                        <pre className="p-2.5 bg-stone-900 text-emerald-400 font-mono text-[10px] rounded-lg overflow-x-auto max-h-36">
                          {SUPABASE_APPOINTMENTS_SQL}
                        </pre>
                        <button
                          type="button"
                          onClick={handleCopySql}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-black transition-colors"
                        >
                          {copiedSql ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          {copiedSql ? 'Copied to Clipboard!' : 'Copy SQL Script'}
                        </button>
                      </div>
                    )}
                  </div>
                )}

                <button
                  onClick={resetForm}
                  className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
                >
                  Book Another Visit
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                
                {/* Full Legal Name */}
                <div>
                  <label htmlFor="contact-visitor-name" className="font-semibold text-stone-700 block mb-1">
                    Full Legal Name *
                  </label>
                  <input
                    id="contact-visitor-name"
                    type="text"
                    value={visitorName}
                    onChange={e => setVisitorName(e.target.value)}
                    placeholder="e.g. Kamran Ahmed"
                    className="w-full px-3.5 py-2.5 border border-stone-200 rounded-xl text-stone-900 focus:outline-hidden focus:border-emerald-700 focus:ring-1 focus:ring-emerald-700 bg-stone-50/50"
                    required
                  />
                </div>

                {/* WhatsApp / Phone Number */}
                <div>
                  <label htmlFor="contact-visitor-phone" className="font-semibold text-stone-700 block mb-1">
                    WhatsApp / Phone Number *
                  </label>
                  <input
                    id="contact-visitor-phone"
                    type="text"
                    value={visitorPhone}
                    onChange={e => setVisitorPhone(e.target.value)}
                    placeholder="+92 300 1234567"
                    className="w-full px-3.5 py-2.5 border border-stone-200 rounded-xl text-stone-900 focus:outline-hidden focus:border-emerald-700 focus:ring-1 focus:ring-emerald-700 bg-stone-50/50 font-mono"
                    required
                  />
                </div>

                {/* Email Address (Optional) */}
                <div>
                  <label htmlFor="contact-visitor-email" className="font-semibold text-stone-700 block mb-1">
                    Email Address <span className="text-stone-400 font-normal">(Optional)</span>
                  </label>
                  <input
                    id="contact-visitor-email"
                    type="email"
                    value={visitorEmail}
                    onChange={e => setVisitorEmail(e.target.value)}
                    placeholder="kamran@example.com"
                    className="w-full px-3.5 py-2.5 border border-stone-200 rounded-xl text-stone-900 focus:outline-hidden focus:border-emerald-700 focus:ring-1 focus:ring-emerald-700 bg-stone-50/50"
                  />
                </div>

                {/* Preferred Date & Visitor Count */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="contact-visit-date" className="font-semibold text-stone-700 block mb-1">
                      Preferred Date *
                    </label>
                    <input
                      id="contact-visit-date"
                      type="date"
                      value={visitDate}
                      onChange={e => setVisitDate(e.target.value)}
                      min={new Date().toISOString().split('T')[0]}
                      className="w-full px-3.5 py-2.5 border border-stone-200 rounded-xl text-stone-900 focus:outline-hidden focus:border-emerald-700 focus:ring-1 focus:ring-emerald-700 bg-stone-50/50"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="contact-visitor-count" className="font-semibold text-stone-700 block mb-1">
                      Number of Visitors
                    </label>
                    <div className="relative">
                      <input
                        id="contact-visitor-count"
                        type="number"
                        min={1}
                        max={10}
                        value={visitorCount}
                        onChange={e => setVisitorCount(parseInt(e.target.value) || 1)}
                        className="w-full px-3.5 py-2.5 border border-stone-200 rounded-xl text-stone-900 focus:outline-hidden focus:border-emerald-700 focus:ring-1 focus:ring-emerald-700 bg-stone-50/50 font-mono pr-8"
                        required
                      />
                      <Users className="w-4 h-4 text-stone-400 absolute right-3 top-3 pointer-events-none" />
                    </div>
                  </div>
                </div>

                {/* Special Requests / Notes */}
                <div>
                  <label htmlFor="contact-visitor-notes" className="font-semibold text-stone-700 block mb-1">
                    Inspection Focus / Notes <span className="text-stone-400 font-normal">(Optional)</span>
                  </label>
                  <textarea
                    id="contact-visitor-notes"
                    rows={2}
                    value={visitorNotes}
                    onChange={e => setVisitorNotes(e.target.value)}
                    placeholder="e.g. Inspecting batch S1-L40, egg sorting floor observation"
                    className="w-full px-3.5 py-2.5 border border-stone-200 rounded-xl text-stone-900 focus:outline-hidden focus:border-emerald-700 focus:ring-1 focus:ring-emerald-700 bg-stone-50/50"
                  />
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 bg-emerald-800 hover:bg-emerald-900 disabled:bg-emerald-800/60 text-white font-bold rounded-xl transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer text-sm"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Saving to Supabase Backend...
                    </>
                  ) : (
                    <>
                      <Database className="w-4 h-4" />
                      Submit Visit Request to Supabase
                    </>
                  )}
                </button>

                <p className="text-[11px] text-stone-500 text-center flex items-center justify-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                  Encrypted & securely transmitted to Supabase PostgreSQL database
                </p>
              </form>
            )}
          </div>

        </div>

        {/* Supabase Integration Details Banner for Farm Admins */}
        <div className="bg-white rounded-2xl border border-stone-200/90 p-5 sm:p-6 shadow-2xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-900 text-white flex items-center justify-center font-bold">
                <Database className="w-5 h-5 text-emerald-300" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-stone-900">
                  Supabase Backend Configuration
                </h4>
                <p className="text-xs text-stone-500">
                  Active connection to Project <span className="font-mono text-emerald-800 font-semibold">{SUPABASE_PROJECT_ID}</span>
                </p>
              </div>
            </div>

            <button
              onClick={handleCopySql}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-stone-100 hover:bg-stone-200 border border-stone-300/80 text-stone-800 rounded-lg text-xs font-semibold transition-colors"
            >
              {copiedSql ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-stone-600" />}
              {copiedSql ? 'SQL Schema Copied!' : 'Copy Supabase SQL Setup'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-stone-600">
            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/60">
              <span className="block text-stone-400 text-[10px] uppercase font-bold tracking-wider">Project URL</span>
              <span className="font-mono text-[11px] text-stone-900 font-medium break-all">
                https://{SUPABASE_PROJECT_ID}.supabase.co
              </span>
            </div>
            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/60">
              <span className="block text-stone-400 text-[10px] uppercase font-bold tracking-wider">Target Table</span>
              <span className="font-mono text-[11px] text-emerald-800 font-semibold">
                public.appointments
              </span>
            </div>
            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/60">
              <span className="block text-stone-400 text-[10px] uppercase font-bold tracking-wider">Publishable Key</span>
              <span className="font-mono text-[11px] text-stone-900 font-medium">
                sb_publishable_...KiT (Authorized)
              </span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
