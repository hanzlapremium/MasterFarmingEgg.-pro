import React from 'react';
import { Clock, Sun, Sunrise, Sunset, Moon, Activity, CheckCircle2 } from 'lucide-react';

export const ProductionProcessView: React.FC = () => {
  const schedule = [
    {
      time: '05:30 AM',
      icon: Sunrise,
      title: 'Dawn Photoperiod & Initial Water Flush',
      details: 'Automated shed LED lighting illuminates at 16-lux intensity simulating natural sunrise. High-pressure water lines are flushed with mild acidifier to maintain optimal gut flora.'
    },
    {
      time: '06:30 AM',
      icon: Sun,
      title: 'Primary Morning Feeding Auger Activation',
      details: 'Timed chain feeding augers distribute 70 grams per bird of fresh 16% CP Layer Mash. Flock appetite and feed consumption speed are recorded on the morning clipboard.'
    },
    {
      time: '08:30 AM',
      icon: Clock,
      title: 'Morning Egg Collection Sweep (Main Laying Window)',
      details: '70% of layer hen oviposition occurs within 4 hours of daylight. Farm hands inspect roll-away nest boxes, retrieve eggs into sanitized collection buckets, and tally initial counts.'
    },
    {
      time: '11:00 AM',
      icon: Activity,
      title: 'Veterinary Biosecurity & Health Patrol',
      details: 'Resident vet Dr. Yasir checks shed ambient temperature, static air pressure, ammonia sensors (<15 ppm), litter dryness, and examines any bird exhibiting sluggish movement or molt signs.'
    },
    {
      time: '02:30 PM',
      icon: Sun,
      title: 'Secondary Afternoon Feed & Electrolyte Top-Up',
      details: 'Afternoon feeding (approx 45 grams per bird) supplemented with essential vitamins (A, D3, E) and calcium grit top-dress to reinforce nocturnal eggshell formation.'
    },
    {
      time: '03:30 PM',
      icon: Sunset,
      title: 'Secondary Egg Collection & Grading',
      details: 'Afternoon collection sweep ensures zero eggs remain overnight in nest boxes. Eggs undergo candling inspection, grading by weight, and packing into 30-egg fiber trays.'
    },
    {
      time: '05:30 PM',
      icon: Moon,
      title: 'Wholesale Mandi Crating & Dispatch',
      details: 'Sanitized refrigerated or covered transport trucks arrive from Rawalpindi / Islamabad wholesale markets. Invoices are logged with quantity, rate, and buyer signature.'
    },
    {
      time: '07:30 PM',
      icon: Moon,
      title: 'Flock Roosting & Photoperiod Dimming',
      details: 'Light dimming sequence over 30 minutes prompts natural roosting on perches. Night curtains closed, perimeter electric fencing and security dogs active for predator defense.'
    }
  ];

  return (
    <div className="py-12 bg-stone-50/70 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        <div className="text-center space-y-3 max-w-xl mx-auto">
          <div className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
            Daily Operational Rhythm
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold font-display text-emerald-950 tracking-tight">
            Daily Egg Production Process
          </h1>
          <p className="text-sm text-stone-600 leading-relaxed">
            Every egg produced on our farm is the result of disciplined, hour-by-hour commercial animal husbandry protocols.
          </p>
        </div>

        {/* Timeline */}
        <div className="space-y-4 relative before:absolute before:inset-0 before:left-5 sm:before:left-8 before:w-0.5 before:bg-emerald-900/10">
          {schedule.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={item.time}
                className="relative flex items-start gap-4 sm:gap-6 bg-white p-5 sm:p-6 rounded-xl border border-emerald-950/10 shadow-xs hover:border-emerald-700/30 transition-all ml-2 sm:ml-4"
              >
                <div className="w-9 h-9 rounded-full bg-emerald-800 text-white flex items-center justify-center shrink-0 z-10 shadow-xs">
                  <Icon className="w-4 h-4 text-emerald-200" />
                </div>

                <div className="space-y-1 flex-1 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-1">
                    <h3 className="font-bold text-sm text-emerald-950 font-display">{item.title}</h3>
                    <span className="font-mono font-bold text-emerald-800">{item.time}</span>
                  </div>
                  <p className="text-stone-600 leading-relaxed text-xs">
                    {item.details}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};
