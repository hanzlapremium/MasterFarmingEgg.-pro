import React from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, Check, ArrowRight, AlertCircle, FileText, CheckCircle2 } from 'lucide-react';

export const HowItWorksView: React.FC = () => {
  const { setActiveView, setPurchaseModalOpen } = useApp();

  const steps = [
    {
      num: '01',
      title: 'Choose Available Physical Hens',
      desc: 'Browse our live inventory of registered layer hens across our Punjab sheds. Each hen has a unique wing/leg band tag code (e.g. FME-L201), known age in weeks, and verifiable breed. Initial listed acquisition price is strictly Rs. 500 per hen.',
    },
    {
      num: '02',
      title: 'Sign the Hen Ownership & Farm-Care Agreement',
      desc: 'Execute a transparent legal custody and bailment contract. You retain legal title to the physical hen while appointing Farming Master Egg as your authorized agricultural caretaker and flock custodian under documented animal welfare standards.',
    },
    {
      num: '03',
      title: 'Professional Veterinary Farm Custody',
      desc: 'Your hen is housed in our climate-managed sheds with automated feeding (16% crude protein balanced layer mash), fresh nipple waterers, continuous biosecurity disinfections, and bi-weekly certified veterinary health examinations.',
    },
    {
      num: '04',
      title: 'Daily Egg Collection & Wholesale Mandi Sales',
      desc: 'Every morning and afternoon, eggs are swept from laying nest boxes, quality graded, crated, and sold at prevailing market rates to wholesale buyers and institutional bakers in Rawalpindi, Islamabad, and Punjab wholesale mandis.',
    },
    {
      num: '05',
      title: 'Transparent Operational Cost Deduction',
      desc: 'Documented farm operating expenses (feed bags, electricity, veterinary care, labor) are subtracted directly from gross egg sales. Net proceeds are allocated strictly by flock proportion under your signed agreement.',
    },
    {
      num: '06',
      title: 'Monthly Statement & Verified Disbursements',
      desc: 'At the end of each monthly cycle, view your itemized accounting ledger in your Customer Dashboard. Withdraw verified proceeds directly to Easypaisa, JazzCash, or bank transfer (minimum Rs. 1,000 threshold).',
    },
  ];

  return (
    <div className="py-12 bg-stone-50/70 min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
            Operational Blueprint · No Gimmicks
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold font-display text-emerald-950 tracking-tight">
            How Physical Hen Ownership Works
          </h1>
          <p className="text-sm text-stone-600 leading-relaxed">
            A real-world commercial poultry enterprise where you own the physical birds and we provide the daily agricultural custody, feed, and market distribution.
          </p>
        </div>

        {/* Steps Flow */}
        <div className="space-y-4">
          {steps.map((step, idx) => (
            <div
              key={step.num}
              className="bg-white p-6 rounded-xl border border-emerald-950/10 shadow-xs flex flex-col sm:flex-row items-start gap-5 hover:border-emerald-700/30 transition-all"
            >
              <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center font-display font-bold text-lg text-emerald-900 shrink-0">
                {step.num}
              </div>
              <div className="space-y-1.5 flex-1">
                <h3 className="font-bold text-base text-emerald-950 font-display">
                  {step.title}
                </h3>
                <p className="text-xs text-stone-600 leading-relaxed">
                  {step.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* What We Are vs What We Are NOT */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
          
          {/* Authentic Realities */}
          <div className="bg-emerald-900/10 border border-emerald-800/30 p-6 rounded-xl space-y-4">
            <h3 className="font-bold text-sm text-emerald-950 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700" />
              <span>What Farming Master Egg Is</span>
            </h3>
            <ul className="space-y-2 text-xs text-stone-700">
              <li className="flex items-start gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-700 mt-0.5 shrink-0" />
                <span>An actual poultry farm situated in Mandra-Chakwal, Punjab.</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-700 mt-0.5 shrink-0" />
                <span>Physical hens tagged with individual identification markers.</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-700 mt-0.5 shrink-0" />
                <span>Real veterinary care, real feed consumption, and real egg harvest.</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-700 mt-0.5 shrink-0" />
                <span>Distributions backed by actual wholesale invoices and bank receipts.</span>
              </li>
            </ul>
          </div>

          {/* Strict Prohibitions */}
          <div className="bg-red-50/70 border border-red-200 p-6 rounded-xl space-y-4">
            <h3 className="font-bold text-sm text-red-950 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-700" />
              <span>What Farming Master Egg is NOT</span>
            </h3>
            <ul className="space-y-2 text-xs text-stone-700">
              <li className="flex items-start gap-2">
                <span className="text-red-600 font-bold shrink-0">✕</span>
                <span>NOT an MLM, referral matrix, or Ponzi pyramid scheme.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-600 font-bold shrink-0">✕</span>
                <span>NO guaranteed daily profits, fixed returns, or risk-free claims.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-600 font-bold shrink-0">✕</span>
                <span>NO artificial balances generated from incoming investor deposits.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-600 font-bold shrink-0">✕</span>
                <span>NO false individual egg-to-hen tracking claims.</span>
              </li>
            </ul>
          </div>

        </div>

        {/* CTA */}
        <div className="bg-white p-8 rounded-2xl border border-emerald-950/10 text-center space-y-4 shadow-xs">
          <h3 className="text-xl font-bold font-display text-emerald-950">
            Ready to inspect available physical hens?
          </h3>
          <p className="text-xs text-stone-600 max-w-md mx-auto">
            Hens currently listed at Rs. 500 each. Complete with official downloadable ownership certificate and physical bailment contract.
          </p>
          <button
            onClick={() => {
              setActiveView('marketplace');
              setPurchaseModalOpen(true);
            }}
            className="px-6 py-3 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-lg shadow-xs transition-colors inline-flex items-center gap-2"
          >
            <span>Explore Available Hens (Rs. 500)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
