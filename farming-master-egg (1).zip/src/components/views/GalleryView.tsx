import React, { useState } from 'react';
import { Camera, Eye, MapPin } from 'lucide-react';

export const GalleryView: React.FC = () => {
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);

  const photos = [
    {
      url: '/src/assets/images/hero_poultry_farm_1793810684299.jpg',
      title: 'Panoramic View of Mandra Farm & Pastures',
      caption: '3 high-capacity commercial layer houses situated within green rolling foothills in Punjab, Pakistan.',
      category: 'Farm Grounds',
    },
    {
      url: '/src/assets/images/layer_hens_close_1793810684205.jpg',
      title: 'Rhode Island Red & Golden Misri Layers',
      caption: 'Healthy adult hens feeding at clean galvanized automated troughs with organic feed ration.',
      category: 'Flock Health',
    },
    {
      url: '/src/assets/images/fresh_farm_eggs_1793810684885.jpg',
      title: 'Freshly Harvested Grade-A Brown Eggs',
      caption: 'Natural brown eggs sorted into 30-egg fiber trays awaiting wholesale market dispatch.',
      category: 'Produce Quality',
    },
    {
      url: '/src/assets/images/farm_shed_interior_1793810685931.jpg',
      title: 'Automated Tunnel-Ventilated Shed Interior',
      caption: 'Pristine pine shaving bedding, stainless steel nipple waterers, and climate-regulated ceiling airflow.',
      category: 'Infrastructure',
    },
    {
      url: '/src/assets/images/veterinary_care_1793810685937.jpg',
      title: 'Clinical Veterinary Examination',
      caption: 'Resident poultry veterinarian Dr. Yasir conducting weekly physical checks on laying pullets.',
      category: 'Veterinary Welfare',
    },
  ];

  return (
    <div className="py-12 bg-stone-50/70 min-h-screen">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        <div className="text-center space-y-3 max-w-xl mx-auto">
          <div className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
            Authentic Visual Proof
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold font-display text-emerald-950 tracking-tight">
            Farm Photo Gallery
          </h1>
          <p className="text-sm text-stone-600 leading-relaxed">
            Real photography from our active poultry facility in Punjab. No stock renderings or fabricated environments.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {photos.map((photo, i) => (
            <div
              key={photo.url}
              onClick={() => setSelectedPhoto(photo.url)}
              className="bg-white rounded-xl border border-emerald-950/10 overflow-hidden shadow-xs hover:border-emerald-700/40 transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div className="relative aspect-4/3 bg-stone-100 overflow-hidden">
                <img
                  src={photo.url}
                  alt={photo.title}
                  className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-2 left-2 bg-emerald-950/80 backdrop-blur-xs text-white text-[11px] font-medium px-2 py-0.5 rounded">
                  {photo.category}
                </div>
              </div>

              <div className="p-4 space-y-1">
                <h3 className="font-bold text-sm text-emerald-950 font-display">
                  {photo.title}
                </h3>
                <p className="text-xs text-stone-600 leading-relaxed">
                  {photo.caption}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Modal for Enlarged Photo */}
        {selectedPhoto && (
          <div
            onClick={() => setSelectedPhoto(null)}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 cursor-pointer"
          >
            <div className="max-w-4xl max-h-[90vh] bg-stone-900 rounded-xl overflow-hidden p-2">
              <img
                src={selectedPhoto}
                alt="Enlarged farm view"
                className="max-h-[80vh] w-auto mx-auto object-contain rounded-lg"
                referrerPolicy="no-referrer"
              />
              <p className="text-center text-xs text-stone-300 pt-2">Click anywhere to close</p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
