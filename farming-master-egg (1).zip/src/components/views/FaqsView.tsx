import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ChevronDown, ChevronUp, HelpCircle, ArrowRight } from 'lucide-react';

export const FaqsView: React.FC = () => {
  const { setActiveView } = useApp();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Are profits or returns guaranteed?',
      a: 'NO. Under no circumstances do we promise, advertise, or guarantee a fixed daily, weekly, or monthly return. Farming Master Egg is an authentic agricultural business. Livestock biology, seasonal molting phases, egg yield fluctuations, and wholesale market price shifts mean distributions vary each month. In periods of high feed costs or flock molting, net distributions may be minimal or zero.'
    },
    {
      q: 'What happens if one of my physical hens dies?',
      a: 'Physical mortality is a natural reality of commercial poultry farming. Under Clause 4.2 of our signed Hen Ownership and Farm-Care Custody Agreement, if a customer-owned hen dies due to documented natural causes within the first 60 days of custody, the Farm provides one (1) replacement layer hen from the active flock, verified by Dr. Yasir’s veterinary autopsy log. After 60 days, deceased birds are retired and logged honestly.'
    },
    {
      q: 'Why is the initial listed price Rs. 500 per hen?',
      a: 'Rs. 500 represents the actual cost of acquiring or brooding a high-yield point-of-lay pullet (20–24 weeks of age) that has received full Marek, Newcastle (ND), and Gumboro (IBD) vaccinations. It covers the physical bird itself.'
    },
    {
      q: 'How are feed and care costs deducted?',
      a: 'Because hens are housed in flock-level sheds where communal automated augers distribute feed, individual bird feed measuring is impractical. Operating costs (feed mash, electricity, labor, medicine) are pooled at the shed level and deducted proportionately from gross egg sales according to your percentage of hens in the active laying flock.'
    },
    {
      q: 'Can I physically visit the farm to inspect my hens?',
      a: 'Yes, absolutely. Physical transparency is our core ethos. Customers may visit our Mandra-Chakwal farm during visiting hours (Tuesday & Saturday, 10:00 AM – 03:00 PM) with 48 hours prior notice. To safeguard our flock from avian pathogens, all visitors must step through our Virkon S biosecurity footbaths and wear provided sterile protective suits.'
    },
    {
      q: 'Can I choose to bring my hens to my own home?',
      a: 'Yes. You hold legal title to your hens. With 7 days written notice, you may take physical custody of your tagged hens from our Mandra facility, at which point the farm custody contract and egg allocation terminate.'
    },
    {
      q: 'How does withdrawal of accumulated funds work?',
      a: 'Whenever your withdrawable balance exceeds Rs. 1,000, you can submit a withdrawal request from your Customer Dashboard. We disburse via Easypaisa, JazzCash, or bank transfer (Meezan Bank / any 1-Link bank in Pakistan) following a manual review to protect your funds.'
    },
    {
      q: 'Is this business model Halal (Shariah-compliant)?',
      a: 'Yes. The structure is based on classic Islamic commercial principles: Bai (direct sale/purchase of a physical asset) coupled with Ijarah / Wakalah bil Ujrah (bailment and agency for agricultural care custody, where the farm earns a transparent service fee from actual net proceeds). There is no guaranteed interest (Riba) or speculative gambling (Gharar).'
    }
  ];

  return (
    <div className="py-12 bg-stone-50/70 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        <div className="text-center space-y-3 max-w-xl mx-auto">
          <div className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
            Clear Honest Answers
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold font-display text-emerald-950 tracking-tight">
            Frequently Asked Questions
          </h1>
          <p className="text-sm text-stone-600 leading-relaxed">
            Everything you need to know about physical hen custody, egg allocation, veterinary welfare, and operational realities.
          </p>
        </div>

        {/* Accordion FAQ list */}
        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={faq.q}
                className="bg-white rounded-xl border border-emerald-950/10 overflow-hidden shadow-xs transition-colors"
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 focus:outline-hidden hover:bg-stone-50/50"
                >
                  <span className="font-bold text-sm text-emerald-950 font-display">
                    {faq.q}
                  </span>
                  <div className="text-emerald-800 shrink-0">
                    {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs text-stone-600 leading-relaxed border-t border-stone-100">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still have questions */}
        <div className="bg-emerald-950 text-white p-8 rounded-2xl text-center space-y-4 shadow-xs">
          <h3 className="text-xl font-bold font-display text-white">
            Have a question not addressed here?
          </h3>
          <p className="text-xs text-emerald-200 max-w-md mx-auto">
            Our agricultural team and farm manager Tariq Mahmood are available via WhatsApp or telephone during farm operating hours.
          </p>
          <button
            onClick={() => setActiveView('contact')}
            className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold text-xs rounded-lg transition-colors inline-flex items-center gap-2"
          >
            <span>Contact Farm Management</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
