import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { FileText, ShieldAlert, Lock, CheckSquare, Printer } from 'lucide-react';

export const LegalAgreementView: React.FC = () => {
  const [activeDoc, setActiveDoc] = useState<'agreement' | 'risk' | 'terms' | 'privacy'>('agreement');

  return (
    <div className="py-12 bg-stone-50/70 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Navigation Selector */}
        <div className="flex items-center justify-between flex-wrap gap-4 pb-4 border-b border-stone-200">
          <div>
            <span className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
              Legal Center & Compliance
            </span>
            <h1 className="text-2xl sm:text-3xl font-bold font-display text-emerald-950">
              Contractual Agreements & Disclosures
            </h1>
          </div>

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-semibold text-stone-700 hover:bg-stone-50 shadow-2xs"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Legal Document</span>
          </button>
        </div>

        {/* Document Tabs */}
        <div className="flex items-center gap-1 p-1 bg-stone-200/70 rounded-xl overflow-x-auto text-xs font-medium">
          <button
            onClick={() => setActiveDoc('agreement')}
            className={`px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeDoc === 'agreement' ? 'bg-white text-emerald-950 font-bold shadow-xs' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Hen Ownership & Care Agreement
          </button>
          <button
            onClick={() => setActiveDoc('risk')}
            className={`px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeDoc === 'risk' ? 'bg-white text-emerald-950 font-bold shadow-xs' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Agricultural Risk Disclosure
          </button>
          <button
            onClick={() => setActiveDoc('terms')}
            className={`px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeDoc === 'terms' ? 'bg-white text-emerald-950 font-bold shadow-xs' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Platform Terms & Conditions
          </button>
          <button
            onClick={() => setActiveDoc('privacy')}
            className={`px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeDoc === 'privacy' ? 'bg-white text-emerald-950 font-bold shadow-xs' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Privacy Policy
          </button>
        </div>

        {/* DOCUMENT 1: Hen Ownership and Farm-Care Agreement */}
        {activeDoc === 'agreement' && (
          <div className="bg-white p-8 rounded-2xl border border-emerald-950/10 shadow-xs space-y-6 text-xs text-stone-700 leading-relaxed">
            <div className="border-b border-stone-200 pb-4 text-center space-y-1">
              <h2 className="text-xl font-bold font-display text-emerald-950">
                HEN OWNERSHIP AND FARM-CARE CUSTODY AGREEMENT
              </h2>
              <div className="text-stone-500 font-mono text-[11px]">Standard Commercial Form FME-AGR-2026</div>
            </div>

            <section className="space-y-2">
              <h3 className="font-bold text-sm text-emerald-950 font-display">1. PARTIES & PREAMBLE</h3>
              <p>
                This Agreement is entered into between <strong>Farming Master Egg Agro Enterprises</strong> ("the Farm" or "Custodian"), operating at Mandra-Chakwal Highway, Punjab, Pakistan, and the registered individual ("the Owner") acquiring physical layer poultry assets.
              </p>
              <p>
                WHEREAS the Owner desires to purchase actual, living layer hens and commit them to the physical custody, husbandry, and commercial bailment of the Farm; and the Farm agrees to provide commercial housing, nutrition, health management, and wholesale egg marketing on the terms set forth herein.
              </p>
            </section>

            <section className="space-y-2">
              <h3 className="font-bold text-sm text-emerald-950 font-display">2. TITLE OF OWNERSHIP & PHYSICAL TAG IDENTIFICATION</h3>
              <p>
                2.1 Upon payment of the fixed acquisition sum of Rs. 500 per hen, legal ownership and title of the designated hen(s) vests directly in the Owner.<br />
                2.2 Each hen is permanently tagged with a verifiable numeric wing or leg band code registered in the farm physical ledger.<br />
                2.3 This transaction constitutes a genuine sale of tangible livestock and is not a financial deposit, debenture, or pool investment.
              </p>
            </section>

            <section className="space-y-2">
              <h3 className="font-bold text-sm text-emerald-950 font-display">3. CARE, FEEDING & BIOSECURITY OBLIGATIONS</h3>
              <p>
                3.1 The Farm shall house the flock in modern, climate-monitored sheds maintaining appropriate ambient temperature, continuous clean nipple water, and 16% Crude Protein balanced layer mash.<br />
                3.2 Routine biosecurity disinfections and certified vaccinations (Marek, ND, IBD) shall be administered by a licensed Doctor of Veterinary Medicine (DVM).<br />
                3.3 The Owner acknowledges that hens are reared in communal commercial flocks where individual feed intake tracking is operationally infeasible.
              </p>
            </section>

            <section className="space-y-2">
              <h3 className="font-bold text-sm text-emerald-950 font-display">4. EGG HARVEST, OPERATIONAL EXPENSES & ACCOUNTING</h3>
              <p>
                4.1 All eggs laid by the active flock are collected twice daily, graded, and sold wholesale at prevailing market mandi rates.<br />
                4.2 Validated operating expenses directly incurred by the flock (feed procurement, electrical power, veterinary care, and sorting labor) are deducted from gross egg revenue.<br />
                4.3 Net proceeds are allocated strictly in proportion to the Owner’s active hen holdings.<br />
                4.4 The Farm shall retain a 10% Farm Custody Fee deducted only from net positive distributions. No custody fee is collected in break-even or negative periods.
              </p>
            </section>

            <section className="space-y-2">
              <h3 className="font-bold text-sm text-emerald-950 font-display">5. MORTALITY, MOLTING & REPLACEMENT POLICY</h3>
              <p>
                5.1 In the event of natural mortality within sixty (60) days of acquisition, verified by veterinary post-mortem, the Farm shall provide one (1) replacement layer hen from the active flock at zero additional cost to the Owner.<br />
                5.2 Seasonal feather molting (typically lasting 4 to 8 weeks) is a recognized physiological cycle during which egg production drops naturally; this does not constitute default or breach.
              </p>
            </section>

            <section className="space-y-2">
              <h3 className="font-bold text-sm text-emerald-950 font-display">6. PHYSICAL INSPECTION & TERMINATION</h3>
              <p>
                6.1 The Owner reserves the right to physically inspect the farm and their designated flock upon 48 hours prior notice, subject to Level-2 biosecurity entry rules.<br />
                6.2 The Owner may terminate custody and take physical delivery of their hens from the farm premises upon 7 days written notice.
              </p>
            </section>
          </div>
        )}

        {/* DOCUMENT 2: Agricultural Risk Disclosure */}
        {activeDoc === 'risk' && (
          <div className="bg-white p-8 rounded-2xl border border-emerald-950/10 shadow-xs space-y-6 text-xs text-stone-700 leading-relaxed">
            <div className="border-b border-stone-200 pb-4 text-center space-y-1">
              <h2 className="text-xl font-bold font-display text-emerald-950 flex items-center justify-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-600" />
                <span>AGRICULTURAL RISK DISCLOSURE STATEMENT</span>
              </h2>
              <div className="text-stone-500 font-mono text-[11px]">Mandatory Pre-Acquisition Disclosure</div>
            </div>

            <p className="font-semibold text-stone-900">
              Please read this document carefully before acquiring physical poultry assets. Livestock ownership entails biological and market risks that differ fundamentally from banking or fixed instruments.
            </p>

            <div className="space-y-3">
              <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 space-y-1">
                <h4 className="font-bold text-amber-950">1. Biological & Seasonal Production Variance</h4>
                <p className="text-amber-900 text-[11px]">
                  Laying rates vary based on bird age, humidity, heat peaks in Punjab summers, and natural molting cycles. Laying percentages may drop from 88% down to 40% during transition intervals.
                </p>
              </div>

              <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 space-y-1">
                <h4 className="font-bold text-amber-950">2. Feed Price Inflation</h4>
                <p className="text-amber-900 text-[11px]">
                  Poultry feed constitutes approximately 65% of monthly flock operating costs. Significant spikes in domestic or international grain prices (corn, soybean meal) directly elevate operating deductions and decrease net distributions.
                </p>
              </div>

              <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 space-y-1">
                <h4 className="font-bold text-amber-950">3. Wholesale Egg Market Volatility</h4>
                <p className="text-amber-900 text-[11px]">
                  Egg mandi rates are dictated by national supply and demand. Rates in Rawalpindi/Islamabad fluctuate between Rs. 12.00 and Rs. 16.50 per egg depending on season and school calendars.
                </p>
              </div>

              <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 space-y-1">
                <h4 className="font-bold text-amber-950">4. Disease & Mortality Realities</h4>
                <p className="text-amber-900 text-[11px]">
                  Despite comprehensive vaccination and biosecurity, poultry flocks are susceptible to endemic avian diseases. Natural attrition occurs and is recorded truthfully.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* DOCUMENT 3: Terms & Conditions */}
        {activeDoc === 'terms' && (
          <div className="bg-white p-8 rounded-2xl border border-emerald-950/10 shadow-xs space-y-4 text-xs text-stone-700 leading-relaxed">
            <h2 className="text-xl font-bold font-display text-emerald-950 pb-3 border-b border-stone-200">
              Platform Terms & Conditions
            </h2>
            <p>
              By creating an account or purchasing hens on Farming Master Egg, you confirm that you are at least 18 years of age and legally capable of entering into binding agricultural contracts under Pakistani law.
            </p>
            <p>
              All payments must be remitted through authorized banking channels (Easypaisa, JazzCash, or State Bank regulated commercial banks). You agree to provide accurate CNIC and identity information for livestock registration records.
            </p>
            <p>
              Attempting to solicit other users, advertise Ponzi schemes, misrepresent returns, or manipulate farm ledgers will result in immediate account termination.
            </p>
          </div>
        )}

        {/* DOCUMENT 4: Privacy Policy */}
        {activeDoc === 'privacy' && (
          <div className="bg-white p-8 rounded-2xl border border-emerald-950/10 shadow-xs space-y-4 text-xs text-stone-700 leading-relaxed">
            <h2 className="text-xl font-bold font-display text-emerald-950 pb-3 border-b border-stone-200">
              Customer Privacy Policy
            </h2>
            <p>
              Farming Master Egg values your privacy. We collect personal identification details (name, mobile number, CNIC, and banking details) solely for agricultural ownership title generation, bailment certificates, and withdrawal processing.
            </p>
            <p>
              Under our Row Level Security (RLS) data architecture, customers can never access other customers' private financial statements, bank accounts, or phone numbers.
            </p>
            <p>
              We never sell or distribute your contact details to third-party marketing companies.
            </p>
          </div>
        )}

      </div>
    </div>
  );
};
