import React from 'react';
import { useApp } from '../../context/AppContext';
import { MapPin, ShieldCheck, HeartHandshake, Award, CheckCircle, ArrowRight } from 'lucide-react';

export const AboutFarmView: React.FC = () => {
  const { setActiveView } = useApp();

  return (
    <div className="py-12 bg-stone-50/70 min-h-screen">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Hero Banner */}
        <div className="relative rounded-2xl overflow-hidden shadow-md">
          <img
            src="/src/assets/images/farm_shed_interior_1793810685931.jpg"
            alt="Farming Master Egg commercial poultry house"
            className="w-full h-72 sm:h-96 object-cover filter brightness-90"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/90 via-emerald-950/50 to-transparent" />
          <div className="absolute bottom-6 left-6 right-6 text-white space-y-2">
            <span className="text-xs uppercase tracking-widest text-emerald-300 font-bold">
              Established 2024 · Punjab Poultry Belt
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold font-display tracking-tight text-white">
              About Farming Master Egg
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100 max-w-2xl leading-relaxed">
              Pioneering transparent, ethical poultry layer custody in Pakistan. Combining scientific housing, strict Level-2 biosecurity, and verifiable customer bailment records.
            </p>
          </div>
        </div>

        {/* Narrative & Values */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <div className="lg:col-span-2 bg-white rounded-xl border border-emerald-950/10 p-8 shadow-xs space-y-6">
            <div className="space-y-3">
              <h2 className="text-2xl font-bold font-display text-emerald-950">
                Our Physical Farm Mission
              </h2>
              <p className="text-sm text-stone-700 leading-relaxed">
                Founded along the Mandra-Chakwal poultry corridor in Punjab, Farming Master Egg was created to bridge urban agricultural enthusiasts with actual productive poultry assets. Many citizens wish to participate in livestock farming but lack rural land, housing infrastructure, daily labor, and wholesale distribution connections.
              </p>
              <p className="text-sm text-stone-700 leading-relaxed">
                We bridge this gap through a strictly documented care and custody contract. You acquire legal title to physical layer hens at a fixed price of Rs. 500 each, and our dedicated team of farm hands, veterinarians, and poultry technicians maintain them with industry-leading animal welfare and feed efficiency.
              </p>
            </div>

            <div className="pt-4 border-t border-stone-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 bg-stone-50 rounded-xl space-y-1">
                <span className="text-xs font-bold text-emerald-950">Level-2 Biosecurity Standards</span>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Vehicle disinfection wheel dips, footbaths with Virkon S, and complete quarantine protocols prevent external pathogen entry.
                </p>
              </div>

              <div className="p-4 bg-stone-50 rounded-xl space-y-1">
                <span className="text-xs font-bold text-emerald-950">Veterinary Regulated Welfare</span>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Licensed Doctor of Veterinary Medicine (DVM) oversees Marek, Newcastle (ND), and Gumboro (IBD) vaccination protocols.
                </p>
              </div>
            </div>
          </div>

          {/* Right Col: Farm Specifications */}
          <div className="bg-emerald-950 text-white rounded-xl p-6 shadow-xs space-y-5">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Facility Specs</span>
            </div>

            <h3 className="text-lg font-bold font-display text-white">
              Farm Location & Asset Data
            </h3>

            <div className="space-y-3 text-xs text-emerald-200">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Mandra-Chakwal Road, District Chakwal, Punjab, Pakistan</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-emerald-900">
                <span className="text-emerald-300">Total Land Area:</span>
                <span className="font-semibold text-white">4.5 Acres</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-emerald-900">
                <span className="text-emerald-300">Active Commercial Sheds:</span>
                <span className="font-semibold text-white">3 High-Cap Barns</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-emerald-900">
                <span className="text-emerald-300">Total Hen Capacity:</span>
                <span className="font-semibold text-white">6,000 Birds</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-emerald-900">
                <span className="text-emerald-300">Backup Solar Grid:</span>
                <span className="font-semibold text-white">25 kW Hybrid System</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-emerald-300">Wholesale Market Hub:</span>
                <span className="font-semibold text-white">Rawalpindi & Islamabad</span>
              </div>
            </div>

            <button
              onClick={() => setActiveView('contact')}
              className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white font-semibold text-xs rounded-lg transition-colors text-center"
            >
              Schedule an On-Site Farm Visit
            </button>
          </div>

        </div>

        {/* Dedicated Team Section */}
        <div className="bg-white rounded-xl border border-emerald-950/10 p-8 shadow-xs space-y-6">
          <h2 className="text-2xl font-bold font-display text-emerald-950">
            Farm Management & Veterinary Oversight
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <div className="p-4 bg-stone-50 rounded-xl border border-stone-200/80 flex items-start gap-4">
              <div className="w-14 h-14 rounded-full bg-emerald-800 text-white flex items-center justify-center font-bold text-lg font-display shrink-0">
                TM
              </div>
              <div className="space-y-1 text-xs">
                <div className="font-bold text-sm text-emerald-950">Tariq Mahmood</div>
                <div className="text-emerald-800 font-medium">Farm Manager & Operational Custodian</div>
                <p className="text-stone-600 leading-relaxed pt-1">
                  Over 16 years of hands-on commercial poultry layer flock management across Punjab and KPK. Specializes in feed formulation and climate-controlled ventilation dynamics.
                </p>
              </div>
            </div>

            <div className="p-4 bg-stone-50 rounded-xl border border-stone-200/80 flex items-start gap-4">
              <div className="w-14 h-14 rounded-full bg-emerald-700 text-white flex items-center justify-center font-bold text-lg font-display shrink-0">
                MY
              </div>
              <div className="space-y-1 text-xs">
                <div className="font-bold text-sm text-emerald-950">Dr. Muhammad Yasir, DVM</div>
                <div className="text-emerald-800 font-medium">Resident Poultry Veterinarian</div>
                <p className="text-stone-600 leading-relaxed pt-1">
                  Graduate of University of Veterinary and Animal Sciences (UVAS) Lahore. Directly audits biosecurity, conducts flock autopsies, and certifies mandatory vaccine compliance.
                </p>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
