import React from 'react';
import { useApp } from '../../context/AppContext';
import { Activity, ShieldCheck, TrendingDown, TrendingUp, AlertTriangle, FileText, CheckCircle2 } from 'lucide-react';

export const TransparencyView: React.FC = () => {
  const { productionRecords, eggSales, expenses, financialCycles } = useApp();

  return (
    <div className="py-12 bg-stone-50/70 min-h-screen">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
            Unfiltered Agricultural Ledger
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold font-display text-emerald-950 tracking-tight">
            Farm Transparency & Production Reports
          </h1>
          <p className="text-sm text-stone-600 leading-relaxed">
            Honest reporting of our actual flock performance, verified feed expenses, wholesale mandi prices, and mortality numbers.
          </p>
        </div>

        {/* 4 Transparency Truth Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-xl border border-emerald-950/10 shadow-xs space-y-1.5">
            <span className="text-xs text-stone-500">Average Flock Laying %</span>
            <div className="text-2xl font-bold font-display text-emerald-950 font-mono tabular-nums">84.6%</div>
            <p className="text-[11px] text-stone-500">Fluctuates with ambient season & molt cycles</p>
          </div>

          <div className="bg-white p-5 rounded-xl border border-emerald-950/10 shadow-xs space-y-1.5">
            <span className="text-xs text-stone-500">Current Wholesale Mandi Rate</span>
            <div className="text-2xl font-bold font-display text-emerald-950 font-mono tabular-nums">Rs. 14.75 / egg</div>
            <p className="text-[11px] text-stone-500">Rs. 442.50 per 30-egg tray in Rawalpindi Mandi</p>
          </div>

          <div className="bg-white p-5 rounded-xl border border-emerald-950/10 shadow-xs space-y-1.5">
            <span className="text-xs text-stone-500">Monthly Mortality Rate</span>
            <div className="text-2xl font-bold font-display text-stone-800 font-mono tabular-nums">0.62%</div>
            <p className="text-[11px] text-stone-500">Well below commercial threshold of 1.2%</p>
          </div>

          <div className="bg-white p-5 rounded-xl border border-emerald-950/10 shadow-xs space-y-1.5">
            <span className="text-xs text-stone-500">Feed Conversion Ratio</span>
            <div className="text-2xl font-bold font-display text-emerald-950 font-mono tabular-nums">2.18 kg / doz</div>
            <p className="text-[11px] text-stone-500">Feed constitutes ~64% of total farm costs</p>
          </div>
        </div>

        {/* Cost Structure Breakdown */}
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-emerald-950/10 shadow-xs space-y-6">
          <div className="space-y-1">
            <h3 className="text-xl font-bold font-display text-emerald-950">
              Where Operating Expenses Go
            </h3>
            <p className="text-xs text-stone-500">
              Every rupee deducted from customer gross egg revenue corresponds to verifiable physical operational expenditures.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            
            {/* Visual Bars */}
            <div className="space-y-4 text-xs font-medium">
              <div>
                <div className="flex justify-between pb-1 text-stone-700">
                  <span>Layer Feed & Mineral Premix (Corn, Soy, DCP, Calcium)</span>
                  <span className="font-mono font-bold">64.5%</span>
                </div>
                <div className="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden">
                  <div className="bg-emerald-800 h-full rounded-full" style={{ width: '64.5%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between pb-1 text-stone-700">
                  <span>Farm Hands, Sweepers & Egg Sorting Labor</span>
                  <span className="font-mono font-bold">15.2%</span>
                </div>
                <div className="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden">
                  <div className="bg-emerald-600 h-full rounded-full" style={{ width: '15.2%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between pb-1 text-stone-700">
                  <span>Electricity, Backup Generator Diesel & Solar Maintenance</span>
                  <span className="font-mono font-bold">11.8%</span>
                </div>
                <div className="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden">
                  <div className="bg-amber-600 h-full rounded-full" style={{ width: '11.8%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between pb-1 text-stone-700">
                  <span>Veterinary Vaccines, Virkon Disinfectants & Lab Assays</span>
                  <span className="font-mono font-bold">5.4%</span>
                </div>
                <div className="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden">
                  <div className="bg-blue-600 h-full rounded-full" style={{ width: '5.4%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between pb-1 text-stone-700">
                  <span>Crates, Bedding Shavings & Mandi Transport</span>
                  <span className="font-mono font-bold">3.1%</span>
                </div>
                <div className="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden">
                  <div className="bg-stone-500 h-full rounded-full" style={{ width: '3.1%' }} />
                </div>
              </div>
            </div>

            {/* Explanatory Note */}
            <div className="p-5 bg-stone-50 rounded-xl border border-stone-200 space-y-3 text-xs leading-relaxed text-stone-700">
              <h4 className="font-bold text-emerald-950 font-display">Zero Hidden Markups</h4>
              <p>
                We do not inflate feed costs or bill ghost items. All feed procurement is handled through bulk wholesale agreements with recognized manufacturers (such as National Feeds, Punjab Feeds). 
              </p>
              <p>
                Farming Master Egg charges only a fixed <strong className="text-emerald-900 font-semibold">10% farm custody management fee</strong> deducted exclusively from net positive revenue. If a seasonal molt or feed price spike results in zero net gain, zero custody fee is collected.
              </p>
            </div>

          </div>
        </div>

        {/* Live Wholesale Sales Log Table */}
        <div className="bg-white rounded-2xl border border-emerald-950/10 shadow-xs overflow-hidden">
          <div className="p-4 bg-stone-50 border-b border-stone-200 flex items-center justify-between text-xs font-semibold text-stone-700">
            <span>Recent Commercial Wholesale Egg Mandi Invoices</span>
            <span className="text-stone-500">Publicly Audited</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-sans font-semibold bg-stone-50/50">
                  <th className="p-3">Invoice</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Quantity</th>
                  <th className="p-3">Mandi Rate</th>
                  <th className="p-3">Gross Revenue</th>
                  <th className="p-3">Wholesale Buyer</th>
                  <th className="p-3">Market Destination</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {eggSales.map(sale => (
                  <tr key={sale.id} className="hover:bg-stone-50">
                    <td className="p-3 font-bold text-emerald-950">{sale.invoiceNumber}</td>
                    <td className="p-3 font-sans text-stone-700">{sale.date}</td>
                    <td className="p-3 text-stone-900 font-bold">{sale.quantityEggs.toLocaleString()}</td>
                    <td className="p-3 text-stone-800">Rs. {sale.ratePerEgg}</td>
                    <td className="p-3 font-bold text-emerald-900">Rs. {sale.grossAmount.toLocaleString()}</td>
                    <td className="p-3 font-sans text-stone-800">{sale.buyerName}</td>
                    <td className="p-3 font-sans text-stone-600">{sale.marketLocation}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
};
