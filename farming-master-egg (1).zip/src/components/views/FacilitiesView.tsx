import React from 'react';
import { useApp } from '../../context/AppContext';
import { Wind, Thermometer, Droplets, Egg, CheckCircle2 } from 'lucide-react';

export const FacilitiesView: React.FC = () => {
  const { sheds, setActiveView } = useApp();

  return (
    <div className="py-12 bg-stone-50/70 min-h-screen">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
            Poultry Engineering & Welfare Architecture
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold font-display text-emerald-950 tracking-tight">
            Our Poultry Sheds & Infrastructure
          </h1>
          <p className="text-sm text-stone-600 leading-relaxed">
            Constructed with advanced thermal insulation, tunnel evaporative cooling, and automated feeding to maintain peak layer flock health throughout Punjab's seasonal weather extremes.
          </p>
        </div>

        {/* Sheds Deep Dive Grid */}
        <div className="space-y-6">
          {sheds.map(shed => (
            <div
              key={shed.id}
              className="bg-white rounded-2xl border border-emerald-950/10 p-6 sm:p-8 shadow-xs flex flex-col lg:flex-row gap-8 items-start"
            >
              <div className="w-full lg:w-2/5 aspect-16/10 rounded-xl overflow-hidden bg-stone-100 shrink-0">
                <img
                  src="/src/assets/images/farm_shed_interior_1793810685931.jpg"
                  alt={shed.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="space-y-4 flex-1">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-stone-100">
                  <div>
                    <span className="font-mono text-xs font-bold text-emerald-800">{shed.code}</span>
                    <h3 className="text-xl font-bold font-display text-emerald-950">{shed.name}</h3>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-stone-500 block">Bird Capacity</span>
                    <span className="font-mono font-bold text-emerald-950 text-base">{shed.currentHens} / {shed.capacity}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-stone-50 rounded-lg">
                    <div className="flex items-center gap-1.5 text-stone-500 text-[11px] mb-1">
                      <Thermometer className="w-3.5 h-3.5 text-amber-600" />
                      <span>Temperature</span>
                    </div>
                    <span className="font-bold text-emerald-950 font-mono">{shed.temperatureC}°C</span>
                  </div>

                  <div className="p-3 bg-stone-50 rounded-lg">
                    <div className="flex items-center gap-1.5 text-stone-500 text-[11px] mb-1">
                      <Droplets className="w-3.5 h-3.5 text-blue-600" />
                      <span>Humidity</span>
                    </div>
                    <span className="font-bold text-emerald-950 font-mono">{shed.humidityPct}%</span>
                  </div>

                  <div className="p-3 bg-stone-50 rounded-lg col-span-2">
                    <div className="flex items-center gap-1.5 text-stone-500 text-[11px] mb-1">
                      <Wind className="w-3.5 h-3.5 text-emerald-700" />
                      <span>Ventilation</span>
                    </div>
                    <span className="text-stone-800 text-[11px] font-medium">{shed.ventilation}</span>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs text-stone-600">
                  <div><strong>Feeding Mechanism:</strong> {shed.feedingSystem}</div>
                  <div><strong>Water Lines:</strong> {shed.drinkingSystem}</div>
                  <div><strong>Sanitation:</strong> Weekly litter raking, dry hydrated lime spreading, and antimicrobial spray.</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Biosecurity & Egg Grading Protocol */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-xl border border-emerald-950/10 shadow-xs space-y-3">
            <h3 className="text-base font-bold text-emerald-950 font-display flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700" />
              <span>Egg Grading & Packing Protocol</span>
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Eggs are gathered from roll-out laying boxes twice daily. Every single egg is candled over LED lamps to detect microscopic hairline fractures, weighed to classify into Grade-A (58g+), medium, or small, and packed in sanitized 30-egg pulp trays for wholesale dispatch.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-emerald-950/10 shadow-xs space-y-3">
            <h3 className="text-base font-bold text-emerald-950 font-display flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700" />
              <span>Feed Quality & Lab Assays</span>
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              We never use unregulated kitchen waste. Flocks receive precision-milled Layer Mash formulated with yellow corn, soybean meal, canola meal, dicalcium phosphate (DCP), methionine, and limestone grit to guarantee resilient eggshell thickness and vibrant yolk pigmentation.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
};
