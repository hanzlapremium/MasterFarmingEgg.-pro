import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Search, Filter, ShieldCheck, HeartPulse, Check, ArrowRight, Info, AlertTriangle } from 'lucide-react';
import { Hen } from '../types';

export const Marketplace: React.FC = () => {
  const { hens, sheds, setPurchaseModalOpen } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBreed, setSelectedBreed] = useState<string>('all');
  const [selectedShed, setSelectedShed] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('available');
  const [orderQuantity, setOrderQuantity] = useState<number>(2);

  const breeds = useMemo(() => {
    const list = Array.from(new Set(hens.map(h => h.breed)));
    return ['all', ...list];
  }, [hens]);

  const filteredHens = useMemo(() => {
    return hens.filter(hen => {
      const matchesSearch = hen.tagCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
        hen.breed.toLowerCase().includes(searchQuery.toLowerCase()) ||
        hen.shedName.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesBreed = selectedBreed === 'all' || hen.breed === selectedBreed;
      const matchesShed = selectedShed === 'all' || hen.shedId === selectedShed;
      const matchesStatus = selectedStatus === 'all' || hen.status === selectedStatus;

      return matchesSearch && matchesBreed && matchesShed && matchesStatus;
    });
  }, [hens, searchQuery, selectedBreed, selectedShed, selectedStatus]);

  const availableCount = hens.filter(h => h.status === 'available').length;
  const totalPrice = orderQuantity * 500;

  return (
    <section className="py-12 bg-stone-50/60 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Header & Intro */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-emerald-950/10">
          <div className="space-y-2 max-w-2xl">
            <div className="text-xs font-semibold uppercase tracking-wider text-emerald-800">
              Live Farm Registry · Verified Physical Inventory
            </div>
            <h2 className="text-3xl font-bold font-display text-emerald-950 tracking-tight">
              Physical Hen Catalog & Custody
            </h2>
            <p className="text-sm text-stone-600 leading-relaxed">
              Every listed hen is an actual physical layer bird with an individual wing/leg band tag residing at our Punjab poultry sheds. 
              The initial price is strictly <strong className="text-emerald-900 font-semibold">Rs. 500 per hen</strong>.
            </p>
          </div>

          {/* Quick Purchase Box */}
          <div className="bg-white p-4 rounded-xl border border-emerald-950/10 shadow-xs space-y-3 w-full md:w-80 shrink-0">
            <div className="flex items-center justify-between">
              <span className="text-xs text-stone-500">Fixed Acquisition Price</span>
              <span className="text-lg font-bold text-emerald-900 font-mono tabular-nums">Rs. 500 / hen</span>
            </div>

            <div className="flex items-center gap-3">
              <label htmlFor="hen-qty-select" className="text-xs font-medium text-stone-700">Quantity:</label>
              <div className="flex items-center gap-1">
                {[1, 2, 4, 10].map(qty => (
                  <button
                    key={qty}
                    onClick={() => setOrderQuantity(qty)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md border transition-colors ${
                      orderQuantity === qty
                        ? 'bg-emerald-800 text-white border-emerald-800'
                        : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                    }`}
                  >
                    {qty}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
              <span className="text-stone-600">Total Purchase:</span>
              <span className="font-bold text-emerald-950 text-sm font-mono tabular-nums">Rs. {totalPrice.toLocaleString()}</span>
            </div>

            <button
              onClick={() => setPurchaseModalOpen(true)}
              className="w-full py-2.5 px-4 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs"
            >
              <span>Acquire & Sign Agreement</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <p className="text-[11px] text-center text-stone-500">
              {availableCount} physical hens currently ready for custody
            </p>
          </div>
        </div>

        {/* Filter Controls (Segmented buttons & inputs per §1.A) */}
        <div className="bg-white p-4 rounded-xl border border-emerald-950/10 shadow-xs flex flex-wrap items-center justify-between gap-4">
          
          {/* Search bar */}
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by Hen ID, Breed or Shed..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-hidden focus:border-emerald-600 text-stone-800 placeholder-stone-400"
            />
          </div>

          {/* Availability Status Filter */}
          <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg">
            <button
              onClick={() => setSelectedStatus('available')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                selectedStatus === 'available'
                  ? 'bg-white text-emerald-950 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Available ({hens.filter(h => h.status === 'available').length})
            </button>
            <button
              onClick={() => setSelectedStatus('owned')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                selectedStatus === 'owned'
                  ? 'bg-white text-emerald-950 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Customer-Owned ({hens.filter(h => h.status === 'owned').length})
            </button>
            <button
              onClick={() => setSelectedStatus('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                selectedStatus === 'all'
                  ? 'bg-white text-emerald-950 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              All Flock ({hens.length})
            </button>
          </div>

          {/* Breed Dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500 whitespace-nowrap">Breed:</span>
            <select
              value={selectedBreed}
              onChange={e => setSelectedBreed(e.target.value)}
              aria-label="Filter by hen breed"
              className="px-2.5 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-700 focus:outline-hidden focus:border-emerald-600"
            >
              <option value="all">All Breeds</option>
              {breeds.filter(b => b !== 'all').map(b => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
          </div>

          {/* Shed Dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500 whitespace-nowrap">Shed:</span>
            <select
              value={selectedShed}
              onChange={e => setSelectedShed(e.target.value)}
              aria-label="Filter by farm shed"
              className="px-2.5 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-700 focus:outline-hidden focus:border-emerald-600"
            >
              <option value="all">All Sheds</option>
              {sheds.map(s => (
                <option key={s.id} value={s.id}>{s.name.split('-')[0]}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Hen Inventory Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredHens.map(hen => (
            <div
              key={hen.id}
              className="bg-white rounded-xl border border-emerald-950/10 shadow-xs overflow-hidden flex flex-col hover:border-emerald-700/30 transition-all group"
            >
              {/* Hen Photo with zero-broken-image fallback container */}
              <div className="relative aspect-4/3 bg-stone-100 overflow-hidden">
                <img
                  src={hen.photoUrl}
                  alt={`Hen tag ${hen.tagCode} (${hen.breed})`}
                  className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-2 left-2 bg-emerald-950/80 backdrop-blur-xs text-white text-[11px] font-mono px-2 py-0.5 rounded">
                  {hen.tagCode}
                </div>
                
                {hen.status === 'owned' ? (
                  <div className="absolute top-2 right-2 bg-amber-900/80 backdrop-blur-xs text-amber-200 text-[11px] font-medium px-2 py-0.5 rounded">
                    Owned
                  </div>
                ) : (
                  <div className="absolute top-2 right-2 bg-emerald-800/90 backdrop-blur-xs text-emerald-100 text-[11px] font-medium px-2 py-0.5 rounded">
                    Available
                  </div>
                )}
              </div>

              {/* Card Body */}
              <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-emerald-950 font-display">
                      {hen.breed}
                    </h3>
                    <span className="font-bold text-emerald-900 font-mono text-sm tabular-nums">
                      Rs. 500
                    </span>
                  </div>

                  {/* Clean unboxed metadata with typographic dot separators (§1.A) */}
                  <div className="flex items-center gap-1.5 text-xs text-stone-500 flex-wrap">
                    <span>{hen.ageWeeks} weeks</span>
                    <span aria-hidden="true">·</span>
                    <span>{hen.shedName.split('-')[0]}</span>
                    <span aria-hidden="true">·</span>
                    <span>Flock {hen.flockCode.split('-')[1]}</span>
                  </div>

                  {/* Health status descriptor */}
                  <div className="pt-1 flex items-center gap-1.5 text-xs">
                    {hen.healthStatus === 'healthy' && (
                      <span className="text-emerald-700 flex items-center gap-1 font-medium">
                        <Check className="w-3.5 h-3.5" /> Healthy Layer
                      </span>
                    )}
                    {hen.healthStatus === 'molting' && (
                      <span className="text-amber-700 flex items-center gap-1 font-medium">
                        <Info className="w-3.5 h-3.5" /> Seasonal Molting
                      </span>
                    )}
                    {hen.healthStatus === 'under_observation' && (
                      <span className="text-stone-600 flex items-center gap-1 font-medium">
                        <HeartPulse className="w-3.5 h-3.5" /> Under Vet Care
                      </span>
                    )}
                    {hen.healthStatus === 'mortality' && (
                      <span className="text-red-700 flex items-center gap-1 font-medium">
                        <AlertTriangle className="w-3.5 h-3.5" /> Deceased / Replaced
                      </span>
                    )}
                  </div>

                  {hen.notes && (
                    <p className="text-[11px] text-stone-500 line-clamp-2 leading-relaxed italic">
                      "{hen.notes}"
                    </p>
                  )}
                </div>

                {/* Card Action */}
                <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
                  <div className="text-stone-500 text-[11px]">
                    Avg yield: <span className="font-mono text-stone-800 font-medium">{(hen.dailyEggYieldAvg * 30).toFixed(0)} eggs/mo</span>
                  </div>

                  {hen.status === 'available' ? (
                    <button
                      onClick={() => {
                        setOrderQuantity(1);
                        setPurchaseModalOpen(true);
                      }}
                      className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-md font-semibold text-xs transition-colors"
                    >
                      Acquire
                    </button>
                  ) : (
                    <span className="text-stone-400 text-xs font-medium">
                      Owner: {hen.ownerName?.split(' ')[0] || 'Registered'}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredHens.length === 0 && (
          <div className="bg-white p-12 text-center rounded-xl border border-emerald-950/10 space-y-3">
            <Info className="w-8 h-8 text-stone-400 mx-auto" />
            <h3 className="text-base font-bold text-stone-800">No physical hens matched your criteria</h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              Try adjusting your search filters or check back after the farm manager logs new incoming layer batches.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedBreed('all');
                setSelectedShed('all');
                setSelectedStatus('all');
              }}
              className="px-4 py-2 bg-emerald-800 text-white text-xs font-medium rounded-lg"
            >
              Reset Filters
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
