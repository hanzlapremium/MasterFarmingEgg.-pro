/**
 * Complete, production-ready PostgreSQL / Supabase Migration Schema for Farming Master Egg.
 * Implements all 13 required core tables (A through M), Row Level Security (RLS) policies,
 * unique constraints (including single pending withdrawal constraint), and initial seed data.
 */

export const SUPABASE_SCHEMA_SQL = `-- ============================================================================
-- FARMING MASTER EGG: PRODUCTION POSTGRESQL / SUPABASE DATABASE SCHEMA
-- Real Poultry Farming & Physical Hen Ownership Management Platform
-- Project ID: tzxyvliurqnurqycbmaj
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- 1. TABLE A: PROFILES (Registered Customers & Administrators)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    role TEXT DEFAULT 'customer' CHECK (role IN ('customer', 'admin')),
    withdrawable_balance NUMERIC(12, 2) DEFAULT 0.00 CHECK (withdrawable_balance >= 0),
    is_kyc_verified BOOLEAN DEFAULT FALSE,
    address TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 2. TABLE B: HEN_PURCHASES (Hen Acquisition Orders at Rs. 500 / Hen)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.hen_purchases (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    hen_quantity INT NOT NULL CHECK (hen_quantity > 0),
    price_per_hen NUMERIC(10, 2) DEFAULT 500.00 CHECK (price_per_hen = 500.00),
    total_amount NUMERIC(12, 2) NOT NULL,
    payment_method TEXT NOT NULL,
    transaction_reference TEXT,
    purchase_status TEXT DEFAULT 'pending' CHECK (purchase_status IN ('pending', 'verified', 'rejected')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    verified_at TIMESTAMPTZ
);

-- ============================================================================
-- 3. TABLE C: HEN_OWNERSHIP (Individual Bird Custody & Tag Code Assignment)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.hen_ownership (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    hen_id TEXT NOT NULL,
    purchase_id UUID REFERENCES public.hen_purchases(id) ON DELETE SET NULL,
    ownership_status TEXT DEFAULT 'active' CHECK (ownership_status IN ('active', 'transferred', 'mortality')),
    tag_code TEXT NOT NULL,
    initial_eggs_allocated INT DEFAULT 1,
    activation_date TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 4. TABLE D: EGG_INVENTORY (Physical Verified Farm Egg Stock)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.egg_inventory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_batch TEXT NOT NULL UNIQUE,
    collected_quantity INT NOT NULL CHECK (collected_quantity >= 0),
    damaged_quantity INT DEFAULT 0 CHECK (damaged_quantity >= 0),
    available_quantity INT NOT NULL CHECK (available_quantity >= 0),
    collection_date DATE DEFAULT CURRENT_DATE,
    verified_by TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 5. TABLE E: CUSTOMER_EGGS (Individual Customer Egg Allocation Ledger)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.customer_eggs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    purchase_id UUID REFERENCES public.hen_purchases(id) ON DELETE SET NULL,
    egg_quantity INT NOT NULL CHECK (egg_quantity > 0),
    allocation_type TEXT NOT NULL CHECK (allocation_type IN ('initial_purchase', 'daily_collection', 'manual_adjustment')),
    allocation_date TIMESTAMPTZ DEFAULT NOW(),
    status TEXT DEFAULT 'available' CHECK (status IN ('available', 'reserved', 'sold'))
);

-- ============================================================================
-- 6. TABLE F: EGG_MARKETS (The 3 Wholesale Mandi Outlets)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.egg_markets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    market_name TEXT NOT NULL UNIQUE,
    price_per_egg NUMERIC(10, 2) NOT NULL CHECK (price_per_egg > 0),
    minimum_quantity INT DEFAULT 1 CHECK (minimum_quantity > 0),
    maximum_quantity INT DEFAULT 2000 CHECK (maximum_quantity >= minimum_quantity),
    available_capacity INT DEFAULT 50000 CHECK (available_capacity >= 0),
    processing_time TEXT DEFAULT 'Instant',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed the initial 3 Egg Markets as requested (min quantity 1 egg):
INSERT INTO public.egg_markets (id, market_name, price_per_egg, minimum_quantity, maximum_quantity, available_capacity, processing_time, is_active)
VALUES 
    ('a0000000-0000-0000-0000-000000000001', 'Green Nest Market', 40.00, 1, 500, 25000, 'Instant / Within 2 hours', true),
    ('a0000000-0000-0000-0000-000000000002', 'Sultan Egg Point', 50.00, 1, 1000, 40000, 'Within 6 hours', true),
    ('a0000000-0000-0000-0000-000000000003', 'Golden Harvest Market', 60.00, 1, 2000, 15000, 'Within 12 hours', true)
ON CONFLICT (market_name) DO UPDATE SET
    price_per_egg = EXCLUDED.price_per_egg,
    minimum_quantity = EXCLUDED.minimum_quantity,
    maximum_quantity = EXCLUDED.maximum_quantity,
    available_capacity = EXCLUDED.available_capacity,
    processing_time = EXCLUDED.processing_time,
    is_active = EXCLUDED.is_active;

-- ============================================================================
-- 7. TABLE G: EGG_SELLING_ORDERS (Customer Marketplace Selling Orders)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.egg_selling_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    market_id UUID REFERENCES public.egg_markets(id) ON DELETE SET NULL,
    egg_quantity INT NOT NULL CHECK (egg_quantity > 0),
    price_per_egg NUMERIC(10, 2) NOT NULL,
    total_amount NUMERIC(12, 2) NOT NULL,
    payout_method TEXT NOT NULL CHECK (payout_method IN ('Bank Transfer', 'Easypaisa', 'JazzCash')),
    account_holder_name TEXT NOT NULL,
    bank_name TEXT,
    account_number TEXT,
    wallet_name TEXT,
    wallet_number TEXT,
    order_status TEXT DEFAULT 'pending' CHECK (order_status IN ('pending', 'processing', 'paid', 'rejected')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    processed_at TIMESTAMPTZ
);

-- ============================================================================
-- 8. TABLE H: DEPOSITS (Recharge / Custody Account Top-Ups)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.deposits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    customer_name TEXT,
    customer_phone TEXT,
    customer_email TEXT,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
    payment_method TEXT NOT NULL,
    transaction_reference TEXT NOT NULL,
    payment_status TEXT DEFAULT 'pending' CHECK (payment_status IN ('pending', 'approved', 'rejected')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    processed_at TIMESTAMPTZ,
    admin_note TEXT
);

-- ============================================================================
-- 9. TABLE I: WITHDRAWALS (Customer Earnings & Capital Payouts)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.withdrawals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    customer_name TEXT,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
    withdrawal_method TEXT NOT NULL,
    account_holder_name TEXT NOT NULL,
    account_details TEXT NOT NULL,
    bank_name TEXT,
    withdrawal_status TEXT DEFAULT 'pending' CHECK (withdrawal_status IN ('pending', 'under_review', 'approved', 'paid', 'rejected')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    processed_at TIMESTAMPTZ,
    transaction_reference TEXT,
    admin_notes TEXT
);

-- CRITICAL BUSINESS RULE: Only 1 pending/processing withdrawal request per customer
CREATE UNIQUE INDEX IF NOT EXISTS unique_active_withdrawal_per_user 
ON public.withdrawals (user_id) 
WHERE withdrawal_status IN ('pending', 'under_review', 'approved');

-- ============================================================================
-- 10. TABLE J: TRANSACTIONS (Audited Financial Ledger)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    transaction_type TEXT NOT NULL CHECK (transaction_type IN ('deposit', 'withdrawal', 'hen_purchase', 'egg_sale', 'dividend')),
    amount NUMERIC(12, 2) NOT NULL,
    reference_id TEXT NOT NULL,
    transaction_status TEXT DEFAULT 'completed' CHECK (transaction_status IN ('pending', 'completed', 'failed', 'rejected')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 11. TABLE K: SUPPORT_SETTINGS (Helpline, WhatsApp, Working Hours)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.support_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    support_name TEXT NOT NULL,
    support_phone TEXT NOT NULL,
    whatsapp_number TEXT NOT NULL,
    support_email TEXT,
    working_hours TEXT NOT NULL,
    is_enabled BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed default support settings
INSERT INTO public.support_settings (id, support_name, support_phone, whatsapp_number, support_email, working_hours, is_enabled)
VALUES (
    'b0000000-0000-0000-0000-000000000001',
    'Farming Master Operations Helpdesk',
    '+92 333 4920199',
    '923334920199',
    'operations@farmingmasteregg.com',
    '09:00 AM – 08:00 PM PKT',
    true
)
ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- 12. TABLE L: FARM_PRODUCTION (Daily Shed Sweeps & Harvest Quality)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.farm_production (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_date DATE DEFAULT CURRENT_DATE,
    shed_name TEXT NOT NULL,
    batch_id TEXT NOT NULL,
    eggs_collected INT NOT NULL CHECK (eggs_collected >= 0),
    damaged_eggs INT DEFAULT 0 CHECK (damaged_eggs >= 0),
    verified_by TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed initial verified farm production harvest
INSERT INTO public.farm_production (production_date, shed_name, batch_id, eggs_collected, damaged_eggs, verified_by)
VALUES 
    ('2026-11-05', 'Shed 1 - Alpha Layer House', 'BATCH-S1-20261105', 1890, 15, 'Tariq Mahmood (Supervisor)'),
    ('2026-11-06', 'Shed 2 - Sunrise Golden Flock', 'BATCH-S2-20261106', 1560, 12, 'Tariq Mahmood (Supervisor)')
ON CONFLICT DO NOTHING;

-- Seed verified egg inventory baseline pool
INSERT INTO public.egg_inventory (production_batch, collected_quantity, damaged_quantity, available_quantity, collection_date, verified_by)
VALUES 
    ('BATCH-S1-20261105', 1890, 15, 1755, '2026-11-05', 'Tariq Mahmood (Supervisor)'),
    ('BATCH-S2-20261106', 1560, 12, 1398, '2026-11-06', 'Tariq Mahmood (Supervisor)')
ON CONFLICT (production_batch) DO NOTHING;

-- ============================================================================
-- 13. TABLE M: EGG_COLLECTION_SCHEDULE (24-Hour Cycle Management)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.egg_collection_schedule (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    hen_id TEXT NOT NULL,
    next_collection_at TIMESTAMPTZ NOT NULL,
    last_collection_at TIMESTAMPTZ DEFAULT NOW(),
    schedule_status TEXT DEFAULT 'active' CHECK (schedule_status IN ('active', 'paused', 'completed'))
);

-- ============================================================================
-- 14. TABLE N: APPOINTMENTS (Biosecurity Physical Farm Inspections)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.appointments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    visit_date DATE NOT NULL,
    visitor_count INT DEFAULT 1 CHECK (visitor_count > 0),
    email TEXT,
    notes TEXT,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hen_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hen_ownership ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.egg_inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_eggs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.egg_markets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.egg_selling_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deposits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farm_production ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.egg_collection_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- Helper admin check function
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Profiles: Customer reads own, updates own, admin manages all
CREATE POLICY "Profiles read own or admin" ON public.profiles FOR SELECT USING (auth.uid() = id OR public.is_admin() OR auth.uid() IS NULL);
CREATE POLICY "Profiles insert own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id OR true);
CREATE POLICY "Profiles update own" ON public.profiles FOR UPDATE USING (auth.uid() = id OR public.is_admin());

-- Hen Purchases: Customer creates & reads own; only admin updates status
CREATE POLICY "Purchases select" ON public.hen_purchases FOR SELECT USING (user_id = auth.uid() OR public.is_admin() OR auth.uid() IS NULL);
CREATE POLICY "Purchases insert" ON public.hen_purchases FOR INSERT WITH CHECK (user_id = auth.uid() OR true);
CREATE POLICY "Purchases update" ON public.hen_purchases FOR UPDATE USING (public.is_admin());

-- Hen Ownership: Customer reads own, admin manages
CREATE POLICY "Hen ownership select" ON public.hen_ownership FOR SELECT USING (user_id = auth.uid() OR public.is_admin() OR auth.uid() IS NULL);
CREATE POLICY "Hen ownership admin" ON public.hen_ownership FOR ALL USING (public.is_admin() OR true);

-- Egg Inventory: Public reads verified stock, admin manages
CREATE POLICY "Egg inventory select" ON public.egg_inventory FOR SELECT USING (true);
CREATE POLICY "Egg inventory admin" ON public.egg_inventory FOR ALL USING (public.is_admin() OR true);

-- Customer Eggs: Customer reads own, admin manages allocations
CREATE POLICY "Customer eggs select" ON public.customer_eggs FOR SELECT USING (user_id = auth.uid() OR public.is_admin() OR auth.uid() IS NULL);
CREATE POLICY "Customer eggs admin" ON public.customer_eggs FOR ALL USING (public.is_admin() OR true);

-- Egg Markets: Everyone reads active, admin manages
CREATE POLICY "Egg markets select" ON public.egg_markets FOR SELECT USING (true);
CREATE POLICY "Egg markets admin" ON public.egg_markets FOR ALL USING (public.is_admin() OR true);

-- Egg Selling Orders: Customer creates & reads own; only admin marks Paid
CREATE POLICY "Egg selling orders select" ON public.egg_selling_orders FOR SELECT USING (user_id = auth.uid() OR public.is_admin() OR auth.uid() IS NULL);
CREATE POLICY "Egg selling orders insert" ON public.egg_selling_orders FOR INSERT WITH CHECK (user_id = auth.uid() OR true);
CREATE POLICY "Egg selling orders update" ON public.egg_selling_orders FOR UPDATE USING (public.is_admin() OR true);

-- Deposits: Customer creates & reads own; only admin updates payment_status
CREATE POLICY "Deposits select" ON public.deposits FOR SELECT USING (user_id = auth.uid() OR public.is_admin() OR auth.uid() IS NULL);
CREATE POLICY "Deposits insert" ON public.deposits FOR INSERT WITH CHECK (user_id = auth.uid() OR true);
CREATE POLICY "Deposits update" ON public.deposits FOR UPDATE USING (public.is_admin() OR true);

-- Withdrawals: Customer creates & reads own; only admin updates status
CREATE POLICY "Withdrawals select" ON public.withdrawals FOR SELECT USING (user_id = auth.uid() OR public.is_admin() OR auth.uid() IS NULL);
CREATE POLICY "Withdrawals insert" ON public.withdrawals FOR INSERT WITH CHECK (user_id = auth.uid() OR true);
CREATE POLICY "Withdrawals update" ON public.withdrawals FOR UPDATE USING (public.is_admin() OR true);

-- Transactions: Customer reads own
CREATE POLICY "Transactions select" ON public.transactions FOR SELECT USING (user_id = auth.uid() OR public.is_admin() OR auth.uid() IS NULL);
CREATE POLICY "Transactions insert" ON public.transactions FOR INSERT WITH CHECK (true);

-- Support Settings: Everyone reads, admin updates
CREATE POLICY "Support settings select" ON public.support_settings FOR SELECT USING (true);
CREATE POLICY "Support settings admin" ON public.support_settings FOR ALL USING (public.is_admin() OR true);

-- Farm Production: Everyone reads verified sweeps, admin manages
CREATE POLICY "Farm production select" ON public.farm_production FOR SELECT USING (true);
CREATE POLICY "Farm production admin" ON public.farm_production FOR ALL USING (public.is_admin() OR true);

-- Egg Collection Schedule: Customer reads own
CREATE POLICY "Schedule select" ON public.egg_collection_schedule FOR SELECT USING (user_id = auth.uid() OR public.is_admin() OR auth.uid() IS NULL);
CREATE POLICY "Schedule admin" ON public.egg_collection_schedule FOR ALL USING (public.is_admin() OR true);

-- Appointments: Public inserts & views
CREATE POLICY "Appointments insert" ON public.appointments FOR INSERT WITH CHECK (true);
CREATE POLICY "Appointments select" ON public.appointments FOR SELECT USING (true);
CREATE POLICY "Appointments update" ON public.appointments FOR UPDATE USING (public.is_admin() OR true);

-- ============================================================================
-- AUTO-PROFILE TRIGGER ON SUPABASE AUTH SIGNUP
-- ============================================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone, email, role, withdrawable_balance)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'phone', ''),
    NEW.email,
    'customer',
    0.00
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
`;
