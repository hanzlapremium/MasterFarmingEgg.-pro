import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HeroSection } from './components/HeroSection';
import { Marketplace } from './components/Marketplace';
import { PurchaseModal } from './components/PurchaseModal';
import { CertificateModal } from './components/CertificateModal';
import { CustomerDashboard } from './components/CustomerDashboard';
import { CustomerAuthView } from './components/auth/CustomerAuthView';
import { SecureAdminPortal } from './components/admin/SecureAdminPortal';
import { HowItWorksView } from './components/views/HowItWorksView';
import { AboutFarmView } from './components/views/AboutFarmView';
import { FacilitiesView } from './components/views/FacilitiesView';
import { ProductionProcessView } from './components/views/ProductionProcessView';
import { GalleryView } from './components/views/GalleryView';
import { TransparencyView } from './components/views/TransparencyView';
import { FaqsView } from './components/views/FaqsView';
import { ContactView } from './components/views/ContactView';
import { LegalAgreementView } from './components/views/LegalAgreementView';
import { ArrowRight, ShieldCheck, CheckCircle2, Egg, Activity, FileText } from 'lucide-react';

const AppContent: React.FC = () => {
  const { 
    activeView, 
    setActiveView, 
    setPurchaseModalOpen, 
    hens, 
    isAdminRoute,
    setIsAdminRoute,
    adminLogin,
    currentUser 
  } = useApp();

  // Scroll to top on view changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeView]);

  // If user navigated to private admin route /secure-farm-control
  if (isAdminRoute) {
    return <SecureAdminPortal />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#faf9f5] text-[#1c271e]">
      {/* Primary Header (Zero admin links) */}
      <Header />

      {/* Main View Router */}
      <main className="flex-1">
        {activeView === 'home' && (
          <div>
            <HeroSection />

            {/* Section 1: Physical Model Value Proposition */}
            <section className="py-16 bg-white border-b border-emerald-950/10">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
                  
                  <div className="space-y-4 lg:col-span-1">
                    <span className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
                      Commercial Poultry Bailment
                    </span>
                    <h2 className="text-3xl font-bold font-display text-emerald-950 tracking-tight">
                      Actual Hen Ownership. Genuine Farm Custody.
                    </h2>
                    <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                      FARMING MASTER EGG connects you directly to physical layer poultry in Punjab. 
                      You acquire real layer hens at <strong className="text-emerald-900 font-semibold">Rs. 500 per hen</strong>, receive permanent wing/leg tags, and entrust daily husbandry to licensed agricultural professionals.
                    </p>
                    <div className="pt-2">
                      <button
                        onClick={() => setActiveView('how-it-works')}
                        className="flex items-center gap-2 text-xs font-bold text-emerald-800 hover:text-emerald-950 group"
                      >
                        <span>Learn how the physical custody model operates</span>
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>

                  {/* 3 Value Pillars */}
                  <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-6">
                    
                    <div className="p-5 bg-stone-50 rounded-xl border border-stone-200/80 space-y-2">
                      <div className="w-10 h-10 rounded-lg bg-emerald-100/70 text-emerald-900 flex items-center justify-center">
                        <Egg className="w-5 h-5 text-emerald-800" />
                      </div>
                      <h3 className="font-bold text-sm text-emerald-950 font-display">Rs. 500 Initial Price</h3>
                      <p className="text-xs text-stone-600 leading-relaxed">
                        Transparent cost reflecting real acquisition of 24-week point-of-lay pullets with complete Marek, ND, and IBD vaccinations.
                      </p>
                    </div>

                    <div className="p-5 bg-stone-50 rounded-xl border border-stone-200/80 space-y-2">
                      <div className="w-10 h-10 rounded-lg bg-emerald-100/70 text-emerald-900 flex items-center justify-center">
                        <Activity className="w-5 h-5 text-emerald-800" />
                      </div>
                      <h3 className="font-bold text-sm text-emerald-950 font-display">Wholesale Mandi Sales</h3>
                      <p className="text-xs text-stone-600 leading-relaxed">
                        Collected eggs are crated daily and sold directly to wholesale buyers in Rawalpindi and Islamabad mandis at prevailing market rates.
                      </p>
                    </div>

                    <div className="p-5 bg-stone-50 rounded-xl border border-stone-200/80 space-y-2">
                      <div className="w-10 h-10 rounded-lg bg-emerald-100/70 text-emerald-900 flex items-center justify-center">
                        <FileText className="w-5 h-5 text-emerald-800" />
                      </div>
                      <h3 className="font-bold text-sm text-emerald-950 font-display">Audited Cost Sharing</h3>
                      <p className="text-xs text-stone-600 leading-relaxed">
                        Documented feed, electricity, and vet expenses are deducted from gross egg revenue. Net distributions are allocated by flock formula.
                      </p>
                    </div>

                  </div>

                </div>
              </div>
            </section>

            {/* Section 2: Physical Flock Catalog Preview */}
            <section className="py-16 bg-stone-50/70 border-b border-emerald-950/10">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
                <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
                      Physical Flock Catalog
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-bold font-display text-emerald-950">
                      Currently Available Layer Hens (Rs. 500)
                    </h2>
                    <p className="text-xs text-stone-600">
                      Individually tagged pullets currently in Shed 1, 2 and 3 ready for custody assignment.
                    </p>
                  </div>

                  <button
                    onClick={() => setActiveView('marketplace')}
                    className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 hover:text-emerald-950"
                  >
                    <span>View All Hens ({hens.length})</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {hens.filter(h => h.status === 'available').slice(0, 4).map(hen => (
                    <div
                      key={hen.id}
                      className="bg-white rounded-xl border border-emerald-950/10 shadow-xs overflow-hidden flex flex-col justify-between"
                    >
                      <div className="relative aspect-4/3 bg-stone-100">
                        <img
                          src={hen.photoUrl}
                          alt={hen.tagCode}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-2 left-2 bg-emerald-950/80 backdrop-blur-xs text-white text-[11px] font-mono px-2 py-0.5 rounded">
                          {hen.tagCode}
                        </div>
                      </div>

                      <div className="p-4 space-y-3">
                        <div>
                          <div className="flex justify-between items-center">
                            <h3 className="font-bold text-sm text-emerald-950">{hen.breed}</h3>
                            <span className="font-bold font-mono text-emerald-900 text-sm">Rs. 500</span>
                          </div>
                          <div className="text-xs text-stone-500 mt-1">
                            {hen.ageWeeks} weeks · {hen.shedName.split('-')[0]}
                          </div>
                        </div>

                        <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                          <span className="text-[11px] text-emerald-800 font-medium">Ready for Custody</span>
                          <button
                            onClick={() => {
                              setActiveView('marketplace');
                              setPurchaseModalOpen(true);
                            }}
                            className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-md text-xs font-semibold"
                          >
                            Acquire
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </div>
        )}

        {activeView === 'marketplace' && <Marketplace />}
        {activeView === 'how-it-works' && <HowItWorksView />}
        {activeView === 'about' && <AboutFarmView />}
        {activeView === 'facilities' && <FacilitiesView />}
        {activeView === 'production-process' && <ProductionProcessView />}
        {activeView === 'gallery' && <GalleryView />}
        {activeView === 'transparency' && <TransparencyView />}
        {activeView === 'faqs' && <FaqsView />}
        {activeView === 'contact' && <ContactView />}
        {activeView === 'agreement' && <LegalAgreementView />}
        {activeView === 'risk-disclosure' && <LegalAgreementView />}
        {activeView === 'terms' && <LegalAgreementView />}
        {activeView === 'privacy' && <LegalAgreementView />}
        {activeView === 'customer-dashboard' && <CustomerDashboard />}
        {activeView === 'customer-login' && <CustomerAuthView initialMode="login" />}
        {activeView === 'customer-register' && <CustomerAuthView initialMode="register" />}
      </main>

      {/* Global Interactive Modals */}
      <PurchaseModal />
      <CertificateModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
