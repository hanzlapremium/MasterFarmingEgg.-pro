// Re-export all appointment utilities from the unified Supabase client
// This breaks any circular dependency between appointments.ts and supabase.ts
export {
  type AppointmentPayload,
  type AppointmentRecord,
  getLocalAppointments,
  saveLocalAppointment,
  updateLocalAppointmentSync,
  saveAppointmentToSupabase,
  fetchAllAppointments,
  testSupabaseHealth,
  SUPABASE_APPOINTMENTS_SQL
} from './supabase';
