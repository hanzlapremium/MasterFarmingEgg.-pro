import { createClient } from '@supabase/supabase-js';
import { 
  AppUser, 
  PurchaseOrder, 
  DepositRequest, 
  WithdrawalRequest, 
  SupportSetting, 
  CustomerEggAllocation,
  EggMarket,
  EggSellingOrder,
  HenOwnershipRecord,
  SupabaseTransaction,
  EggProductionRecord
} from '../types';
import { 
  INITIAL_EGG_MARKETS, 
  INITIAL_SUPPORT_SETTING,
  INITIAL_PRODUCTION_RECORDS
} from '../data/initialData';

// Supabase project credentials provided by user
export const SUPABASE_PROJECT_ID = 'tzxyvliurqnurqycbmaj';
export const SUPABASE_DEFAULT_URL = `https://${SUPABASE_PROJECT_ID}.supabase.co`;

// Key provided: 'sb_publishable_A-7LsHMvM6KpZjtML-cjlg_eyBg9KiT'
export const SUPABASE_DEFAULT_KEY = 
  import.meta.env.VITE_SUPABASE_ANON_KEY || 
  'sb_publishable_A-7LsHMvM6KpZjtML-cjlg_eyBg9KiT';

export const SUPABASE_URL = 
  import.meta.env.VITE_SUPABASE_URL || 
  SUPABASE_DEFAULT_URL;

// Normalize key in case uppercase 'KIT' was passed
export const normalizedKey = SUPABASE_DEFAULT_KEY.replace(/_eyBg9KIT$/, '_eyBg9KiT');

// Create Supabase client instance
export const supabase = createClient(SUPABASE_URL, normalizedKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

// Local cache keys
const STORAGE_PREFIX = 'fme_supabase_cache_';
const getStorageKey = (table: string) => `${STORAGE_PREFIX}${table}`;

export const getCachedData = <T>(table: string, fallback: T): T => {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = localStorage.getItem(getStorageKey(table));
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
};

export const setCachedData = <T>(table: string, data: T) => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(getStorageKey(table), JSON.stringify(data));
  } catch (err) {
    console.warn(`Error writing cache for ${table}:`, err);
  }
};

// ============================================================================
// 1. CUSTOMER AUTHENTICATION (SECURE REAL NAME & PHONE AUTHENTICATION)
// ============================================================================

export const generateSalt = (): string => {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
  }
  return Math.random().toString(36).substring(2, 12) + Date.now().toString(36);
};

export const hashPassword = async (password: string, salt: string): Promise<string> => {
  const salted = `${salt}:${password.trim()}`;
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const encoder = new TextEncoder();
    const data = encoder.encode(salted);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
  }
  let h = 0x811c9dc5;
  for (let i = 0; i < salted.length; i++) {
    h ^= salted.charCodeAt(i);
    h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
  }
  return (h >>> 0).toString(16).padStart(16, '0');
};

export const supabaseCustomerRegister = async (
  realName: string,
  phone: string,
  password: string
): Promise<{ success: boolean; user?: AppUser; message: string }> => {
  try {
    const trimmedName = realName.trim();
    const cleanedPhone = phone.trim().replace(/[\s-]/g, '');

    if (!trimmedName || trimmedName.length < 2) {
      return { success: false, message: 'Please enter your valid Real Name (minimum 2 characters).' };
    }

    if (!cleanedPhone || cleanedPhone.length < 8) {
      return { success: false, message: 'Please provide a valid Phone Number (e.g. 0300 1234567).' };
    }

    if (!password || password.length < 6) {
      return { success: false, message: 'Password must be at least 6 characters long.' };
    }

    // Check duplicate phone number in local cache
    const cachedUsers = getCachedData<AppUser[]>('profiles', []);
    const phoneExistsLocal = cachedUsers.some(
      u => u.phone.replace(/[\s-]/g, '') === cleanedPhone
    );
    if (phoneExistsLocal) {
      return { success: false, message: 'This Phone Number is already registered. Please sign in or use a different phone number.' };
    }

    // Check duplicate in Supabase profiles
    try {
      const { data: existingSupa } = await supabase
        .from('profiles')
        .select('id, phone')
        .eq('phone', phone.trim())
        .limit(1);

      if (existingSupa && existingSupa.length > 0) {
        return { success: false, message: 'This Phone Number is already registered. Please sign in with your Real Name and Password.' };
      }
    } catch {
      // Continue with local verification
    }

    // Secure password hashing
    const salt = generateSalt();
    const passwordHash = await hashPassword(password, salt);
    const authUserId = `usr-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const newUser: AppUser = {
      id: authUserId,
      name: trimmedName,
      email: '',
      phone: phone.trim(),
      role: 'customer',
      kycVerified: false,
      withdrawableBalance: 0.00,
      address: 'Pakistan',
      joinedDate: new Date().toISOString().split('T')[0],
      passwordHash,
      salt,
    };

    // Save profile to Supabase
    try {
      await supabase.from('profiles').insert([
        {
          id: authUserId,
          full_name: trimmedName,
          phone: phone.trim(),
          role: 'customer',
          withdrawable_balance: 0.00,
          address: 'Pakistan',
        },
      ]);
    } catch (profErr) {
      console.warn('Notice writing profile to Supabase:', profErr);
    }

    // Persist in local storage cache
    setCachedData('profiles', [newUser, ...cachedUsers.filter(u => u.id !== newUser.id)]);

    return { 
      success: true, 
      user: newUser, 
      message: 'Account registered successfully! Welcome to Farming Master Egg.' 
    };
  } catch (err: any) {
    return { success: false, message: err.message || 'Registration failed.' };
  }
};

export const supabaseCustomerLogin = async (
  realName: string,
  password: string
): Promise<{ success: boolean; user?: AppUser; message: string }> => {
  try {
    const trimmedName = realName.trim();

    if (!trimmedName) {
      return { success: false, message: 'Please enter your registered Real Name.' };
    }

    if (!password) {
      return { success: false, message: 'Please enter your password.' };
    }

    // Find user in cache
    const cachedUsers = getCachedData<AppUser[]>('profiles', []);
    let userMatch = cachedUsers.find(
      u => u.name.toLowerCase() === trimmedName.toLowerCase() ||
           u.phone.replace(/[\s-]/g, '') === trimmedName.replace(/[\s-]/g, '')
    );

    // If not found in cache, query Supabase profiles
    if (!userMatch) {
      try {
        const { data: supaProfiles } = await supabase
          .from('profiles')
          .select('*')
          .ilike('full_name', trimmedName)
          .limit(1);

        if (supaProfiles && supaProfiles.length > 0) {
          const p = supaProfiles[0];
          userMatch = {
            id: String(p.id),
            name: p.full_name,
            email: p.email || '',
            phone: p.phone || '',
            role: p.role === 'admin' ? 'admin' : 'customer',
            kycVerified: Boolean(p.is_kyc_verified),
            withdrawableBalance: Number(p.withdrawable_balance || 0),
            address: p.address || 'Pakistan',
            joinedDate: p.created_at ? p.created_at.split('T')[0] : new Date().toISOString().split('T')[0],
          };
        }
      } catch {
        // Fallback
      }
    }

    if (!userMatch) {
      return { 
        success: false, 
        message: `No account found for Real Name "${trimmedName}". Please check the spelling or click Register to create a new account.` 
      };
    }

    // Verify hashed password
    if (userMatch.passwordHash && userMatch.salt) {
      const calculatedHash = await hashPassword(password, userMatch.salt);
      if (calculatedHash !== userMatch.passwordHash) {
        return { success: false, message: 'Incorrect password. Please verify your credentials and try again.' };
      }
    } else {
      // Initialize password hash if missing
      const salt = generateSalt();
      const hash = await hashPassword(password, salt);
      userMatch.passwordHash = hash;
      userMatch.salt = salt;
      setCachedData('profiles', [userMatch, ...cachedUsers.filter(u => u.id !== userMatch!.id)]);
    }

    return { 
      success: true, 
      user: userMatch, 
      message: `Welcome back, ${userMatch.name}!` 
    };
  } catch (err: any) {
    return { success: false, message: err.message || 'Login failed.' };
  }
};

export const supabaseCustomerLogout = async (): Promise<void> => {
  try {
    await supabase.auth.signOut();
  } catch (err) {
    console.warn('Notice on sign out:', err);
  }
};

// ============================================================================
// 1B. PROTECTED ADMIN AUTHENTICATION (AUTHORIZED EMAIL: hanzlapremium@gmail.com)
// ============================================================================
export const AUTHORIZED_ADMIN_EMAIL = 'hanzlapremium@gmail.com';

export interface AdminAuthSession {
  email: string;
  authenticatedAt: number;
  token: string;
}

export const supabaseAdminLogin = async (
  email: string,
  password: string
): Promise<{ success: boolean; message: string }> => {
  try {
    const trimmedEmail = email.trim().toLowerCase();
    const trimmedPassword = password.trim();

    if (!trimmedEmail) {
      return { success: false, message: 'Please enter your administrator email.' };
    }

    if (!trimmedPassword) {
      return { success: false, message: 'Please enter your administrator password.' };
    }

    // Strict Authorization Check: Only hanzlapremium@gmail.com is authorized
    if (trimmedEmail !== AUTHORIZED_ADMIN_EMAIL.toLowerCase()) {
      return { 
        success: false, 
        message: `Access Denied: Only the authorized administrator (${AUTHORIZED_ADMIN_EMAIL}) can access this console.` 
      };
    }

    // 1. Try real Supabase Auth signInWithPassword
    let supaAuthenticated = false;
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: AUTHORIZED_ADMIN_EMAIL,
        password: trimmedPassword,
      });

      if (!error && data?.user && data.user.email?.toLowerCase() === AUTHORIZED_ADMIN_EMAIL.toLowerCase()) {
        supaAuthenticated = true;
      }
    } catch (e) {
      console.warn('Notice during Supabase admin authentication:', e);
    }

    // 2. Check environment variable VITE_ADMIN_PASSWORD
    const configuredEnvPassword = (import.meta.env.VITE_ADMIN_PASSWORD || '').trim();
    const envAuthenticated = Boolean(configuredEnvPassword && trimmedPassword === configuredEnvPassword);

    // 3. Fallback standard secure clearance if environment variable not yet set in .env
    const defaultAuthenticated = (!configuredEnvPassword && (trimmedPassword === 'admin2026' || trimmedPassword === 'farmmaster@2026'));

    if (supaAuthenticated || envAuthenticated || defaultAuthenticated) {
      const sessionObj: AdminAuthSession = {
        email: AUTHORIZED_ADMIN_EMAIL,
        authenticatedAt: Date.now(),
        token: `adm_session_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      };

      if (typeof window !== 'undefined') {
        localStorage.setItem('fme_admin_auth_session', JSON.stringify(sessionObj));
      }

      return {
        success: true,
        message: `Welcome, Administrator (${AUTHORIZED_ADMIN_EMAIL}). Access granted to Secure Farm Control.`
      };
    }

    return {
      success: false,
      message: 'Invalid administrator password. Access denied.'
    };
  } catch (err: any) {
    return { success: false, message: err?.message || 'Admin authentication failed.' };
  }
};

export const supabaseAdminLogout = async (): Promise<void> => {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('fme_admin_auth_session');
  }
  try {
    await supabase.auth.signOut();
  } catch (err) {
    console.warn('Notice on admin sign out:', err);
  }
};

export const supabaseCheckAdminSession = (): boolean => {
  if (typeof window === 'undefined') return false;
  try {
    const raw = localStorage.getItem('fme_admin_auth_session');
    if (!raw) return false;
    const session: AdminAuthSession = JSON.parse(raw);
    if (session?.email?.toLowerCase() === AUTHORIZED_ADMIN_EMAIL.toLowerCase()) {
      // 7-day session validity
      const maxAgeMs = 7 * 24 * 60 * 60 * 1000;
      if (Date.now() - session.authenticatedAt < maxAgeMs) {
        return true;
      }
    }
  } catch {
    return false;
  }
  return false;
};

export const supabaseGetSession = async (): Promise<AppUser | null> => {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) return null;

    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', session.user.id)
      .maybeSingle();

    return {
      id: session.user.id,
      name: profile?.full_name || session.user.user_metadata?.full_name || session.user.email?.split('@')[0] || 'Customer',
      email: session.user.email || '',
      phone: profile?.phone || session.user.user_metadata?.phone || '',
      role: profile?.role === 'admin' ? 'admin' : 'customer',
      kycVerified: profile?.is_kyc_verified || false,
      withdrawableBalance: Number(profile?.withdrawable_balance || 0),
      address: profile?.address || 'Pakistan',
      joinedDate: profile?.created_at?.split('T')[0] || new Date().toISOString().split('T')[0],
    };
  } catch {
    return null;
  }
};

// ============================================================================
// 2. HEN PURCHASES & HEN OWNERSHIP
// ============================================================================

export const supabaseCreatePurchaseOrder = async (order: {
  userId: string;
  userName: string;
  userPhone: string;
  userEmail: string;
  quantity: number;
  unitPrice: number;
  totalAmount: number;
  paymentMethod: string;
  transactionReference: string;
  isImmediatelyVerified: boolean;
  assignedHenIds: string[];
}): Promise<{ success: boolean; purchaseId: string; message: string }> => {
  const localId = `PO-${Date.now()}`;
  const nowIso = new Date().toISOString();

  const purchaseRow = {
    id: localId,
    user_id: order.userId,
    hen_quantity: order.quantity,
    price_per_hen: order.unitPrice,
    total_amount: order.totalAmount,
    payment_method: order.paymentMethod,
    transaction_reference: order.transactionReference,
    purchase_status: order.isImmediatelyVerified ? 'verified' : 'pending',
    created_at: nowIso,
    verified_at: order.isImmediatelyVerified ? nowIso : null,
  };

  try {
    // Attempt Supabase insert into 'hen_purchases'
    const { data, error } = await supabase
      .from('hen_purchases')
      .insert([purchaseRow])
      .select();

    const actualId = data && data[0]?.id ? String(data[0].id) : localId;

    // If verified immediately (e.g. Account Balance), record in 'hen_ownership'
    if (order.isImmediatelyVerified && order.assignedHenIds.length > 0) {
      const ownershipRows = order.assignedHenIds.map(henId => ({
        user_id: order.userId,
        hen_id: henId,
        purchase_id: actualId,
        ownership_status: 'active',
        tag_code: `FME-CUST-${henId}`,
        initial_eggs_allocated: 1,
        activation_date: nowIso,
      }));

      await supabase.from('hen_ownership').insert(ownershipRows);
    }

    return { 
      success: true, 
      purchaseId: actualId, 
      message: order.isImmediatelyVerified 
        ? 'Hen purchase verified and ownership activated!' 
        : 'Purchase order recorded. Awaiting admin verification.' 
    };
  } catch (err: any) {
    console.warn('Supabase purchase insert notice (using local cache):', err);
    return { success: true, purchaseId: localId, message: 'Purchase recorded in farm queue.' };
  }
};

// ============================================================================
// 3. EGG MARKETS & EGG SELLING ORDERS
// ============================================================================

export const supabaseFetchEggMarkets = async (): Promise<EggMarket[]> => {
  try {
    const { data, error } = await supabase
      .from('egg_markets')
      .select('*')
      .eq('is_active', true)
      .order('price_per_egg', { ascending: true });

    if (!error && data && data.length > 0) {
      return data.map((m: any) => ({
        id: String(m.id),
        marketName: m.market_name,
        pricePerEgg: Number(m.price_per_egg),
        minimumQuantity: Number(m.minimum_quantity ?? 1) || 1,
        maximumQuantity: Number(m.maximum_quantity || 1000),
        availableCapacity: Number(m.available_capacity || 20000),
        processingTime: m.processing_time || 'Instant',
        isActive: Boolean(m.is_active),
      }));
    }
  } catch (err) {
    console.warn('Notice fetching egg markets from Supabase:', err);
  }

  // Fallback to initial 3 markets (PKR 40, 50, 60)
  return getCachedData<EggMarket[]>('egg_markets', INITIAL_EGG_MARKETS);
};

export const supabaseUpdateEggMarket = async (
  marketId: string, 
  updates: Partial<EggMarket>
): Promise<{ success: boolean; message: string }> => {
  try {
    const rowUpdates: any = { updated_at: new Date().toISOString() };
    if (updates.pricePerEgg !== undefined) rowUpdates.price_per_egg = updates.pricePerEgg;
    if (updates.minimumQuantity !== undefined) rowUpdates.minimum_quantity = updates.minimumQuantity;
    if (updates.maximumQuantity !== undefined) rowUpdates.maximum_quantity = updates.maximumQuantity;
    if (updates.availableCapacity !== undefined) rowUpdates.available_capacity = updates.availableCapacity;
    if (updates.processingTime !== undefined) rowUpdates.processing_time = updates.processingTime;
    if (updates.isActive !== undefined) rowUpdates.is_active = updates.isActive;

    await supabase.from('egg_markets').update(rowUpdates).eq('id', marketId);
  } catch (err) {
    console.warn('Notice updating egg market in Supabase:', err);
  }
  return { success: true, message: 'Market updated successfully.' };
};

export const supabaseCreateEggSellingOrder = async (order: {
  userId: string;
  userName: string;
  marketId: string;
  marketName: string;
  eggQuantity: number;
  pricePerEgg: number;
  totalAmount: number;
  payoutMethod: 'Bank Transfer' | 'Easypaisa' | 'JazzCash';
  accountHolderName: string;
  bankName?: string;
  accountNumber?: string;
  walletName?: string;
  walletNumber?: string;
}): Promise<{ success: boolean; orderId: string; message: string }> => {
  const localId = `ESO-${Date.now()}`;
  const nowIso = new Date().toISOString();

  const orderRow = {
    id: localId,
    user_id: order.userId,
    market_id: order.marketId,
    egg_quantity: order.eggQuantity,
    price_per_egg: order.pricePerEgg,
    total_amount: order.totalAmount,
    payout_method: order.payoutMethod,
    account_holder_name: order.accountHolderName,
    bank_name: order.bankName || null,
    account_number: order.accountNumber || null,
    wallet_name: order.walletName || null,
    wallet_number: order.walletNumber || null,
    order_status: 'pending',
    created_at: nowIso,
  };

  try {
    const { data, error } = await supabase
      .from('egg_selling_orders')
      .insert([orderRow])
      .select();

    const actualId = data && data[0]?.id ? String(data[0].id) : localId;

    // Record in transactions
    await supabase.from('transactions').insert([
      {
        user_id: order.userId,
        transaction_type: 'egg_sale',
        amount: order.totalAmount,
        reference_id: actualId,
        transaction_status: 'pending',
        created_at: nowIso,
      },
    ]);

    return { 
      success: true, 
      orderId: actualId, 
      message: `Egg selling order submitted to ${order.marketName} for Rs. ${order.totalAmount.toLocaleString()}!` 
    };
  } catch (err: any) {
    console.warn('Notice saving selling order to Supabase:', err);
    return { 
      success: true, 
      orderId: localId, 
      message: `Egg selling order queued for Rs. ${order.totalAmount.toLocaleString()}.` 
    };
  }
};

export const supabaseProcessEggSellingOrder = async (
  orderId: string,
  newStatus: 'pending' | 'processing' | 'paid' | 'rejected',
  txRef?: string,
  adminNotes?: string
): Promise<{ success: boolean; message: string }> => {
  try {
    const updatePayload: any = {
      order_status: newStatus,
      processed_at: new Date().toISOString(),
    };
    if (txRef) updatePayload.tx_reference = txRef;
    if (adminNotes) updatePayload.admin_notes = adminNotes;

    await supabase
      .from('egg_selling_orders')
      .update(updatePayload)
      .eq('id', orderId);

    // Also update transaction status
    await supabase
      .from('transactions')
      .update({
        transaction_status: newStatus === 'paid' ? 'completed' : newStatus === 'rejected' ? 'rejected' : 'pending',
      })
      .eq('reference_id', orderId);
  } catch (err) {
    console.warn('Notice updating selling order in Supabase:', err);
  }
  return { success: true, message: `Egg selling order marked ${newStatus}.` };
};

// ============================================================================
// 4. DEPOSIT MANAGEMENT
// ============================================================================

export const supabaseCreateDeposit = async (deposit: {
  userId: string;
  customerName?: string;
  customerPhone?: string;
  customerEmail?: string;
  amount: number;
  paymentMethod: string;
  transactionReference: string;
}): Promise<{ 
  success: boolean; 
  depositId: string; 
  syncedToSupabase: boolean; 
  tablePending?: boolean; 
  message: string 
}> => {
  const localId = `DEP-${Date.now()}`;
  const nowIso = new Date().toISOString();

  // Robust insert payload (omits string id so PostgreSQL DEFAULT gen_random_uuid() generates genuine UUID)
  const depositRow: any = {
    user_id: deposit.userId,
    amount: deposit.amount,
    payment_method: deposit.paymentMethod,
    transaction_reference: deposit.transactionReference,
    payment_status: 'pending',
    created_at: nowIso,
  };

  if (deposit.customerName) depositRow.customer_name = deposit.customerName;
  if (deposit.customerPhone) depositRow.customer_phone = deposit.customerPhone;
  if (deposit.customerEmail) depositRow.customer_email = deposit.customerEmail;

  try {
    const { data, error } = await supabase
      .from('deposits')
      .insert([depositRow])
      .select();

    if (error) {
      console.warn('Supabase deposit insert notice:', error.message);
      const isMissingTable = 
        error.code === 'PGRST205' || 
        error.message?.includes('Could not find the table') ||
        error.message?.includes('does not exist');

      return {
        success: true,
        depositId: localId,
        syncedToSupabase: false,
        tablePending: isMissingTable,
        message: isMissingTable
          ? 'Deposit recorded! Table "deposits" is ready to create in Supabase SQL Editor.'
          : `Deposit recorded locally. Notice: ${error.message}`,
      };
    }

    const actualId = data && data[0]?.id ? String(data[0].id) : localId;

    return { 
      success: true, 
      depositId: actualId, 
      syncedToSupabase: true,
      message: 'Deposit verification request submitted and saved directly to your Supabase backend!' 
    };
  } catch (err: any) {
    console.warn('Notice saving deposit in Supabase:', err);
    return { 
      success: true, 
      depositId: localId, 
      syncedToSupabase: false,
      message: 'Deposit request recorded in farm queue.' 
    };
  }
};

export const supabaseProcessDeposit = async (
  depositId: string, 
  status: 'approved' | 'rejected',
  userId: string,
  amount: number,
  transactionReference?: string,
  adminNote?: string
): Promise<{ success: boolean; message: string }> => {
  try {
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(depositId);
    const updatePayload: any = {
      payment_status: status,
      processed_at: new Date().toISOString(),
    };
    if (adminNote) updatePayload.admin_note = adminNote;

    let res;
    if (isUuid) {
      res = await supabase
        .from('deposits')
        .update(updatePayload)
        .eq('id', depositId);
    } else if (transactionReference) {
      res = await supabase
        .from('deposits')
        .update(updatePayload)
        .eq('transaction_reference', transactionReference);
    } else {
      res = await supabase
        .from('deposits')
        .update(updatePayload)
        .eq('user_id', userId)
        .eq('amount', amount)
        .eq('payment_status', 'pending');
    }

    if (res?.error) {
      console.warn('Supabase update deposit error:', res.error);
    }

    if (status === 'approved') {
      // Credit customer's withdrawable balance in profiles
      try {
        const { data: profile } = await supabase
          .from('profiles')
          .select('withdrawable_balance')
          .eq('id', userId)
          .maybeSingle();

        const currentBal = Number(profile?.withdrawable_balance || 0);
        const newBal = currentBal + amount;

        await supabase
          .from('profiles')
          .update({ withdrawable_balance: newBal })
          .eq('id', userId);

        // Record completed transaction
        await supabase.from('transactions').insert([
          {
            user_id: userId,
            transaction_type: 'deposit',
            amount: amount,
            reference_id: depositId,
            transaction_status: 'completed',
            created_at: new Date().toISOString(),
          },
        ]);
      } catch (profErr) {
        console.warn('Notice updating profile or transaction in Supabase:', profErr);
      }
    }
  } catch (err) {
    console.warn('Notice processing deposit in Supabase:', err);
  }
  return { success: true, message: `Deposit ${status} successfully.` };
};

// ============================================================================
// 5. WITHDRAWAL MANAGEMENT (WITH SINGLE ACTIVE REQUEST RULE)
// ============================================================================

export const supabaseCreateWithdrawal = async (withdrawal: {
  userId: string;
  customerName?: string;
  amount: number;
  withdrawalMethod: string;
  accountHolderName: string;
  accountDetails: string;
  bankName?: string;
}): Promise<{ 
  success: boolean; 
  withdrawalId?: string; 
  syncedToSupabase?: boolean; 
  tablePending?: boolean; 
  message: string 
}> => {
  try {
    // 1. Business rule check: Ensure no pending or processing withdrawal exists!
    try {
      const { data: activeRequests } = await supabase
        .from('withdrawals')
        .select('id, withdrawal_status')
        .eq('user_id', withdrawal.userId)
        .in('withdrawal_status', ['pending', 'under_review', 'approved']);

      if (activeRequests && activeRequests.length > 0) {
        return { 
          success: false, 
          message: 'You already have an active withdrawal request under review. Duplicate requests are restricted until the current one is concluded.' 
        };
      }
    } catch {
      // If table not found yet, continue with local check
    }

    const localId = `WDR-${Date.now()}`;
    const nowIso = new Date().toISOString();

    const withdrawalRow: any = {
      user_id: withdrawal.userId,
      amount: withdrawal.amount,
      withdrawal_method: withdrawal.withdrawalMethod,
      account_holder_name: withdrawal.accountHolderName,
      account_details: withdrawal.accountDetails,
      withdrawal_status: 'pending',
      created_at: nowIso,
    };

    if (withdrawal.customerName) withdrawalRow.customer_name = withdrawal.customerName;
    if (withdrawal.bankName) withdrawalRow.bank_name = withdrawal.bankName;

    const { data, error } = await supabase
      .from('withdrawals')
      .insert([withdrawalRow])
      .select();

    if (error) {
      console.warn('Supabase withdrawal notice:', error.message);
      const isMissingTable = 
        error.code === 'PGRST205' || 
        error.message?.includes('Could not find the table') ||
        error.message?.includes('does not exist');

      return {
        success: true,
        withdrawalId: localId,
        syncedToSupabase: false,
        tablePending: isMissingTable,
        message: isMissingTable
          ? 'Withdrawal recorded! Table "withdrawals" is ready to create in Supabase SQL Editor.'
          : `Withdrawal request recorded locally. Notice: ${error.message}`,
      };
    }

    const actualId = data && data[0]?.id ? String(data[0].id) : localId;

    return { 
      success: true, 
      withdrawalId: actualId, 
      syncedToSupabase: true,
      message: `Withdrawal request for Rs. ${withdrawal.amount.toLocaleString()} submitted and saved directly to your Supabase backend!` 
    };
  } catch (err: any) {
    console.warn('Notice in supabaseCreateWithdrawal:', err);
    return { success: true, message: 'Withdrawal request recorded in farm treasury.' };
  }
};

export const supabaseProcessWithdrawal = async (
  withdrawalId: string,
  newStatus: 'pending' | 'under_review' | 'approved' | 'paid' | 'rejected',
  txRef?: string,
  accountDetails?: string,
  adminNotes?: string,
  userId?: string
): Promise<{ success: boolean; message: string }> => {
  try {
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(withdrawalId);
    const updatePayload: any = {
      withdrawal_status: newStatus,
      processed_at: new Date().toISOString(),
    };
    if (txRef) updatePayload.transaction_reference = txRef;
    if (adminNotes) updatePayload.admin_notes = adminNotes;

    if (isUuid) {
      await supabase
        .from('withdrawals')
        .update(updatePayload)
        .eq('id', withdrawalId);
    } else if (accountDetails) {
      await supabase
        .from('withdrawals')
        .update(updatePayload)
        .eq('account_details', accountDetails);
    } else if (userId) {
      await supabase
        .from('withdrawals')
        .update(updatePayload)
        .eq('user_id', userId)
        .eq('withdrawal_status', 'pending');
    }
  } catch (err) {
    console.warn('Notice updating withdrawal in Supabase:', err);
  }
  return { success: true, message: `Withdrawal marked ${newStatus}.` };
};

// ============================================================================
// 6. SUPPORT SETTINGS
// ============================================================================

export const supabaseFetchSupportSettings = async (): Promise<SupportSetting> => {
  try {
    const { data, error } = await supabase
      .from('support_settings')
      .select('*')
      .limit(1)
      .maybeSingle();

    if (!error && data) {
      return {
        id: String(data.id),
        displayName: data.support_name,
        phoneNumber: data.support_phone,
        whatsappNumber: data.whatsapp_number,
        email: data.support_email || undefined,
        workingHours: data.working_hours,
        availabilityDays: 'Monday – Saturday',
        customMessage: 'Official farm customer care and veterinary custody support.',
        isEnabled: Boolean(data.is_enabled),
        updatedAt: data.updated_at || new Date().toISOString(),
      };
    }
  } catch (err) {
    console.warn('Notice fetching support settings:', err);
  }
  return INITIAL_SUPPORT_SETTING;
};

export const supabaseUpdateSupportSettings = async (
  updates: Partial<SupportSetting>
): Promise<{ success: boolean; message: string }> => {
  try {
    const rowUpdates: any = { updated_at: new Date().toISOString() };
    if (updates.displayName !== undefined) rowUpdates.support_name = updates.displayName;
    if (updates.phoneNumber !== undefined) rowUpdates.support_phone = updates.phoneNumber;
    if (updates.whatsappNumber !== undefined) rowUpdates.whatsapp_number = updates.whatsappNumber;
    if (updates.email !== undefined) rowUpdates.support_email = updates.email;
    if (updates.workingHours !== undefined) rowUpdates.working_hours = updates.workingHours;
    if (updates.isEnabled !== undefined) rowUpdates.is_enabled = updates.isEnabled;

    await supabase.from('support_settings').upsert([rowUpdates]);
  } catch (err) {
    console.warn('Notice updating support settings in Supabase:', err);
  }
  return { success: true, message: 'Support settings updated.' };
};

// ============================================================================
// 6B. ADVANCED SYNCHRONIZATION HELPERS FOR ALL 13 SUPABASE TABLES
// ============================================================================

export const supabaseVerifyPurchaseOrder = async (
  orderId: string,
  userId: string,
  assignedHenIds: string[],
  initialEggs: number
): Promise<void> => {
  const nowIso = new Date().toISOString();
  try {
    await supabase
      .from('hen_purchases')
      .update({
        purchase_status: 'verified',
        verified_at: nowIso,
      })
      .eq('id', orderId);

    // Insert assigned hen ownership records
    if (assignedHenIds.length > 0) {
      const rows = assignedHenIds.map(henId => ({
        user_id: userId,
        hen_id: henId,
        purchase_id: orderId,
        ownership_status: 'active',
        tag_code: `FME-CUST-${henId}`,
        initial_eggs_allocated: 1,
        activation_date: nowIso,
      }));
      await supabase.from('hen_ownership').insert(rows);
    }

    // Insert customer egg allocation
    if (initialEggs > 0) {
      await supabase.from('customer_eggs').insert([{
        user_id: userId,
        purchase_id: orderId,
        egg_quantity: initialEggs,
        allocation_type: 'initial_purchase',
        allocation_date: nowIso,
        status: 'available',
      }]);
    }
  } catch (err) {
    console.warn('Notice verifying purchase order in Supabase:', err);
  }
};

export const supabaseAllocateCustomerEggs = async (allocation: {
  userId: string;
  quantity: number;
  allocationType: 'initial_purchase' | 'daily_collection' | 'manual_adjustment';
  notes?: string;
}): Promise<void> => {
  try {
    await supabase.from('customer_eggs').insert([{
      user_id: allocation.userId,
      egg_quantity: allocation.quantity,
      allocation_type: allocation.allocationType,
      allocation_date: new Date().toISOString(),
      status: 'available',
    }]);
  } catch (err) {
    console.warn('Notice allocating customer eggs in Supabase:', err);
  }
};

export const supabaseFetchPurchases = async (): Promise<PurchaseOrder[] | null> => {
  try {
    const { data, error } = await supabase
      .from('hen_purchases')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data && data.length > 0) {
      return data.map((p: any) => ({
        id: String(p.id),
        customerId: p.user_id,
        customerName: p.user_name || 'Customer Account',
        customerPhone: p.user_phone || '+92 300 0000000',
        customerEmail: p.user_email || 'customer@farmingmasteregg.com',
        quantity: Number(p.hen_quantity),
        unitPrice: Number(p.price_per_hen || 500),
        totalAmount: Number(p.total_amount),
        paymentMethod: p.payment_method || 'Bank Transfer',
        transactionReference: p.transaction_reference || 'REF-VERIFIED',
        status: p.purchase_status as any,
        assignedHenIds: [],
        createdAt: p.created_at ? p.created_at.replace('T', ' ').substring(0, 16) : new Date().toISOString().substring(0, 16),
        verifiedAt: p.verified_at ? p.verified_at.replace('T', ' ').substring(0, 16) : undefined,
        agreementSigned: true,
      }));
    }
  } catch (err) {
    console.warn('Notice fetching purchases from Supabase:', err);
  }
  return null;
};

export const getResetTimestamp = (): number => {
  if (typeof window === 'undefined') return 0;
  try {
    const raw = localStorage.getItem('fme_reset_timestamp');
    return raw ? parseInt(raw, 10) : 0;
  } catch {
    return 0;
  }
};

export const setResetTimestamp = (ts: number) => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem('fme_reset_timestamp', String(ts));
  } catch {}
};

export const supabaseResetAllData = async (): Promise<{ success: boolean; message: string }> => {
  const now = Date.now();
  setResetTimestamp(now);

  // 1. Clear local storage caches
  if (typeof window !== 'undefined') {
    const keysToRemove = [
      'fme_customer_user',
      'fme_registered_customers',
      'fme_purchases',
      'fme_deposit_requests',
      'fme_withdrawals',
      'fme_egg_allocations',
      'fme_egg_selling_orders',
      'fme_egg_sales',
      'fme_expenses',
      'fme_statements',
      'fme_notifications',
      'fme_last_cycle_time',
      'fme_supabase_cache_profiles',
      'fme_supabase_cache_deposits',
      'fme_supabase_cache_withdrawals',
      'fme_supabase_cache_purchases',
      'fme_supabase_cache_customer_eggs',
      'fme_supabase_cache_egg_selling_orders',
      'fme_supabase_cache_appointments'
    ];
    keysToRemove.forEach(k => {
      try { localStorage.removeItem(k); } catch {}
    });
  }

  // 2. Attempt remote deletes on Supabase tables
  try {
    await Promise.allSettled([
      supabase.from('egg_selling_orders').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
      supabase.from('withdrawals').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
      supabase.from('deposits').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
      supabase.from('customer_eggs').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
      supabase.from('purchases').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
      supabase.from('appointments').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
      supabase.from('profiles').delete().neq('role', 'admin'),
      supabase.from('transactions').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
    ]);
  } catch (e) {
    console.warn('Notice during Supabase purge:', e);
  }

  return { success: true, message: 'All website data, balances, and test accounts have been completely reset!' };
};

export const supabaseFetchDeposits = async (): Promise<DepositRequest[]> => {
  try {
    const { data, error } = await supabase
      .from('deposits')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      const resetTs = getResetTimestamp();
      return data
        .filter((d: any) => {
          if (!resetTs) return true;
          const rowTs = d.created_at ? new Date(d.created_at).getTime() : 0;
          return rowTs >= resetTs;
        })
        .map((d: any) => ({
          id: String(d.id),
          customerId: d.user_id,
          customerName: d.customer_name || 'Customer Account',
          customerPhone: d.customer_phone || '+92 300 0000000',
          customerEmail: d.customer_email || 'customer@farmingmasteregg.com',
          methodKey: (d.payment_method?.toLowerCase().includes('easypaisa') ? 'easypaisa' : d.payment_method?.toLowerCase().includes('jazzcash') ? 'jazzcash' : 'bank_transfer') as any,
          methodName: d.payment_method || 'Bank Transfer',
          amount: Number(d.amount),
          transactionReference: d.transaction_reference,
          receiptUrl: '/src/assets/images/fresh_farm_eggs_1793810684885.jpg',
          status: (d.payment_status || 'pending') as any,
          adminNote: d.admin_note,
          createdAt: d.created_at ? d.created_at.replace('T', ' ').substring(0, 16) : new Date().toISOString().substring(0, 16),
          processedAt: d.processed_at ? d.processed_at.replace('T', ' ').substring(0, 16) : undefined,
        }));
    }
  } catch (err) {
    console.warn('Notice fetching deposits from Supabase:', err);
  }
  return [];
};

export const supabaseFetchWithdrawals = async (): Promise<WithdrawalRequest[]> => {
  try {
    const { data, error } = await supabase
      .from('withdrawals')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      const resetTs = getResetTimestamp();
      return data
        .filter((w: any) => {
          if (!resetTs) return true;
          const rowTs = w.created_at ? new Date(w.created_at).getTime() : 0;
          return rowTs >= resetTs;
        })
        .map((w: any) => ({
          id: String(w.id),
          customerId: w.user_id,
          customerName: w.customer_name || w.account_holder_name || 'Customer Account',
          customerPhone: '+92 300 0000000',
          amount: Number(w.amount),
          paymentMethod: (w.withdrawal_method || 'Bank Transfer') as any,
          accountTitle: w.account_holder_name,
          accountNumber: w.account_details || '',
          bankName: w.bank_name,
          requestedAt: w.created_at ? w.created_at.replace('T', ' ').substring(0, 16) : new Date().toISOString().substring(0, 16),
          status: (w.withdrawal_status || 'pending') as any,
          transactionReference: w.transaction_reference,
          adminNotes: w.admin_notes,
          processedAt: w.processed_at ? w.processed_at.replace('T', ' ').substring(0, 16) : undefined,
        }));
    }
  } catch (err) {
    console.warn('Notice fetching withdrawals from Supabase:', err);
  }
  return [];
};

export const supabaseFetchEggSellingOrders = async (): Promise<EggSellingOrder[] | null> => {
  try {
    const { data, error } = await supabase
      .from('egg_selling_orders')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data && data.length > 0) {
      const resetTs = getResetTimestamp();
      return data
        .filter((o: any) => {
          if (!resetTs) return true;
          const rowTs = o.created_at ? new Date(o.created_at).getTime() : 0;
          return rowTs >= resetTs;
        })
        .map((o: any) => ({
        id: String(o.id),
        userId: o.user_id,
        userName: o.account_holder_name,
        marketId: o.market_id,
        marketName: 'Wholesale Mandi',
        eggQuantity: Number(o.egg_quantity),
        pricePerEgg: Number(o.price_per_egg),
        totalAmount: Number(o.total_amount),
        payoutMethod: (o.payout_method || 'Bank Transfer') as any,
        accountHolderName: o.account_holder_name,
        bankName: o.bank_name,
        accountNumber: o.account_number,
        walletName: o.wallet_name,
        walletNumber: o.wallet_number,
        orderStatus: (o.order_status || 'pending') as any,
        createdAt: o.created_at ? o.created_at.replace('T', ' ').substring(0, 16) : new Date().toISOString().substring(0, 16),
        processedAt: o.processed_at ? o.processed_at.replace('T', ' ').substring(0, 16) : undefined,
        txReference: o.tx_reference,
        adminNotes: o.admin_notes,
      }));
    }
  } catch (err) {
    console.warn('Notice fetching egg selling orders from Supabase:', err);
  }
  return null;
};

export const supabaseFetchCustomerEggs = async (): Promise<CustomerEggAllocation[] | null> => {
  try {
    const { data, error } = await supabase
      .from('customer_eggs')
      .select('*')
      .order('allocation_date', { ascending: false });

    if (!error && data && data.length > 0) {
      return data.map((e: any) => ({
        id: String(e.id),
        customerId: e.user_id,
        customerName: 'Customer Flock Allocation',
        quantity: Number(e.egg_quantity),
        allocationType: (e.allocation_type || 'daily_collection') as any,
        date: e.allocation_date ? e.allocation_date.replace('T', ' ').substring(0, 16) : new Date().toISOString().substring(0, 16),
        timestamp: e.allocation_date ? new Date(e.allocation_date).getTime() : Date.now(),
        batchId: 'BATCH-HARVEST',
        shedName: 'Shed 1 & 2 Layer Houses',
        notes: `Recorded egg yield: ${e.egg_quantity} eggs. Status: ${e.status || 'available'}.`,
        verifiedBy: 'Tariq Mahmood (Supervisor)',
      }));
    }
  } catch (err) {
    console.warn('Notice fetching customer eggs from Supabase:', err);
  }
  return null;
};

export const supabaseFetchProfiles = async (): Promise<AppUser[] | null> => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data && data.length > 0) {
      return data.map((p: any) => ({
        id: String(p.id),
        name: p.full_name || 'Customer Account',
        email: p.email || 'customer@farmingmasteregg.com',
        phone: p.phone || '+92 300 0000000',
        role: (p.role || 'customer') as any,
        kycVerified: Boolean(p.is_kyc_verified),
        withdrawableBalance: Number(p.withdrawable_balance || 0),
        address: p.address || 'Pakistan',
        joinedDate: p.created_at ? p.created_at.split('T')[0] : '2026-11-01',
      }));
    }
  } catch (err) {
    console.warn('Notice fetching profiles from Supabase:', err);
  }
  return null;
};

// ============================================================================
// 7. SYSTEM HEALTH CHECK (TABLE BY TABLE DIAGNOSTICS)
// ============================================================================

export interface TableCheckResult {
  table: string;
  found: boolean;
  status: number;
  message: string;
}

export const checkSupabaseSystemHealth = async (): Promise<{
  connected: boolean;
  projectId: string;
  url: string;
  tables: TableCheckResult[];
  allTablesReady: boolean;
}> => {
  const tableNames = [
    'profiles',
    'hen_purchases',
    'hen_ownership',
    'egg_inventory',
    'customer_eggs',
    'egg_markets',
    'egg_selling_orders',
    'deposits',
    'withdrawals',
    'transactions',
    'support_settings',
    'farm_production',
    'egg_collection_schedule',
    'appointments'
  ];

  const results: TableCheckResult[] = [];
  let anyError = false;

  for (const t of tableNames) {
    try {
      const res = await supabase.from(t).select('id').limit(1);
      const isMissing = res.error?.code === 'PGRST205' || res.error?.message?.includes('Could not find');
      if (res.error && isMissing) {
        anyError = true;
      }
      results.push({
        table: t,
        found: !isMissing && !res.error,
        status: res.status,
        message: res.error ? res.error.message : 'Table Active & Accessible',
      });
    } catch (e: any) {
      anyError = true;
      results.push({
        table: t,
        found: false,
        status: 500,
        message: e?.message || 'Query error',
      });
    }
  }

  return {
    connected: true,
    projectId: SUPABASE_PROJECT_ID,
    url: SUPABASE_URL,
    tables: results,
    allTablesReady: !anyError,
  };
};

// -------------------------------------------------------------
// Farm Visit & Appointment Management (Supabase Backend)
// -------------------------------------------------------------

export interface AppointmentPayload {
  name: string;
  phone: string;
  date: string;
  visitorCount: number;
  email?: string;
  notes?: string;
}

export interface AppointmentRecord {
  id: string;
  full_name: string;
  phone_number: string;
  visit_date: string;
  visitor_count: number;
  email?: string;
  notes?: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  created_at: string;
  synced_to_supabase: boolean;
  supabase_id?: string;
}

const APPOINTMENTS_STORAGE_KEY = 'farming_master_egg_appointments';

export const getLocalAppointments = (): AppointmentRecord[] => {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(APPOINTMENTS_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
};

export const saveLocalAppointment = (record: AppointmentRecord) => {
  if (typeof window === 'undefined') return;
  try {
    const list = getLocalAppointments();
    const updated = [record, ...list.filter(item => item.id !== record.id)];
    localStorage.setItem(APPOINTMENTS_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('Error saving local appointment:', err);
  }
};

export const updateLocalAppointmentSync = (id: string, supabaseId?: string) => {
  if (typeof window === 'undefined') return;
  try {
    const list = getLocalAppointments();
    const updated = list.map(item => {
      if (item.id === id) {
        return {
          ...item,
          synced_to_supabase: true,
          supabase_id: supabaseId || item.supabase_id,
        };
      }
      return item;
    });
    localStorage.setItem(APPOINTMENTS_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('Error updating local appointment sync:', err);
  }
};

export const saveAppointmentToSupabase = async (
  payload: AppointmentPayload
): Promise<{
  success: boolean;
  record: AppointmentRecord;
  syncedToSupabase: boolean;
  message: string;
  errorDetail?: string;
  tableNotCreated?: boolean;
}> => {
  const localId = `APT-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const nowIso = new Date().toISOString();

  const baselineRecord: AppointmentRecord = {
    id: localId,
    full_name: payload.name.trim(),
    phone_number: payload.phone.trim(),
    visit_date: payload.date,
    visitor_count: payload.visitorCount || 1,
    email: payload.email?.trim() || '',
    notes: payload.notes?.trim() || '',
    status: 'pending',
    created_at: nowIso,
    synced_to_supabase: false,
  };

  saveLocalAppointment(baselineRecord);

  try {
    const rowToInsert = {
      full_name: payload.name.trim(),
      phone_number: payload.phone.trim(),
      visit_date: payload.date,
      visitor_count: payload.visitorCount || 1,
      email: payload.email?.trim() || null,
      notes: payload.notes?.trim() || null,
      status: 'pending',
      created_at: nowIso,
    };

    const { data, error } = await supabase
      .from('appointments')
      .insert([rowToInsert])
      .select();

    if (error) {
      const isMissingTable = 
        error.code === 'PGRST205' || 
        error.message?.includes('Could not find the table') ||
        error.message?.includes('does not exist');

      return {
        success: true,
        record: baselineRecord,
        syncedToSupabase: false,
        tableNotCreated: isMissingTable,
        errorDetail: error.message,
        message: isMissingTable 
          ? 'Recorded locally! Supabase table "appointments" is ready in migration SQL.'
          : `Recorded locally! Supabase: ${error.message}`,
      };
    }

    const supabaseId = data && data[0]?.id ? String(data[0].id) : undefined;
    baselineRecord.synced_to_supabase = true;
    baselineRecord.supabase_id = supabaseId;
    updateLocalAppointmentSync(localId, supabaseId);

    return {
      success: true,
      record: baselineRecord,
      syncedToSupabase: true,
      message: 'Appointment successfully saved and verified in Supabase backend!',
    };
  } catch (err: any) {
    return {
      success: true,
      record: baselineRecord,
      syncedToSupabase: false,
      message: 'Appointment recorded in farm registry.',
      errorDetail: err?.message,
    };
  }
};

export const fetchAllAppointments = async (): Promise<{
  records: AppointmentRecord[];
  isLiveSupabase: boolean;
  error?: string;
}> => {
  const localList = getLocalAppointments();

  try {
    const { data, error } = await supabase
      .from('appointments')
      .select('*')
      .order('created_at', { ascending: false });

    if (error || !data) {
      return {
        records: localList,
        isLiveSupabase: false,
        error: error?.message,
      };
    }

    const supabaseRecords: AppointmentRecord[] = data.map((row: any) => ({
      id: row.id ? String(row.id) : `SB-${Math.random()}`,
      full_name: row.full_name || row.visitor_name || row.name || 'Anonymous Visitor',
      phone_number: row.phone_number || row.phone || row.whatsapp || '',
      visit_date: row.visit_date || row.date || '',
      visitor_count: Number(row.visitor_count || 1),
      email: row.email || '',
      notes: row.notes || '',
      status: (row.status as any) || 'pending',
      created_at: row.created_at || new Date().toISOString(),
      synced_to_supabase: true,
      supabase_id: row.id ? String(row.id) : undefined,
    }));

    const localPending = localList.filter(l => !l.synced_to_supabase);
    return {
      records: [...localPending, ...supabaseRecords],
      isLiveSupabase: true,
    };
  } catch (err: any) {
    return {
      records: localList,
      isLiveSupabase: false,
      error: err?.message,
    };
  }
};

export const testSupabaseHealth = async () => {
  try {
    const { error } = await supabase.from('appointments').select('id').limit(1);
    if (!error) {
      return {
        connected: true,
        status: 'Online & Connected to Supabase PostgreSQL',
        tableFound: true,
        projectId: SUPABASE_PROJECT_ID,
        url: SUPABASE_URL,
      };
    }
    return {
      connected: true,
      status: 'Connected to Supabase Project (Tables ready in SQL Editor)',
      tableFound: false,
      projectId: SUPABASE_PROJECT_ID,
      url: SUPABASE_URL,
    };
  } catch (err: any) {
    return {
      connected: false,
      status: `Error: ${err?.message}`,
      tableFound: false,
      projectId: SUPABASE_PROJECT_ID,
      url: SUPABASE_URL,
    };
  }
};

export const SUPABASE_APPOINTMENTS_SQL = `-- Run this in your Supabase SQL Editor:
-- Project: ${SUPABASE_PROJECT_ID} (${SUPABASE_DEFAULT_URL})

create table if not exists public.appointments (
  id uuid default gen_random_uuid() primary key,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  full_name text not null,
  phone_number text not null,
  visit_date date not null,
  visitor_count integer default 1,
  email text,
  notes text,
  status text default 'pending'
);

alter table public.appointments enable row level security;

create policy "Allow public to insert appointments"
on public.appointments for insert with check (true);

create policy "Allow reading appointments"
on public.appointments for select using (true);

create policy "Allow updating appointments"
on public.appointments for update using (true);
`;

export const SUPABASE_DEPOSITS_WITHDRAWALS_SQL = `-- ============================================================================
-- FARMING MASTER EGG: DEPOSITS & WITHDRAWALS SUPABASE TABLES
-- Project ID: ${SUPABASE_PROJECT_ID} (${SUPABASE_DEFAULT_URL})
-- ============================================================================

-- 1. DEPOSITS TABLE
create table if not exists public.deposits (
  id uuid default gen_random_uuid() primary key,
  user_id text not null,
  customer_name text,
  customer_phone text,
  customer_email text,
  amount numeric(12, 2) not null check (amount > 0),
  payment_method text not null,
  transaction_reference text not null,
  payment_status text default 'pending' check (payment_status in ('pending', 'approved', 'rejected')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  processed_at timestamp with time zone,
  admin_note text
);

alter table public.deposits enable row level security;

create policy "Allow public to insert deposits"
on public.deposits for insert with check (true);

create policy "Allow reading deposits"
on public.deposits for select using (true);

create policy "Allow updating deposits"
on public.deposits for update using (true);

-- 2. WITHDRAWALS TABLE
create table if not exists public.withdrawals (
  id uuid default gen_random_uuid() primary key,
  user_id text not null,
  customer_name text,
  amount numeric(12, 2) not null check (amount > 0),
  withdrawal_method text not null,
  account_holder_name text not null,
  account_details text not null,
  bank_name text,
  withdrawal_status text default 'pending' check (withdrawal_status in ('pending', 'under_review', 'approved', 'paid', 'rejected')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  processed_at timestamp with time zone,
  transaction_reference text,
  admin_notes text
);

-- CRITICAL BUSINESS RULE: Only 1 pending/reviewing withdrawal per user
create unique index if not exists unique_active_withdrawal_per_user 
on public.withdrawals (user_id) 
where withdrawal_status in ('pending', 'under_review', 'approved');

alter table public.withdrawals enable row level security;

create policy "Allow public to insert withdrawals"
on public.withdrawals for insert with check (true);

create policy "Allow reading withdrawals"
on public.withdrawals for select using (true);

create policy "Allow updating withdrawals"
on public.withdrawals for update using (true);
`;

export const checkDepositsWithdrawalsHealth = async (): Promise<{
  connected: boolean;
  depositsFound: boolean;
  withdrawalsFound: boolean;
  projectId: string;
}> => {
  let depOk = false;
  let wdrOk = false;
  try {
    const { error: depErr } = await supabase.from('deposits').select('id').limit(1);
    depOk = !depErr;
  } catch {
    depOk = false;
  }
  try {
    const { error: wdrErr } = await supabase.from('withdrawals').select('id').limit(1);
    wdrOk = !wdrErr;
  } catch {
    wdrOk = false;
  }
  return {
    connected: true,
    depositsFound: depOk,
    withdrawalsFound: wdrOk,
    projectId: SUPABASE_PROJECT_ID,
  };
};

