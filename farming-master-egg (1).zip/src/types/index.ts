/**
 * Core domain types for Farming Master Egg
 * Real poultry farming and actual physical hen ownership platform.
 */

export type HenBreed = 
  | 'Rhode Island Red' 
  | 'Golden Misri' 
  | 'Fayoumi Layer' 
  | 'Desi Cross' 
  | 'White Leghorn';

export type HenHealthStatus = 
  | 'healthy' 
  | 'molting' 
  | 'under_observation' 
  | 'sick' 
  | 'mortality';

export type HenStatus = 'available' | 'reserved' | 'owned';

export interface Hen {
  id: string;
  tagCode: string; // e.g. FME-L201
  breed: HenBreed;
  ageWeeks: number;
  healthStatus: HenHealthStatus;
  shedId: string;
  shedName: string;
  flockCode: string;
  purchasePrice: number; // Fixed at Rs. 500
  status: HenStatus;
  ownerId?: string;
  ownerName?: string;
  acquisitionDate: string;
  vaccinationStatus: string;
  photoUrl: string;
  dailyEggYieldAvg: number;
  notes?: string;
  ownershipId?: string;
  initialEggsAllocated?: number;
  cycleStartedAt?: number;
  nextCollectionTimestamp?: number;
}

export interface Shed {
  id: string;
  name: string;
  code: string;
  capacity: number;
  currentHens: number;
  ventilation: string;
  feedingSystem: string;
  drinkingSystem: string;
  temperatureC: number;
  humidityPct: number;
}

export interface EggProductionRecord {
  id: string;
  date: string;
  shedId: string;
  shedName: string;
  flockSize: number;
  eggsCollected: number;
  eggsDamaged: number;
  eggsReserved: number;
  eggsAvailableForSale: number;
  layingPercentage: number;
  notes: string;
  loggedBy: string;
}

export interface EggSaleRecord {
  id: string;
  date: string;
  quantityEggs: number;
  ratePerEgg: number;
  grossAmount: number;
  buyerName: string;
  marketLocation: string;
  paymentStatus: 'paid' | 'pending';
  invoiceNumber: string;
}

export type ExpenseCategory = 
  | 'feed' 
  | 'veterinary' 
  | 'labour' 
  | 'electricity' 
  | 'maintenance' 
  | 'transport';

export interface FarmExpense {
  id: string;
  date: string;
  category: ExpenseCategory;
  amount: number;
  description: string;
  voucherNumber: string;
  receiptAvailable: boolean;
}

export interface FinancialCycle {
  id: string;
  cyclePeriod: string;
  grossEggRevenue: number;
  totalOperatingExpenses: number;
  netFarmIncome: number;
  totalFlockHens: number;
  customerOwnedHens: number;
  grossRevenuePerHen: number;
  operatingCostPerHen: number;
  netDistributionPerHen: number;
  farmManagementFeePct: number; // 10%
  status: 'draft' | 'published';
  publishedDate?: string;
}

export interface CustomerStatement {
  id: string;
  customerId: string;
  customerName: string;
  cyclePeriod: string;
  hensOwned: number;
  grossRevenueShare: number;
  operatingExpenseShare: number;
  farmManagementFee: number;
  netPayableAmount: number;
  distributedAt: string;
  status: 'credited' | 'settled';
}

export type DepositMethodKey = 'easypaisa' | 'jazzcash' | 'bank_transfer';

export interface DepositSetting {
  id: string;
  methodKey: DepositMethodKey;
  name: string;
  isEnabled: boolean;
  accountHolderName: string;
  accountNumber: string;
  bankName?: string;
  accountDetails?: string;
  paymentInstructions?: string;
  updatedAt: string;
}

export type DepositRequestStatus = 'pending' | 'approved' | 'rejected';

export interface DepositRequest {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  methodKey: DepositMethodKey;
  methodName: string;
  amount: number;
  transactionReference: string;
  receiptUrl?: string;
  status: DepositRequestStatus;
  adminNote?: string;
  createdAt: string;
  processedAt?: string;
  processedBy?: string;
}

export type PaymentMethod = 'Easypaisa' | 'JazzCash' | 'Bank Transfer' | 'Account Balance';

export interface PurchaseOrder {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  quantity: number;
  unitPrice: number; // Rs. 500
  totalAmount: number;
  paymentMethod: PaymentMethod;
  transactionReference: string;
  receiptSlipUrl?: string;
  status: 'pending' | 'verified' | 'rejected';
  assignedHenIds: string[];
  createdAt: string;
  verifiedAt?: string;
  agreementSigned: boolean;
  notes?: string;
}

export type WithdrawalStatus = 'pending' | 'under_review' | 'approved' | 'rejected' | 'paid';

export type WithdrawalMethodKey = 'easypaisa' | 'jazzcash' | 'bank_transfer';

export interface WithdrawalSetting {
  id: string;
  methodKey: WithdrawalMethodKey;
  name: string;
  isEnabled: boolean;
  accountHolderName: string;
  accountNumber: string;
  bankName?: string;
  branchName?: string;
  iban?: string;
  paymentInstructions?: string;
  updatedAt: string;
}

export interface WithdrawalRequest {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  amount: number;
  paymentMethod: 'Easypaisa' | 'JazzCash' | 'Bank Transfer';
  accountTitle: string;
  accountNumber: string;
  bankName?: string;
  requestedAt: string;
  status: WithdrawalStatus;
  adminNotes?: string;
  transactionReference?: string;
  processedAt?: string;
}

export interface HenOwnershipCertificate {
  certificateId: string;
  henId: string;
  henTag: string;
  breed: string;
  shedName: string;
  ownerId: string;
  ownerName: string;
  ownerPhone: string;
  issueDate: string;
  careTaker: string;
  farmLocation: string;
  contractSerial: string;
}

export interface AppUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'customer' | 'admin';
  kycVerified: boolean;
  withdrawableBalance: number;
  address: string;
  joinedDate: string;
  passwordHash?: string;
  salt?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  category: 'hen' | 'production' | 'sale' | 'expense' | 'allocation' | 'purchase' | 'deposit' | 'withdrawal' | 'settings' | 'security';
  details: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
  type: 'purchase' | 'deposit' | 'statement' | 'health' | 'withdrawal' | 'production' | 'system';
}

export type PublicActiveView = 
  | 'home' 
  | 'about' 
  | 'facilities' 
  | 'marketplace' 
  | 'how-it-works' 
  | 'production-process' 
  | 'gallery' 
  | 'transparency' 
  | 'faqs' 
  | 'contact' 
  | 'terms' 
  | 'privacy' 
  | 'agreement' 
  | 'risk-disclosure' 
  | 'customer-dashboard'
  | 'customer-login'
  | 'customer-register';

export interface SupportSetting {
  id: string;
  phoneNumber: string;
  whatsappNumber: string;
  displayName: string;
  availabilityDays: string;
  workingHours: string;
  email?: string;
  customMessage: string;
  isEnabled: boolean;
  updatedAt: string;
}

export interface CustomerEggAllocation {
  id: string;
  customerId: string;
  customerName: string;
  henId?: string;
  henTag?: string;
  quantity: number;
  allocationType: 'initial_purchase' | 'daily_collection' | 'manual_adjustment';
  date: string;
  timestamp: number;
  batchId?: string;
  shedName?: string;
  notes: string;
  verifiedBy: string;
}

export interface EggMarket {
  id: string;
  marketName: string;
  pricePerEgg: number;
  minimumQuantity: number;
  maximumQuantity: number;
  availableCapacity: number;
  processingTime: string;
  isActive: boolean;
  description?: string;
}

export interface EggSellingOrder {
  id: string;
  userId: string;
  userName?: string;
  marketId: string;
  marketName: string;
  eggQuantity: number;
  pricePerEgg: number;
  totalAmount: number;
  payoutMethod: 'Bank Transfer' | 'Easypaisa' | 'JazzCash';
  accountHolderName: string;
  bankName?: string;
  accountNumber?: string;
  walletName?: string;
  walletNumber?: string;
  orderStatus: 'pending' | 'processing' | 'paid' | 'rejected';
  createdAt: string;
  processedAt?: string;
  txReference?: string;
  adminNotes?: string;
}

export interface HenOwnershipRecord {
  id: string;
  userId: string;
  henId: string;
  purchaseId: string;
  ownershipStatus: 'active' | 'transferred' | 'mortality';
  activationDate: string;
  tagCode: string;
  initialEggsAllocated: number;
}

export interface EggCollectionSchedule {
  id: string;
  userId: string;
  henId: string;
  nextCollectionAt: number;
  lastCollectionAt: number;
  scheduleStatus: 'active' | 'paused' | 'completed';
}

export interface SupabaseTransaction {
  id: string;
  userId: string;
  transactionType: 'deposit' | 'withdrawal' | 'hen_purchase' | 'egg_sale' | 'dividend';
  amount: number;
  referenceId: string;
  transactionStatus: 'pending' | 'completed' | 'failed' | 'rejected';
  createdAt: string;
  notes?: string;
}

export type AdminActiveSection =
  // 11 Streamlined Admin Navigation Sections
  | 'overview'            // 1. Dashboard
  | 'customers'           // 2. Customers
  | 'hens'                // 3. Hen Management
  | 'deposits'            // 4. Deposits
  | 'withdrawals'         // 5. Withdrawals
  | 'egg-management'      // 6. Egg Management
  | 'egg-markets'         // 7. Egg Markets
  | 'selling-orders'      // 8. Selling Orders
  | 'payment-settings'    // 9. Payment Settings
  | 'support-settings'    // 10. Support Settings
  | 'website-settings'    // 11. Website Settings
  // Legacy section aliases for backwards compatibility
  | 'ownership'
  | 'purchases'
  | 'deposit-settings'
  | 'withdrawal-settings'
  | 'appointments'
  | 'production'
  | 'egg-collection'
  | 'sales'
  | 'expenses'
  | 'statements'
  | 'reports'
  | 'notifications'
  | 'audit'
  | 'settings';


